class AST

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}#{y[3..y.length]}:"

		attrs.each do |a|
			a.print_ast indent + "	" if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end

class ASTNumber < AST
	attr_accessor :litNumb

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@litNumb = d
	end

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}#{y[3..y.length]}: \n#{indent}\tvalor: #{@litNumb}"
	end
end

class ASTIdentificador < AST
	attr_accessor :ident

	def initialize i
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{i}"
		@ident = i
	end

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}#{y[3..y.length]}: \n#{indent}\tnombre: #{@ident}"
	end
end



class ASTBoolean < AST
	attr_accessor :bool

	def initialize b 
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{b}"
		@bool = b
	end

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}#{y[3..y.length]}: #{@bool}"
	end
end

class ArithmeticUnOP < AST
    attr_accessor :operand

    def initialize operand
    	y = "#{self.class}"
    	puts "#{y[3..y.length]} => #{operand}"
        @operand = operand
    end
end

class ArithmeticBinOP < AST
    attr_accessor :left, :right

    def initialize lh, rh
    	y = "#{self.class}"
    	puts "#{y[3..y.length]} => #{lh} , #{rh}"
        @left = lh
        @right = rh
    end
end

class ASTMenosUnario < ArithmeticUnOP;end

class ASTMultiplicacion < ArithmeticBinOP;end
class ASTDivision < ArithmeticBinOP;end
class ASTDiv < ArithmeticBinOP;end
class ASTMod < ArithmeticBinOP;end
class ASTResto < ArithmeticBinOP;end
class ASTSuma < ArithmeticBinOP;end
class ASTResta < ArithmeticBinOP;end

class BooleanUnOP < AST
    attr_accessor :operandb

    def initialize operand
    	y = "#{self.class}"
    	puts "#{y[3..y.length]} => #{operand}"
        @operandb = operand
    end
end

class BooleanBinOP < AST
    attr_accessor :leftb, :rightb

    def initialize lh, rh
    	y = "#{self.class}"
    	puts "#{y[3..y.length]} => #{lh} , #{rh}"
        @leftb = lh
        @rightb = rh
    end
end

class ASTNegado < BooleanUnOP;end

class ASTAnd < BooleanBinOP;end
class ASTOr < BooleanBinOP;end
class ASTDobleIgual < BooleanBinOP;end
class ASTNotIgual < BooleanBinOP;end
class ASTMayorIgual < BooleanBinOP;end
class ASTMenorIgual < BooleanBinOP;end
class ASTMayor < BooleanBinOP;end
class ASTMenor < BooleanBinOP;end

class ASTFuncion < BooleanBinOP;end

class ASTInteracion < AST
	attr_accessor :ident, :exp1, :exp2, :inst

	def initialize i, e1, e2, is
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{i}, #{e1}, #{e2}, #{is}"
		@ident = i
		@exp1 = e1
		@exp2 = e2
		@inst = is
	end
end

class ASTInteracionBy < AST
	attr_accessor :ident, :exp1, :exp2, :exp3, :inst

	def initialize i, e1, e2, e3, is
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{i}, #{e1}, #{e2}, #{e3}, #{is}"
		@ident = i
		@exp1 = e1
		@exp2 = e2
		@exp3 = e3
		@inst = is
	end
end

class ASTCondicional < AST
	attr_accessor :leftb, :rightb

    def initialize lh, rh
    	y = "#{self.class}"
    	puts "#{y[3..y.length]} => #{lh} , #{rh}"
        @leftb = lh
        @rightb = rh
    end
end

class  ASTCondicionalElse < AST
	attr_accessor :exp, :inst1, :inst2

	def initialize e, is1, is2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{e}, #{is1}, #{is2}"
		@exp = e1
		@inst1 = is1
		@inst2 = is2
	end
end

class ASTRead < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@dato = d
	end
end

class ASTWrite < ASTRead

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}Salida:"

		attrs.each do |a|
			a.print_ast indent + "	" if a.respond_to? :print_ast
		end
	end
end

class ASTWriteln < ASTRead

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}Salida con salto:"

		attrs.each do |a|
			a.print_ast indent + "	" if a.respond_to? :print_ast
		end
	end
end

class ASTES < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@dato = d
	end
end

class ASTIteCond < ASTES;end
class ASTIteIte < ASTES;end
class ASTIteBloque < ASTES;end
class ASTIteFunc < ASTES;end

class ASTWhile < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end

class ASTRepeat < ASTWhile;end

class ASTInstruccionesUn < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length-2]} => #{d}"
		@dato = d
	end
end

class ASTInstrucciones < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end

class ASTTipo < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@dato = d
	end

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}#{y[3..y.length]}: \n#{indent}\tnombre: #{@dato}"
	end

end

class ASTIdentificadoresUn < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length-2]} => #{d}"
		@dato = d
	end
end

class ASTIdentificadores < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end

class ASTExpresiones < ASTIdentificadores;end

class ASTDeclaracion < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end

	def print_ast indent=""
		y = "#{self.class}"
		puts "#{indent}#{y[3..y.length]}:"

		attrs.each do |a|
			a.print_ast indent + "	" if a.respond_to? :print_ast
		end
	end
end

class ASTDeclaracionesUn < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..(y.length-2)]} => #{d}"
		@dato = d
	end
end

class ASTDeclaraciones < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1 
		@dato2 = d2
	end
end

class ASTString < ASTIdentificador; end 
class ASTBloque < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2 
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end

class ASTBloque_principal < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@dato = d
	end
end

class ASTParametro < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end

class ASTParametrosUn < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length-2]} => #{d}"
		@dato = d
	end
end

class ASTParametros < AST
	attr_accessor :dato1, :dato2

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@dato = d
	end 
end

class ASTDefFuncion < AST
	attr_accessor :dato1, :dato2, :dato3

	def initialize d1, d2, d3
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}, #{d3}"
		@dato1 = d1
		@dato2 = d2 
		@datos = d2
	end 
end

class ASTInstAsignaciones < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d}"
		@dato = d
	end
end

class ASTAsignacionesUn < AST
	attr_accessor :dato

	def initialize d
		y = "#{self.class}"
		puts "#{y[3..y.length-2]} => #{d}"
		@dato = d
	end
end

class ASTAsignaciones < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end

class ASTAsignacion < AST
	attr_accessor :dato1, :dato2

	def initialize d1, d2
		y = "#{self.class}"
		puts "#{y[3..y.length]} => #{d1}, #{d2}"
		@dato1 = d1
		@dato2 = d2
	end
end