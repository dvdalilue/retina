#Arbol Sintactico 
#Clase que sirve como modelo general para cada uno de los elementos sintacticos
#usados en el lenguaje retina, en particular está definida su impresión por terminal
#en forma de arbol sintactico
class AST
	def print_ast indent = ""
		puts "#{indent}#{self.class}"
		attrs.each do |a|
			a.print_ast indent + "      " if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end

class Programa < AST
	attr_accessor :funciones, :bloque
	def initialize f, b
		@funciones = f
		@bloque = b
	end
end

class Bloque < AST
	attr_accessor :declaraciones, :instrucciones
	def initialize d, i
		@declaraciones = d
		@instrucciones = i
	end
end

class Funcion < AST
	attr_accessor :ident, :argumentos, :instruccionesfu
	def initialize i, a, ifu
		@ident = i
		@argumentos = a
		@instruccionesfu = ifu
	end
end

class FuncionConTipo < AST
	attr_accessor :ident, :argumentos, :instruccionesfu
	def initialize i, a, t, ifu
		@ident = i
		@argumentos = a
		@tipo = t
		@instruccionesfu = ifu
	end

	def print_ast indent = ""
		puts "#{indent}Funcion con Tipo"
		attrs.each do |a|
			a.print_ast indent + "      " if a.respond_to? :print_ast
		end
	end
end

class Argumento < AST
	attr_accessor :tipo, :ident
	def initialize t, i
		@tipo = t
		@ident = i
	end
end

class Tipo < AST
	def initialize n
		@nombre = n
	end
	def print_ast indent = ""
		puts "#{indent}#{self.class}"
		puts "#{indent}     nombre: #{@nombre}"
	end
end

class Declaracion < AST
	attr_accessor :tipo, :identoAsig
	def initialize t, i
		@tipo = t
		@identoAsig = i
	end
end

class Llamada < AST
	def initialize i, a
		@ident = i
		@argumentos = a
	end

	def print_ast indent = ""
		puts "#{indent}Llamada a Funcion"
		attrs.each do |a|
			a.print_ast indent + "      " if a.respond_to? :print_ast
		end
	end
end
 
class ExpresionUnaria < AST
	attr_accessor :op
	def initialize op
		@op = op
	end
end

###Elementos con forma de lista###

class Listas < AST
  attr_accessor :lista
	def initialize a
		@lista = a #Atributo es un arreglo de objetos AST
	end

	def print_ast indent = ""
		puts "#{indent}#{self.class}" #Se imprime el nombre de la clase

		@lista.each do |f|
			f.print_ast indent + "      " if f.respond_to? :print_ast #Luego cada elemento de la lista
		end
	end
end

class Funciones < Listas; end
class Argumentos < Listas; end
class Declaraciones < Listas; end
class Instrucciones < Listas; end
class Salidas < Listas; end

class SalidasConSalto < Listas
	def print_ast indent = ""
		puts "#{indent}Salidas con Salto"
		@lista.each do |f|
			f.print_ast indent + "      " if f.respond_to? :print_ast
		end
	end
end

###Elementos con forma Variable###

class Identificador < AST
	attr_accessor :nombre
	def initialize n
		@nombre = n #Esta es su forma
	end
	def print_ast indent = ""
		puts "#{indent}#{self.class}"
		puts "#{indent}    nombre: #{@nombre}" #Se avisa y se imprime su forma
	end
end

class Numero < AST
	def initialize v
		@valor = v
	end
	def print_ast indent = ""
		puts "#{indent}Literal Numerico "
		puts "#{indent}    valor: #{@valor}"
	end
end

class Booleano < AST
	def initialize v
		@valor = v
	end
	def print_ast indent = ""
		puts "#{indent}Booleano"
		puts "#{indent}    valor: #{@valor}"
	end
end

class CadenaDeCaracteresParser < AST
	def initialize f
		@forma = f
	end
	def print_ast indent = ""
		puts "#{indent}Cadena De Caracteres"
		puts "#{indent}    forma: #{@forma}"
	end
end

class Entrada < ExpresionUnaria;end

class Retorno < ExpresionUnaria;end

###Clases de elementos sintacticos de tipo condicional e iterativo###

#Estas tienen 2 partes
class CondIf < AST
	def initialize g, i
		@guardia = g #Guardia o rango iteratico
		@instruccion = i #Instrucciones
	end
	def print_ast indent = ""
		puts "#{indent}Condicional If" #Se imprime el nombre
		indent = indent + "      "
		puts "#{indent}Guardia:" #Se avisa la guardia
		@guardia.print_ast indent + "      " if @guardia.respond_to? :print_ast # Y se imprimen sus elementos
		@instruccion.print_ast indent + "      " if @instruccion.respond_to? :print_ast
	end
end

class CondIfElse < AST
	def initialize g, i, i2
		@guardia = g
		@instruccion = i
		@instruccion2 = i2
	end
	def print_ast indent = ""
		puts "#{indent}Condicional If"
		indent = indent + "      "
		puts "#{indent}Guardia:"
		@guardia.print_ast indent + "      " if @guardia.respond_to? :print_ast
		puts "#{indent}Instruccion If:"
		@instruccion.print_ast indent + "      " if @instruccion.respond_to? :print_ast
		puts "#{indent}Instruccion Else:"
		@instruccion2.print_ast indent + "      " if @instruccion2.respond_to? :print_ast
	end
end

class IterWhile < AST
	def initialize g, i
		@guardia = g
		@instruccion = i
	end
	def print_ast indent = ""
		puts "#{indent}Iterador While"
		indent = indent + "      "
		puts "#{indent}Guardia:"
		@guardia.print_ast indent + "      " if @guardia.respond_to? :print_ast
		@instruccion.print_ast indent + "      " if @instruccion.respond_to? :print_ast
	end
end

class IterFor < AST
	def initialize i, d, h, ins
		@ident = i
		@desde = d
		@hasta = h
		@instruccion = ins
	end
	def print_ast indent = ""
		puts "#{indent}Iterador For"
		indent = indent + "      "
		puts "#{indent}Contador:"
		@ident.print_ast indent + "      " if @ident.respond_to? :print_ast
		puts "#{indent}Inicio:"
		@desde.print_ast indent + "      " if @desde.respond_to? :print_ast
		puts "#{indent}Fin:"
		@hasta.print_ast indent + "      " if @hasta.respond_to? :print_ast
		@instruccion.print_ast indent + "      " if @instruccion.respond_to? :print_ast
	end
end

class IterForBy < AST
	def initialize i, d, h, pp, ins
		@ident = i
		@desde = d
		@hasta = h
		@por = pp
		@instruccion = ins
	end
	def print_ast indent = ""
		puts "#{indent}Iterador For by"
		indent = indent + "      "
		puts "#{indent}Contador:"
		@ident.print_ast indent + "      " if @ident.respond_to? :print_ast
		puts "#{indent}Inicio:"
		@desde.print_ast indent + "      " if @desde.respond_to? :print_ast
		puts "#{indent}Fin:"
		@hasta.print_ast indent + "      " if @hasta.respond_to? :print_ast
		puts "#{indent}Cuanto:"
		@por.print_ast indent + "      " if @por.respond_to? :print_ast
		@instruccion.print_ast indent + "      " if @instruccion.respond_to? :print_ast
	end
end

class IterRepeat < AST
	def initialize v, ins
		@veces = v
		@instruccion = ins
	end
	def print_ast indent = ""
		puts "#{indent}Iterador Repeat"
		indent = indent + "      "
		puts "#{indent}Veces:"
		@veces.print_ast indent + "      " if @veces.respond_to? :print_ast
		@instruccion.print_ast indent + "      " if @instruccion.respond_to? :print_ast
	end
end

###Clases de Elementos Sintácticos de forma Binaria###

#Estas tienen 2 partes
class ExpresionBinaria < AST
	def initialize o1, o2
		@izquierda = o1 # Lado Izquierdo
		@derecha = o2 # Lado Direcho
	end
	def print_ast indent = "" 
		puts "#{indent}#{self.class}" #Se imprime el nombre de la clase, luego:
		puts "#{indent}    Lado izquierdo" #Se avisa el elemento sintáctico de cada lado
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast #Y se imprime el elemento
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end
end

class Suma < ExpresionBinaria; end
class Resta < ExpresionBinaria; end
class Multiplicacion < ExpresionBinaria; end
class Division < ExpresionBinaria; end
class Resto < ExpresionBinaria; end
class Conjuncion < ExpresionBinaria; end
class Disyuncion < ExpresionBinaria; end

class AsignacionParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}#{Asignacion}"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end
end

class DivisionEntera < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Division Entera"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end
end

class RestoEntero < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Resto Entero"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end
end

class IgualQueParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Igual Que"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end;
end;

class MayorQueParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Mayor Que"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end;
end;

class MenorQueParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Menor Que"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end;
end;

class DiferenteAParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Diferente Que"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end;
end;

class MayorIgualQueParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Mayor Igual Que"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end;
end;

class MenorIgualQueParser < ExpresionBinaria
	def print_ast indent = ""
		puts "#{indent}Menor Igual Que"
		puts "#{indent}    Lado izquierdo"
		@izquierda.print_ast indent + "      " if @izquierda.respond_to? :print_ast
		puts "#{indent}    Lado derecho"
		@derecha.print_ast indent + "      " if @derecha.respond_to? :print_ast
	end;
end;