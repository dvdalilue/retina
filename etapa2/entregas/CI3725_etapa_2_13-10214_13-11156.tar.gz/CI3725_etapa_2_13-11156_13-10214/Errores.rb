#! /usr/bin/ruby
# Universidad Simon Bolivar
# Trimestre Enero-Marzo 2017
# Traductores e Interpretadores [CI3725]
# Rafael Cisneros, 13-11156
# Miguel Canedo, 13-10214
# Proyecto, Errores

# Clase del Error Lexicografico
class LexicographError < Exception
	attr_reader :texto

	def initialize texto, fila, columna
		@texto = texto 	# Lo que se detecto al hacer match con alguna Expresion Regular
		@fila = fila	# Fila en el archivo donde se consiguio dicho Token
		@columna = columna # Columna en el archivo donde se consiguio dicho Token
	end

	def to_s #Salida especial del enunciado
    		"linea #{@fila}, columna #{@columna}: caracter inesperado '#{@texto}'"
 	end
end

# Clase que representa el primer Error Sintactico que se consiga.
class SyntacticError < RuntimeError
	# Constructor de la clase.
	def initialize(token)
		@token = token # Token que mando el error sintactico.
	end

	def to_s
		"linea #{@token.fila}, columna #{@token.columna}: token inesperado: #{@token.texto}"
	end
end

# Funcion que revisa si el archivo dado existe y si posee la extension requerida.
def comprobar_archivo(archivo)
	unless archivo =~ /\w+\.rtn/ # Chequeamos la extension del archivo de entrada
		abort("Extension del archivo desconocida")
	end

	unless File::exists?(archivo) # Chequeamos la existencia del archivo de entrada
		abort("Archivo no encontrado")
	end
end