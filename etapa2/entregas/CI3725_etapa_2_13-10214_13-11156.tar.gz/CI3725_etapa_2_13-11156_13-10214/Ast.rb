#! /usr/bin/ruby
# Universidad Simon Bolivar
# Trimestre Enero-Marzo 2017
# Traductores e Interpretadores [CI3725]
# Rafael Cisneros, 13-11156
# Miguel Canedo, 13-10214
# Proyecto, AST

# Clase generica que engloba a las clases participantes en el Arbol Sintactico
class AST

	# Metodo utilizado para imprimir de forma recursiva las clases pertenecientes al arbol
	def print_ast indent = ""
        	puts "#{indent}#{self.class}:"

	        attrs.each do |a|
	        	if a.is_a? Array
	        		a.each do |elem|
		        		elem.print_ast indent + "    " if elem.respond_to? :print_ast
		        	end
	        	else
	        		a.print_ast indent + "    "  if a.respond_to? :print_ast
	        	end
	        end
    	end

	# Metodo utilizado para acceder a los atributos de la clase
	def attrs
       		instance_variables.map do |a|
            		instance_variable_get a
        	end
    	end
end

# Clase engloba un programa completo, con sus bloques, instrucciones y funciones
class Programa < AST
	# Metodo para inicializar un programa definiendo las funciones y los bloques
	def initialize func, bloques
		@funciones = func
		@bloques = bloques
	end
end

# Clase utilizada para definir una nueva funcion dentro del programa
class Funcion
	# Metodo para inicializar una funcion definiendo su id, sus parametros, el tipo de valor retornado y las instrucciones
	def initialize id, param, tr, inst
		@idFuncion = id
		@parametros = param
		@tipoRetorno = tr
		@instrucciones = inst
	end

	def print_ast indent
		puts indent + "Funcion:\n" + indent + "    Nombre de la Funcion:"
		@idFuncion.print_ast indent + "        "

		if !@parametros.empty?
			puts indent + "    Parametros:"
			@parametros.each do |p|
				p.print_ast indent + "        "
			end
		end
		
		if @tipoRetorno != nil
			puts indent + "    Tipo del Valor retornado:"
			@tipoRetorno.print_ast indent + "        "
		end

		puts indent + "    Instrucciones:"
		@instrucciones.each do |i|
			i.print_ast indent + "        "
		end
	end
end

# Clase que representa una instruccion de return dentro de una funcion
class ReturnFuncion < AST
	# Metodo para inicializar la instruccion return en una funcion especificando la expresion a retornar
	def initialize exp
		@expresionRetorno = exp
	end

	def print_ast indent
		puts indent + "Retorno de Funcion: "
		@expresionRetorno.print_ast indent + "    "
	end
end 

# Clase que representa un entorno para un grupo variables e instrucciones
class Bloque < AST
	# Metodo para inicializar un entorno con declaraciones de variables e intrucciones
	def initialize decl, inst
		@declaraciones = decl
		@instrucciones = inst
	end

	def print_ast indent
		puts indent +"Bloque:\n" + indent + "    Declaraciones: "
		@declaraciones.each do |d|
			d.print_ast indent + "    " 
		end
		
		puts indent + "    Instrucciones: "
		@instrucciones.each do |i|
			i.print_ast indent + "        " 
		end
	end
end

# Clase que representa los valores que necesita una funcion para poder ejecutarse
class Parametro < AST
	# Metodo para inicializar un parametro indicando el tipo del parametro y el nombre usado para la variable
	def initialize tipo, id
		@tipo = tipo
		@variable = id
	end
end

# Clase que representa la declaracion de una variable dentro del bloque
class Declaracion < AST
	# Metodo para inicializar una declaracion para una variable
	def initialize tipo, id, expresion
		@tipo = tipo
		@variable = id
		@valor = expresion
	end

	def print_ast indent
		puts indent + "Declaracion:\n" + indent + "    Tipo:"
		@tipo.print_ast indent + "        "

		puts indent + "    Variable:"
		@variable.print_ast indent + "        "

		if @valor != nil
			puts indent + "    Valor:"
			@valor.print_ast indent + "        "
		end
	end
end

# Clase que representa una asignacion a una variable
class Asignacion < AST
	# Metodo para inicializar la asignacion de un valor para una variable una dada
	def initialize id, valor
		@variable = id
		@valor = valor
	end
end

# Clase que representa un control de flujo
class Condicional < AST
	# Metodo para inicializar un grupo de instrucciones dada una condicion para su ejecucion	
	def initialize cond, inst1, inst2
		@condicion = cond
		@instrucciones = inst1
		@instruccionesElse = inst2
	end

	def print_ast indent
		puts indent + "Condicional:\n" + indent + "    Condicion:"
		@condicion.print_ast indent + "        "

		puts indent + "    Instrucciones:"
		@instrucciones.each do |i|
			i.print_ast indent + "        "
		end

		if !@instruccionesElse.empty?
			puts indent + "    Instrucciones en Caso Contrario:"
			@instruccionesElse.each do |i|
				i.print_ast indent + "        "
			end			
		end
	end
end

# Clase que representa un ciclo indeterminado de instrucciones (while)
class IteracionIndeterminada < AST
	# Metodo para inicializar un ciclo while de instrucciones dada una condicion para su ejecucion
	def initialize cond, inst
		@condicion = cond
		@instrucciones = inst
	end

	def print_ast indent
		puts indent + "While:\n" + indent + "    Condicion:"
		@condicion.print_ast indent + "        "

		puts indent + "    Instrucciones:"
		@instrucciones.each do |i|
			i.print_ast indent + "        "
		end
	end
end

# Clase que representa un ciclo determinado de instrucciones (for)
class IteracionDeterminada < AST
	# Metodo para inicializar un ciclo determinado de instrucciones dada una variable de iteracion, su rango de accion y su taza de incremento
	def initialize id, ini, fin, aum, inst
		@iterador = id
		@inicioRango = ini
		@finRango = fin
		@incremento = aum
		@instrucciones = inst
	end

	def print_ast indent
		puts indent + "For:\n" + indent + "    Iterador:"
		@iterador.print_ast indent + "        " 
			
		puts indent + "    Inicio del Rango:"
		@inicioRango.print_ast indent + "        "

		puts indent + "    Fin del Rango:"
		@finRango.print_ast indent + "        "
	
		if @incremento != nil
			puts indent + "    Incremento:"
			@incremento.print_ast indent + "        "
		end

		puts indent + "    Instrucciones:"
		@instrucciones.each do |i|
			i.print_ast indent + "        "
		end
	end
end

# Clase que representa un caso especial de iteraciones determinadas(repeat)
class IteracionRepeat < AST
	# Metodo para inicializar un ciclo repeat dadas las instrucciones y la cantidad de veces a repetir el ciclo
	def initialize v, inst
		@veces = v
		@instrucciones = inst
	end

	def print_ast indent
		puts indent + "Repeat:\n" + indent + "    Cantidad de Iteraciones:"
		@veces.print_ast indent + "        "


		puts indent + "    " + "Instrucciones:\n"

		@instrucciones.each do |i|
			i.print_ast indent + "        "
		end
	end
end

# Clase que representa una llamada a una funcion previamente definida en el programa
class LlamadaFuncion < AST
	# Metodo para inicializar una llamada a una funcion con identificador idf y los parametros especificados
	def initialize idf, param
		@idFuncion = idf
		@parametros = param
	end

	def print_ast indent
		puts indent + "LLamada a Funcion:\n"  + indent + "    " + "Nombre funcion:"
		@idFuncion.print_ast indent + "        " 

		puts indent + "    Parametros:\n"

		@parametros.each do |p|
			puts indent + "        Parametro:"
			p.print_ast indent + "            "
		end
	end
end

# Clase para representar la instruccion de salida sin salto
class Salida < AST
	# Metodo para inicializar una instruccion de salida dado un elemento
	def initialize elem
		@elemento = elem
	end
end

# Clase para representar la instruccion de salida con salto
class SalidaSalto < Salida
end

# Clase que representa la asignacion de un valor a una variable dada una entrada
class Entrada < AST
	# Metodo para inicializar un instruccion de entrada
	def initialize id
		@variable = id
	end	
end

# Clase que representa los numeros dentro del lenguaje
class Numero < AST
	# Metodo que inicializa un numero con un valor dado
	def initialize v
		@valor = v
	end

	def print_ast indent
		puts indent + "Valor Numerico: #{@valor.texto}"
	end
end

# Clase que representa los valores booleanos dentro del lenguaje
class Booleano < AST
	# Metodo para inicializar un valor booleano
	def initialize v
		@valor = v
	end

	def print_ast indent
		puts indent + "Valor Booleano: #{@valor.texto}"
	end
end

# Clase que representa una cadena de caracteres para ser utilizada en una instruccion de salida
class String
	# Metodo que define los caracteres que conforman la cadena
	def initialize c
		@cadena = c
	end

	def print_ast indent
		puts indent + "Cadena de Caracteres: #{@cadena.texto}"
	end
end

# Clase que representa los tipo de valores para variables que pueden ser usadas en el lenguaje
class Tipo < AST
	# Metodo para inicializar un tipo de variable para un nombre dado (number/boolean)
	def initialize n
		@nombre = n
	end

	def print_ast indent
		puts indent + "Tipo:\n" + indent + "    Nombre: #{@nombre.texto}"
	end
end

# Clase que representa los ids que pueden tener las variables y las funciones dentro de un programa
class Identificador < AST
	# Metodo para inicializar un identificador con un nombre dado
	def initialize n
		@nombre = n
	end

	def print_ast indent
		puts indent + "Identificador:\n" + indent +"    Nombre: #{@nombre.texto}"
	end
end

# Clase que engloba a los operadores que requieren de un solo operando para ejecutarse
class OpUnario < AST
	# Metodo para inicializar un operador unario dado operando
	def initialize op
		@operando = op 
	end

	def print_ast indent
		puts indent + "#{self.class.name}:\n" + indent + "    Operando: "
		@operando.print_ast indent + "        "
	end
end

# Clase para representar el operador booleano "not"
class Not < OpUnario

end

# Clase para representar el operador numerico "-"
class Negativo < OpUnario
end

# Clase que engloba a los operadores que requieren de dos operandos para su ejecucion
class OpBinario < AST
	# Metodo para inicializar un operador binario dado sus operandos
	def initialize opl, opr
		@opIzquierda = opl
		@opDerecha = opr
	end

	def print_ast indent
		puts indent + "#{self.class.name}:\n" 
		
		puts indent + "    Operando Izquierdo:"
		@opIzquierda.print_ast indent + "        "
		
		puts indent + "    Operando Derecho:"
		@opDerecha.print_ast indent + "        "
	end
end

# Clase para representar la operacion de adicion de numeros
class Suma < OpBinario
end

# Clase para representar la operacion de sustraccion de numeros
class Resta < OpBinario
end

# Clase para representar la operacion de multiplicacion de numeros
class Multiplicacion < OpBinario
	
end

# Clase para representar la operacion de division de numeros
class Division < OpBinario
end

# Clase para representar la operacion para calcular el resto de una division de numeros
class Modulo < OpBinario
end

# Clase para representar la operacion de division de numeros con resultado entero
class DivisionEntera < OpBinario
end

# Clase para representar la operacion para calcular el resto entero de una division de numeros
class ModuloEntero < OpBinario
end

# Clase para representar la operacion booleana de conjuncion
class And < OpBinario
end

# Clase para representar la operacion booleana de disyuncion
class Or < OpBinario
end

# Clase para representar la operacion de comparacion de igualdad
class Igual < OpBinario
end

# Clase para representar la operacion de comparacion de desigualdad
class Diferente < OpBinario
end

# Clase para representar la operacion de comparacion de "menor estricto que"
class MenorQue < OpBinario
end

# Clase para representar la operacion de comparacion de "mayor estricto que"
class MayorQue < OpBinario
end

# Clase para representar la operacion de comparacion de "menor o igual que"
class MenorIgualQue < OpBinario
end

# Clase para representar la operacion de comparacion de "mayor o igual que"
class MayorIgualQue < OpBinario
end
