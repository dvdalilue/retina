UNIVERSIDAD SIMÓN BOLÍVAR
CI3725-RETINA
Archivo: README 
Contenido:
Archivo de texto que ayuda a comprender la 2da entrega.
Creado por:
    Melanie Gomes, 13-10544
    Veronica Mazutiel, 13-10853

Incluye:
    retina_parser.y
    retina_parser.rb
    retina_lexer.rb
    retina_AST.rb
    retina

SYNOPSIS: chmod +x retina
	  retina <archivo de entrada>

*Ya el archivo retina_parser.y se encuentra compilado

ESTADO DE LA ENTREGA

Esta entrega del proyecto es capaz de reconocer e imprimir el árbol sintáctico abstracto de un programa presente en un archivo para casi todas las Gramáticas
del lenguaje Retina. 
Sin embargo,existen gramáticas que se nos dificultó desarrollar y que no pudimos completar para esta entrega estas son:

- Reconocer declaraciones seguidas por un ; dentro de una bloque with.
- Reconocer lista de atributos de entrada al definir una funcion. Sólo reconoce el primer atributo.
- Reconocer Returns dentro de una función.
- Problemas al hacer llamadas a funciones en un bloque de varias instrucciones.

DIFICULTADES: Se nos hizo un poco engorroso hacer este proyecto dada la poca documentación que existe sobre la herramienta utilizada para el parser de ruby: racc. La poca que hay no es muy buena tampoco.

