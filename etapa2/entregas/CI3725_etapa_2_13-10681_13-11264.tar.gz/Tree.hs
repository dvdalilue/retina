-- Carlos Infante 13-10681
-- Rubmary Rojas 13-11264
-- Tipo de Dato Tree TypeNodo, para manejar el arbol generado por
-- el analizador lexicografico

module Tree where
import Data.Tree
import Lexer
import System.IO
import System.Environment
import TokenInfo

-- Tipo de data del arbol "TypeNode"
data TypeNode = Init    |
                Funs    |
                Is      |
                Exp     |
                Type    |
                Dec     |
                Ds      |
                Assig   |
                Read    |
                Write   |
                WriteL  |
                Prints  |
                DFun    |
                DFunR   |
                Pars    |
                Ps      |
                Par     |
                Do      |
                If      |
                IfElse  |
                While   |
                For     |
                ForBy   |
                Repeat  |
                ExpS    |
                FCall   |
                Ret     |
                Empty   |
                IsToken Token
              
-- Instancia de la funcion mostrara para TypeNode
instance Show TypeNode where
    show Init     = "Inicio de programa:"
    show Funs     = "Funciones:"
    show Is       = "Instrucciones:"
    show Exp      = "Expresión:"
    show Dec      = "Declaración:"
    show Ds       = "Declaraciones:"
    show Assig    = "Asignación:"
    show Read     = "Leer entrada:"
    show Write    = "Salida:"
    show WriteL   = "Salida con salto:"
    show Prints   = "Strings:"
    show DFun     = "Función:"
    show DFunR    = "Función con tipo de retorno:"
    show Pars     = "Argumentos:"
    show Par      = "Argumento:"
    show Do       = "With Do:"
    show If       = "If:"
    show IfElse   = "If Else:"
    show While    = "While:"
    show For      = "For:"
    show ForBy    = "For By:"
    show Repeat   = "Repeat:"
    show ExpS     = "Expresiones:"
    show FCall    = "Llamada a función:"
    show Ret      = "Retorno de función:"
    show Empty    = "Vacía"
    show (IsToken t) = show_val t

-- Obtener los hijos de un arbol
children :: Tree a -> Forest a
children (Node x f) = f

-- Obtener el tipo de un arbol
getType :: (Show a) => Tree a -> String
getType (Node x _) = show x
 
 
-- Imprimir el arbol generado
printTree :: Int -> Tree TypeNode -> IO()
printTree h tree = do
  let tab = take (3*h) (repeat ' ')
  putStrLn $ tab ++ (getType tree)
  let child = children tree
  case (length child == 0) of
      False  ->  do  mapM_  (printTree (h+1))  (children tree)
      True   ->  do  return ()
      

