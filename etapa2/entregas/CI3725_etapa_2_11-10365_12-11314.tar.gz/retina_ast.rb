# Clases que asisten en la produccion del arbol sintactico 
# abstracto en "retina"
#
# calculator_ast.rb fue utilizado como base.
#
# Autores: 	Jonathan Reyes 	(12-11314)
# 			Rosana Garcia	(11-10365)
#

class AST
	def print_ast(indent="")
        puts("#{indent}#{self.class}:")

        attrs.each do |a|
            a.print_ast indent + "  " if a.respond_to? :print_ast
        end
    end

    def attrs
        instance_variables.map do |a|
            instance_variable_get(a)
        end
    end
end

#######################################################
################### Generic Classes ###################
#######################################################

class Type < AST
	attr_accessor :datatype

	def initialize(datatype)
		@datatype = datatype
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}: #{@datatype.item}")
	end
end

#######################################################

class UnaryOperator < AST
    attr_accessor :operand

    def initialize(operand)
        @operand = operand
    end
end

#######################################################

class BinaryOperator < AST
    attr_accessor :left, :right

    def initialize(lh, rh)
        @left = lh
        @right = rh
    end
end

#######################################################

class List < AST
	attr_accessor :list 

	def initialize
		@list = []
	end

	def add(item)
		@list += [item]
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}:")
		@list.each { |l| l.print_ast(indent + "  ") }
	end
end

#####################################################
################ Base Token Classes #################
#####################################################

class CharString < AST
	def initialize(s)
		@charArray = s
	end

	def print_ast(indent="")
		puts("#{indent}String: #{@charArray.item}")
	end
end

######################################################

class Number < AST
    attr_accessor :digit

    def initialize(d) 
        @digit = d
    end

    def print_ast(indent="")
        puts("#{indent}#{self.class}: #{@digit.to_i}")
    end
end

######################################################

class Boolean < AST
	attr_accessor :boole

	def initialize(b)
		@boole = b
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}: #{@boole.item}")
	end
end

######################################################

class Identifier < AST
	attr_accessor :identifier

	def initialize(i)
		@identifier = i
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}: #{@identifier.item}")
	end
end

#########################################################
################## Reserved Structures ##################
#########################################################

class ProgramBlock < AST
	attr_accessor :block 

	def initialize(block)
		@block = block
	end
end

#######################################################

class Block < AST
	attr_accessor :declarations, :instructions

	def initialize(declarations,instructions)
		@declarations = declarations
		@instructions = instructions
	end
end

#######################################################

class Declaration < AST
	attr_accessor :datatype, :tag, :data

	def initialize(datatype, tag, data)
		@datatype = datatype
		@tag = tag
		@data = data
	end
end

#######################################################

class FunctionDeclare < AST
	attr_accessor :tag, :arguments, :returntype, :instructions

	def initialize(tag, arguments, returntype, instructions)
		@tag = tag
		@arguments = arguments
		@returntype = returntype
		@instructions = instructions
	end
end

#######################################################

class FunctionCall < AST
	attr_accessor :tag, :parameters

	def initialize(tag, parameters)
		@tag = tag
		@parameters = parameters
	end
end

#######################################################

class RepeatCall < AST
	attr_accessor :times, :instructions

	def initialize(times, instructions)
		@times = times
		@instructions = instructions
	end
end

#######################################################

class ForCall < AST
	attr_accessor :iterator, :start, :finish, :factor, :instructions

	def initialize(iterator, start, finish, factor, instructions)
		@iterator = iterator
		@start = start
		@finish = finish
		@factor = factor
		@instructions = instructions		
	end
end

#######################################################

class WhileCall < AST
	attr_accessor :condition, :instructions

	def initialize(condition, instructions)
		@condition = condition
		@instructions = instructions
	end
end

#######################################################

class IfThen < AST
	attr_accessor :condition, :instructions

	def initialize(condition, instructions)
		@condition = condition
		@instructions = instructions
	end
end

#######################################################

class IfElse < AST
	attr_accessor :condition, :ifInstructions, :elseInstructions

	def initialize(condition, instructions1, instructions2)
		@condition = condition
		@ifInstructions = instructions1
		@elseInstructions = instructions2
	end
end

############################################################
################## Mass Declarations #######################
############################################################

#Lists
class ArgumentList < List; end
class DeclarationList < List; end
class InstructionList < List; end
class Parameters < List; end

#Aritmethic Operators
class UnaryMinus < UnaryOperator; end
class Addition < BinaryOperator; end
class Substraction < BinaryOperator; end
class Multiplication < BinaryOperator; end
class WholeDivision < BinaryOperator; end
class Modulus < BinaryOperator; end
class ExactDivision < BinaryOperator; end 
class ExactModulus < BinaryOperator; end

#Logic Operators
class NegationOp < UnaryOperator; end
class Conjunction < BinaryOperator; end
class Disjunction < BinaryOperator; end

#Relational Operators
class Equivalence < BinaryOperator; end
class Difference < BinaryOperator; end
class EqualGreaterThan < BinaryOperator; end
class EqualLessThan < BinaryOperator; end
class LessThan < BinaryOperator; end
class GreaterThan < BinaryOperator; end

#Assignment Operators
class Assign < BinaryOperator; end
class Argument < UnaryOperator; end
class In < UnaryOperator; end
class Out < UnaryOperator; end
class OutAndLine < UnaryOperator; end
class Expression < UnaryOperator; end
class Condition < UnaryOperator; end

