class AST
    def print_ast indent=""
        puts "#{indent}#{self.class}:"

        attrs.each do |a|
            a.print_ast indent + "  " if a.respond_to? :print_ast
        end
    end

    def attrs
        instance_variables.map do |a|
            instance_variable_get a
        end
    end
end

###################################

class NumeroNode < AST
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}#{self.class}: #{@digit.to_i}"
    end
end

class ArithmeticUnOP < AST
    attr_accessor :operand

    def initialize operand
        @operand = operand
    end
end

class ArithmeticBinOP < AST
    attr_accessor :left, :right

    def initialize lh, rh
        @left = lh
        @right = rh
    end
end

class TrueNode < AST
    attr_accessor :true

    def initialize t 
        @true = t
    end

    def print_ast indent=""
        puts "#{indent}#{self.class}: #{@true.to_i}"
    end
end

class FalseNode < AST
    attr_accessor :false

    def initialize f 
        @false = f
    end

    def print_ast indent=""
        puts "#{indent}#{self.class}: #{@false.to_i}"
    end
end

class VariableNode < AST
    attr_accessor :id

    def initialize i 
        @id = i
    end

    def print_ast indent=""
        puts "#{indent}#{self.class}: #{@id.to_i}"
    end
end

class AsignacionNode < AST
    attr_accessor :ide, :exp

    def initialize i, e
        @ide = i
        @exp = exp
    end
    def print_ast indent=""
        puts "#{indent}#{self.class}: #{@ide.to_i} '=' #{@exp.to_i}"
    end
end

class BeginNode < AST
    attr_accessor :dec, :ins

    def initialize d, i
        @dec = d
        @ins = i
    end
end

class ReadNode < AST
    attr_accessor :read, :ide

    def initialize r, i
        @read = r
        @ide = i
    end
end

class WriteExpNode < AST
    attr_accessor :exp

    def initialize e
        @exp = e
    end
end

class WriteVarNode < AST
    attr_accessor :var

    def initialize vr
        @var = vr
    end
end

class WritelnExpNode < AST
    attr_accessor :exp

    def initialize e
        @exp = e
    end
end

class WritelnVarNode < AST
    attr_accessor :var

    def initialize vr
        @var = vr
    end
end

class ForwardNode < AST
    attr_accessor :iden

    def initialize id
        @iden = id
    end
end

class BackwardNode < AST
    attr_accessor :iden

    def initialize id
        @iden = id
    end
end

class RotaterNode < AST
    attr_accessor :iden

    def initialize id
        @iden = id
    end
end

class RotatelNode < AST
    attr_accessor :iden

    def initialize id
        @iden = id
    end
end

class SetPositionNode < AST
    attr_accessor :ide1, :ide2

    def initialize id1, id2
        @ide1 = id1;
        @ide2 = id2;
    end
end

class ArcNode < AST
    attr_accessor :ide1, :ide2

    def initialize id1, id2
        @ide1 = id1;
        @ide2 = id2;
    end
end

class IfNode < AST
    attr_accessor :exp, :ins

    def initialize e, i
        @exp = e;
        @ins = i;
    end
end

class ElseNode < AST
    attr_accessor :exp, :ins, :ins1

    def initialize e, i, i1
        @exp = e;
        @ins = i;
        @ins1 = i1;
    end
end

class ForNode < AST
    attr_accessor :var1, :exp1, :expr2, :var2

    def initialize v1, e1, v2, e2
        @var1 = v1;
        @exp1 = e1;
        @var2 = v2;
        @exp2 = e2;
    end
end

class WhileNode < AST
    attr_accessor :exp, :ins

    def initialize e, i
        @exp = e;
        @ins = i;
        
    end
end

class RepeatNode < AST
    attr_accessor :id

    def initialize id
        @id = id;
        
    end
end


class LDeclaracionesNode < AST
    attr_accessor :dec

    def initialize dec
        @dec = dec;
    end
end

class DeclaracionesIdNode < AST
    attr_accessor :id

    def initialize id
        @id = id;
    end
end

class DeclaracionesIdIdNode < AST
    attr_accessor :id1, :id2

    def initialize id1, id2
        @id1 = id1;
        @id2 = id2;
    end
end

class WithNode < AST
    attr_accessor :dec, :ins

    def initialize d, i
        @dec = d;
        @ins = i;
    end
end

class DoNode < AST
    attr_accessor :ins

    def initialize i
        @ins = i;
    end
end

class WithBloqueNode < AST
    attr_accessor :dec, :blo

    def initialize dc, bl
        @dec = dc;
        @blo = bl;
    end
end

class DoBloqueNode < AST
    attr_accessor :blo

    def initialize bl
        @blo = bl;
    end
end

class FuncionNode < AST
    attr_accessor :id, :var, :var1

    def initialize i, vr, vr1
        @id = i;
        @var = vr;
        @var1 = vr1;
    end
end

class FuncionFNode < AST
    attr_accessor :id, :var, :var1

    def initialize i, vr, vr1
        @id = i;
        @var = vr;
        @var1 = vr1;
    end
end

class MenosUnarioNode < ArithmeticUnOP;end
class NotNode < ArithmeticUnOP;end
class MasNode < ArithmeticBinOP;end
class RestaNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class AsteriscoNode < ArithmeticBinOP;end
class DivisionNode < ArithmeticBinOP;end
class DesigualdadNode < ArithmeticBinOP;end
class MenorQueNode < ArithmeticBinOP;end
class MenorIgualQueNode < ArithmeticBinOP;end
class IgualNode < ArithmeticBinOP;end
class MayorQueNode < ArithmeticBinOP;end
class MayorIgualQueNode < ArithmeticBinOP;end
class AndoNode < ArithmeticBinOP;end
class OrNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class ModuloNode < ArithmeticBinOP;end
class Division < ArithmeticBinOP;end
