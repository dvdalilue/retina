require_relative 'Lexer.rb'

begin

    tokens = Lexer.new(ARGV[0])
    parser = Parser.new(tokens)
    ast = parser.parse
    ast.check()
    ast.eval
    if not tokens.hasErrors then 
        puts tokens.tokensList
    end
end