class AST
    def print_ast indent=""
        puts "#{indent}#{self.class}:"

        attrs.each do |a|
            a.print_ast indent + "  " if a.respond_to? :print_ast
        end
    end

    def attrs
        instance_variables.map do |a|
            instance_variable_get a
        end
    end
end

class Number2 < AST
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Numero: #{@digit.id}"
    end
end

class Bool < AST
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Booleano: #{@digit.id}"
    end
end

class ArithmeticUnOP < AST
    attr_accessor :operand

    def initialize operand
        @operand = operand
    end
end

class ArithmeticBinOP < AST
    attr_accessor :left, :right

    def initialize lh, rh
        @left = lh
        @right = rh
    end
end

class I_Tipo
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Tipo:\n#{indent}  nombre: #{@digit.id}"
    end
end

class I_String
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}String:\n#{indent}  nombre: #{@digit.id}"
    end
end

class I_Identificador
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Identificador:\n#{indent}  nombre: #{@digit.id}"
    end
end

class Reserva_Expresiones
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Expresion: "
        @digit.print_ast indent + "    " if @digit.respond_to? :print_ast
    end
end


class I_Imprimible
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==Reserva_Expresiones || a.class==Reserva_String )
            @l.push a
        else 
            a.l.each do |f|
                @l.push f
            end
        end
        if (b.class==Reserva_Expresiones || b.class==Reserva_String)
            @l.push b
        else
            b.l.each do |f|
                @l.push f
            end
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista de Imprimibles: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end

class Reserva_String
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}String: "
        @digit.print_ast indent + "    " if @digit.respond_to? :print_ast
    end
end

class I_Expresiones
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==Reserva_Expresiones || a.class==Reserva_String )
            @l.push a
        else 
            a.l.each do |f|
                @l.push f
            end
        end
        if (b.class==Reserva_Expresiones || b.class==Reserva_String)
            @l.push b
        else
            b.l.each do |f|
                @l.push f
            end
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end




class I_Uso_funciones1
    attr_accessor :inden

    def initialize a
        @iden=a
    end

    def print_ast indent=""
        puts "#{indent}Llamado a funcion sin parametros: "
        puts "#{indent}  identificacion: "
        @iden.print_ast indent + "      " if @iden.respond_to? :print_ast
    end 
end

class I_Uso_funciones2 
    attr_accessor :inden, :expre

    def initialize (a,b)
        @iden=a
        @expre=b
    end

    def print_ast indent=""
        puts "#{indent}Llamado a funcion con parametros: "
        puts "#{indent}  identificacion: "
        @iden.print_ast indent + "      " if @iden.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @expre.print_ast indent + "      " if @iden.respond_to? :print_ast
    end 
end
class Reserva_Parametros
    attr_accessor :tipo, :ident

    def initialize (a,b) 
        @tipo = a
        @ident= b
    end

    def print_ast indent=""
        puts "#{indent}Parametros: "
        @tipo.print_ast indent + "    " if @tipo.respond_to? :print_ast
        @ident.print_ast indent + "    " if @ident.respond_to? :print_ast
    end
end
class I_Parametros
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==Reserva_Parametros)
            @l.push a
        else 
            a.l.each do |f|
                @l.push f
            end
        end
        if (b.class==Reserva_Parametros)
            @l.push b
        else
            b.l.each do |f|
                @l.push f
            end
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista de Parametros: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end
class L_Identificadores
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==I_Identificador)
            @l.push a
        else 
            a.l.each do |f|
                @l.push f
            end
        end
        if (b.class==I_Identificador)
            @l.push b
        else
            b.l.each do |f|
                @l.push f
            end
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista de Identificadores: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end

class Reserva_Instrucciones 
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Instruccion: "
        @digit.print_ast indent + "    " if @digit.respond_to? :print_ast
    end
end

class I_Instrucciones
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==Reserva_Instrucciones)
            @l.push a
        else 
            a.l.each do |f|
                @l.push f
            end
        end
        if (b.class==Reserva_Instrucciones)
            @l.push b
        else
            b.l.each do |f|
                @l.push f
            end
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista de Instrucciones: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end

class I_Asignacion1
    attr_accessor :var, :val

    def initialize (a,b) 
        @var = a
        @val = b
    end

    def print_ast indent=""
        puts "#{indent}Asignacion: "
        puts "#{indent}  identificador: "
        @var.print_ast indent + "      " if @var.respond_to? :print_ast
        puts "#{indent}  valor: "
        @val.print_ast indent + "      " if @val.respond_to? :print_ast
    end
end

class I_Asignacion2
    attr_accessor :var, :val, :tipo

    def initialize (a,b) 
        @tipo= a
        @var = b.var
        @val = b.val
    end

    def print_ast indent=""
        puts "#{indent}Asignacion con declaracion: "
        puts "#{indent}  tipo: "
        @tipo.print_ast indent + "      " if @tipo.respond_to? :print_ast
        puts "#{indent}  identificador: "
        @var.print_ast indent + "      " if @var.respond_to? :print_ast
        puts "#{indent}  valor: "
        @val.print_ast indent + "      " if @val.respond_to? :print_ast
    end
end

class I_D_funciones1
    attr_accessor :ident, :param, :inst, :ret

    def initialize (a,b,c,d) 
        @ident= a
        @param = b
        @inst = c
        @ret=d
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @param.print_ast indent + "      " if @param.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones2
    attr_accessor :ident, :inst, :ret

    def initialize (a,c,b) 
        @ident= a
        @inst = c
        @ret=b
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones4
    attr_accessor :ident, :param, :inst, :v, :ret

    def initialize (a,b,c,d,e) 
        @ident= a
        @param = b
        @v=c
        @inst = d
        @ret=e
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @param.print_ast indent + "      " if @param.respond_to? :print_ast
        puts "#{indent}  tipo de retorno: "
        @v.print_ast indent + "      " if @v.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones5
    attr_accessor :ident, :inst, :v, :ret

    def initialize (a,b,c,d) 
        @ident= a
        @v=b
        @inst = c
        @ret=d
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  tipo de retorno: "
        @v.print_ast indent + "      " if @v.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones6
    attr_accessor :ident, :param, :ret

    def initialize (a,b,c) 
        @ident= a
        @param = b
        @ret = c
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @param.print_ast indent + "      " if @param.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones7
    attr_accessor :ident, :ret

    def initialize (a,b) 
        @ident= a
        @ret = b
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones8
    attr_accessor :ident, :param, :v, :ret

    def initialize (a,b,c,d) 
        @ident= a
        @param = b
        @v=c
        @ret=d
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @param.print_ast indent + "      " if @param.respond_to? :print_ast
        puts "#{indent}  tipo de retorno: "
        @v.print_ast indent + "      " if @v.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones9
    attr_accessor :ident, :v, :ret

    def initialize (a,b,d) 
        @ident= a
        @v=b
        @ret=d
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  tipo de retorno: "
        @v.print_ast indent + "      " if @v.respond_to? :print_ast
        puts "#{indent}  retorno: "
        @ret.print_ast indent + "      " if @ret.respond_to? :print_ast
    end
end

class I_D_funciones10
    attr_accessor :ident, :param, :inst

    def initialize (a,b,c) 
        @ident= a
        @param = b
        @inst = c
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @param.print_ast indent + "      " if @param.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_D_funciones11
    attr_accessor :ident, :inst

    def initialize (a,c) 
        @ident= a
        @inst = c
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_D_funciones12
    attr_accessor :ident, :param, :inst, :v

    def initialize (a,b,c,d) 
        @ident= a
        @param = b
        @v=c
        @inst = d
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  parametros: "
        @param.print_ast indent + "      " if @param.respond_to? :print_ast
        puts "#{indent}  tipo de retorno: "
        @v.print_ast indent + "      " if @v.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_D_funciones13
    attr_accessor :ident, :inst, :v

    def initialize (a,b,c) 
        @ident= a
        @v=b
        @inst = c
    end

    def print_ast indent=""
        puts "#{indent}Declaracion de funcion: "
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  tipo de retorno: "
        @v.print_ast indent + "      " if @v.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_D_funciones3
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==I_D_funciones3)
            a.l.each do |f|
                @l.push f
            end
        else 
            @l.push a
        end
        if (b.class==I_D_funciones3)
            b.l.each do |f|
                @l.push f
            end
        else
            @l.push b
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista de Declaraciones de Funciones: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end

class I_Iteracion_1
    attr_accessor :exp1, :exp2, :exp3,:inst, :ident

    def initialize (d,a,b,c,e) 
        @exp1= a
        @exp2= b
        @exp3= c
        @ident= d
        @inst= e
    end

    def print_ast indent=""
        puts "#{indent}Iteracion determinada: "
        puts "#{indent}  variable: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  desde: "
        @exp1.print_ast indent + "      " if @exp1.respond_to? :print_ast
        puts "#{indent}  hasta: "
        @exp2.print_ast indent + "      " if @exp2.respond_to? :print_ast
        puts "#{indent}  periodo: "
        @exp3.print_ast indent + "      " if @exp3.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Iteracion_2
    attr_accessor :exp1, :exp2,:inst, :ident

    def initialize (d,a,b,e) 
        @exp1= a
        @exp2= b
        @ident= d
        @inst= e
    end

    def print_ast indent=""
        puts "#{indent}Iteracion determinada: "
        puts "#{indent}  variable: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
        puts "#{indent}  desde: "
        @exp1.print_ast indent + "      " if @exp1.respond_to? :print_ast
        puts "#{indent}  hasta: "
        @exp2.print_ast indent + "      " if @exp2.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Iteracion_3
    attr_accessor :exp, :inst

    def initialize (a,b) 
        @exp= a
        @inst= b
    end

    def print_ast indent=""
        puts "#{indent}Iteracion determinada: "
        puts "#{indent}  numero de repeticiones: "
        @exp.print_ast indent + "      " if @exp.respond_to? :print_ast
        puts "#{indent} instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Iteracion_4
    attr_accessor :exp, :inst

    def initialize (a,b) 
        @exp= a
        @inst= b
    end

    def print_ast indent=""
        puts "#{indent}Iteracion indeterminada: "
        puts "#{indent}  determinador: "
        @exp.print_ast indent + "      " if @exp.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Condicional_1
    attr_accessor :exp, :inst

    def initialize (a,b) 
        @exp= a
        @inst= b
    end

    def print_ast indent=""
        puts "#{indent}Condicional: "
        puts "#{indent}  condicion: "
        @exp.print_ast indent + "      " if @exp.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Condicional_2
    attr_accessor :exp, :inst1 , :inst2

    def initialize (a,b,c) 
        @exp= a
        @inst1= b
        @inst2=c
    end

    def print_ast indent=""
        puts "#{indent}Condicional: "
        puts "#{indent}  condicion: "
        @exp.print_ast indent + "      " if @exp.respond_to? :print_ast
        puts "#{indent}  instrucciones si se cumple la condicion: "
        @inst1.print_ast indent + "      " if @inst1.respond_to? :print_ast
        puts "#{indent}  instrucciones si no se cumple la condicion: "
        @inst2.print_ast indent + "      " if @inst2.respond_to? :print_ast
    end
end

class Reserva_Declaracion 
    attr_accessor :tipo, :ident

    def initialize (a,b) 
        @tipo = a
        @ident= b
    end

    def print_ast indent=""
        puts "#{indent}Declaracion: "
        puts "#{indent}  tipo: "
        @tipo.print_ast indent + "      " if @tipo.respond_to? :print_ast
        puts "#{indent}  identificador: "
        @ident.print_ast indent + "      " if @ident.respond_to? :print_ast
    end
end
class I_Declaracion
    attr_accessor :l

    def initialize (a, b)
        @l=[]
        if (a.class==Reserva_Declaracion || a.class==I_Asignacion2)
            @l.push a
        else 
            a.l.each do |f|
                @l.push f
            end
        end
        if (b.class==Reserva_Declaracion || b.class==I_Asignacion2)
            @l.push b
        else
            b.l.each do |f|
                @l.push f
            end
        end
    end

    def print_ast indent=""
        puts "#{indent}Lista de Declaraciones: "
        @l.each do |a|
            a.print_ast indent + "    " if a.respond_to? :print_ast
        end
    end
end

class I_Bloque_1 
    attr_accessor :decla, :inst

    def initialize (a,b) 
        @decla= a
        @inst= b
    end

    def print_ast indent=""
        puts "#{indent}Bloque: "
        puts "#{indent}  declaraciones: "
        @decla.print_ast indent + "      " if @decla.respond_to? :print_ast
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Bloque_2
    attr_accessor :inst

    def initialize (a) 
        @inst= a
    end

    def print_ast indent=""
        puts "#{indent}Bloque: "
        puts "#{indent}  instrucciones: "
        @inst.print_ast indent + "      " if @inst.respond_to? :print_ast
    end
end

class I_Program
    attr_accessor :bloque

    def initialize (a) 
        @bloque= a
    end

    def print_ast indent=""
        puts "#{indent}Programa: "
        puts "#{indent}  bloque de Instrucciones: "
        @bloque.print_ast indent + "      " if @bloque.respond_to? :print_ast
    end
end

class I_Salida
    attr_accessor :exp

    def initialize (a) 
        @exp= a
    end

    def print_ast indent=""
        puts "#{indent}Instruccion de salida: "
        puts "#{indent}  expresiones a imprimir: "
        @exp.print_ast indent + "      " if @exp.respond_to? :print_ast
    end
end

class I_Entrada
    attr_accessor :exp

    def initialize (a) 
        @exp= a
    end

    def print_ast indent=""
        puts "#{indent}Instruccion de Entrada: "
        @exp.print_ast indent + "    " if @exp.respond_to? :print_ast
    end
end

class I_func_prog 
    attr_accessor :decla, :pr

    def initialize (a,b) 
        @decla= a
        @pr= b
    end

    def print_ast indent=""
        @decla.print_ast indent + "" if @decla.respond_to? :print_ast
        @pr.print_ast indent + "" if @pr.respond_to? :print_ast
    end
end

class I_Error < AST
    attr_accessor :exp

    def initialize (a) 
        @exp= a
    end

    def print_ast indent=""
        puts "#{indent}Instruccion inesperada: "
        @exp.print_ast indent + "    " if @exp.respond_to? :print_ast
    end
end

class Suma < ArithmeticBinOP;end
class Resta < ArithmeticBinOP;end
class Multiplicacion < ArithmeticBinOP;end
class Minus < ArithmeticUnOP;end
class Bminus< ArithmeticUnOP;end   
class Division < ArithmeticBinOP;end
class Porcentaje < ArithmeticBinOP;end
class Modulo < ArithmeticBinOP;end 
class Div < ArithmeticBinOP;end
class Mayor < ArithmeticBinOP;end
class Menor < ArithmeticBinOP;end
class Mayorigual < ArithmeticBinOP;end 
class Menorigual < ArithmeticBinOP;end
class Distinto < ArithmeticBinOP;end
class Equivalencia < ArithmeticBinOP;end
class And < ArithmeticBinOP;end
class Or < ArithmeticBinOP;end
class Not < ArithmeticBinOP;end              
                      