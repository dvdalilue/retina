#! /usr/bin/ruby
#  Etapa 1 - Analizador Lexicográfico para el lenguaje Retina
#   Alumnos: Johanny Prado 11-10801
#            Edgar Silva   11-10968
# Fecha Ultima modificacion: 12/02/2017

Ident = 2

class AST
  def identador(cant=iden,token)
      token.rjust(iden +token.to_s.length,' ') + "\n" 
  end  
end

     

class S < AST
    attr_accessor :bloqIns,
                  :funciones

    def initialize bloqIns,funciones=nil
        @bloqIns = bloqIns
        @funciones = funciones
    end 

    def to_s
        ident=Ident
        sig_nivel = ident + Ident
        token = "\nAST:\n"

        if @bloqIns
          token = identador("Bloque:",ident) + token
          token = @bloqIns.to_s(sig_nivel)
        end
       
    end
end    

class InstBlq < AST
   attr_accessor :decla_list,
                 :inst_blq1

    def initialize decla = nil, inst_blq1
        @decla_list = decla
        @inst_blq1 = inst_blq1
    end
end

class InstBlq1 < AST
   attr_accessor :instruction_list,
                 :inst_blq

    def initialize instruc=nil, inst_blq = nil
        @instruction_list = instruc
        @inst_blq = inst_blq
    end
end 

class ListDecl < AST
  attr_accessor :declaration_list,
                :decl

  def initialize decl,declaList = nil 
    @declaration_list= declaList
    @decl = decl
  end
end 

#class Comentarios < AST
# attr_accessor:instruction_list

#    def initialize instruc
#        @instrucciones_list = instruc
#    en
#end

class Decl < AST
 attr_accessor :tipo,
               :decl1 

    def initialize decl1, t
        @decl1 = decl1
        @tipo = t
    end
end

class Decl1 < AST
 attr_accessor :list_id,
               :asig 

    def initialize li=nil,a=nil
        @list_id = li
        @asig = a
    end
end 


class ListId < AST
 attr_accessor :var,
               :list_id

    def initialize v,li = nil
        @var =v
        @list_id = li
    end
end 

=begin
class Var < AST
 attr_accessor :id

    def initialize id
        @id = id
    end
end
=end



class Asig < AST
 attr_accessor :var,
               :expr

    def initialize v,exp
        @var = v
        @expr = exp
    end
end 



class LisTerm < AST
 attr_accessor :term,
               :list_term

    def initialize ter,lisTerm=nil
        @term = ter
        @list_term = lisTerm
    end
end 


class BinOp < AST
    attr_accessor :left, :right

    def initialize lh, rh
        @left = lh
        @right = rh
    end
end 


class UnOp < AST
 attr_accessor :right

    def initialize rh
        @right = rh
    end
end 

class ParenEx < AST
 attr_accessor :expr

    def initialize e
        @expr = e
    end
end 


class ListInst < AST
 attr_accessor :inst,
               :asig,
               :loop,
               :list_inst,
               :conditional

    def initialize i=nil,a=nil,l=nil,listInst=nil, cond=nil
        @inst =i
        @asig =a
        @loop =l
        @list_inst = listInst
        @conditional = cond
    end
end 


class Inst < AST
    attr_accessor :exp,
                  :inst_movi1,
                  :list_term    

    def initialize inst_movi1=nil,exp=nil,list_term=nil
        @inst_movi1=inst_movi1
        @exp=exp
        @list_term =list_term
    end
end

class InstMovi1 < AST
    attr_accessor :inst_movi2

    def initialize inst
        @inst_movi2 = inst
    end
end


class Conditional < AST

    attr_accessor :list_inst,
                  :exp,
                  :cond1

    def initialize expr,listInst,cond1
        @exp =expr
        @list_inst =listInst
        @cond1 = cond1
    end
end

class Cond1 < AST

    attr_accessor :list_inst

    def initialize listInst
        @list_inst =listInst
    end
end


class Loop < AST
    attr_accessor :var,
                  :list_inst,
                  :exp


    def initialize v=nil,expr=nil,listInst
        @var=v
        @exp =expr
        @list_inst =listInst
    end
end 


class ListArg < AST
    attr_accessor :tipo,
                  :var,
                  :list_Arg

    def initialize t,v,listArg=nil
        @tipo =t
        @var =v
        @list_Arg =listArg
    end
end 


class DeclFunc < AST
    attr_accessor :list_Arg,
                  :firma,
                  :list_inst

    def initialize listArg=nil,listInst=nil, firm
        @list_Arg =listArg
        @list_inst =listInst
        @firma = firm
    end
end

class Firm < AST
    attr_accessor :type

    def initialize type = nil
        @type = type
    end
end