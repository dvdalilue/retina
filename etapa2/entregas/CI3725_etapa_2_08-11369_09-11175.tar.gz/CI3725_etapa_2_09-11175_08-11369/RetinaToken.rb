=begin
  Proyecto 2 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Lista de clases de tokens de apoyo para el lexer
$tokensAvailable = [
    "TkLiteralCadenaCaracteres",
    "TkLiteralNumerico",
    "TkProgram",
    "TkWith",
    "TkRepeat",
    "TkDo",
    "TkWriteln",
    "TkWrite",
    "TkRead",
    "TkIf",
    "TkThen",
    "TkElse",
    "TkFor",
    "TkFrom",
    "TkTo",
    "TkBy",
    "TkWhile",
    "TkNumber",
    "TkBoolean",
    "TkTimes",
    "TkBegin",
    "TkEnd",
    "TkFunc",
    "TkReturn",
    "TkTrue",
    "TkFalse",
    "TkTipoRetorno",
    "TkNot",
    "TkMenos",
    "TkIgual",
    "TkDesigual",
    "TkProducto",
    "TkDivisionExacta",
    "TkRestoExacto",
    "TkDivisionEntera",
    "TkRestoEntero",
    "TkMas",
    "TkMayorOIgualQue",
    "TkMenorOIgualQue",
    "TkMayorQue",
    "TkMenorQue",
    "TkAnd",
    "TkOr",
    "TkAsignacion",
    "TkParentesisAbre",
    "TkParentesisCierra",
    "TkComa",
    "TkPuntoYComa",
    "TkIdentificador"
]



# Clase abstracta para modelar los tokens del lenguaje
class RetinaToken
    attr_reader :linea, :columna, :tipo, :valor

    # Inicializa un token
    def initialize(linea, columna, valor)
        @linea = linea
        @columna = columna
        @valor = valor
    end

    # Acceso a variable fuera de la clase
    def self.regex
        @regex
    end

    # Acceso a variable fuera de la clase
    def self.tipo
        @tipo
    end

    # Representacion en string
    def to_s
        selfClass = Object::const_get(self.class.name)
        "linea #{@linea}, columna #{@columna}: #{selfClass.tipo} '#{@valor}'"
    end

end



#Token literal de cadena de caracteres
class TkLiteralCadenaCaracteres < RetinaToken
    @regex = /\A"(?:[^\"\\\n]|\\\\|\\"|\\n)*"/
    @tipo = "literal de cadena de caracteres"

    def to_s
        "linea #{@linea}, columna #{@columna}: #{TkLiteralCadenaCaracteres.tipo} #{@valor}"
    end
end


#Token literal numerico
class TkLiteralNumerico < RetinaToken
    @regex = /\A\d+(?:\.\d+)?/
    @tipo = "literal numerico"
end


#Token program
class TkProgram < RetinaToken
    @regex = /\A\bprogram\b/
    @tipo = "palabra reservada"
end


#Token with
class TkWith < RetinaToken
    @regex = /\A\bwith\b/
    @tipo = "palabra reservada"
end


#Token repeat
class TkRepeat < RetinaToken
    @regex = /\A\brepeat\b/
    @tipo = "palabra reservada"
end


#Token do
class TkDo < RetinaToken
    @regex = /\A\bdo\b/
    @tipo = "palabra reservada"
end


#Token write
class TkWrite < RetinaToken
    @regex = /\A\bwrite\b/
    @tipo = "palabra reservada"
end


#Token writeln
class TkWriteln < RetinaToken
    @regex = /\A\bwriteln\b/
    @tipo = "palabra reservada"
end


#Token read
class TkRead < RetinaToken
    @regex = /\A\bread\b/
    @tipo = "palabra reservada"
end


#Token if
class TkIf < RetinaToken
    @regex = /\A\bif\b/
    @tipo = "palabra reservada"
end


#Token then
class TkThen < RetinaToken
    @regex = /\A\bthen\b/
    @tipo = "palabra reservada"
end


#Token else
class TkElse < RetinaToken
    @regex = /\A\belse\b/
    @tipo = "palabra reservada"
end


#Token for
class TkFor < RetinaToken
    @regex = /\A\bfor\b/
    @tipo = "palabra reservada"
end


#Token from
class TkFrom < RetinaToken
    @regex = /\A\bfrom\b/
    @tipo = "palabra reservada"
end


#Token to
class TkTo < RetinaToken
    @regex = /\A\bto\b/
    @tipo = "palabra reservada"
end


#Token by
class TkBy < RetinaToken
    @regex = /\A\bby\b/
    @tipo = "palabra reservada"
end


#Token while
class TkWhile < RetinaToken
    @regex = /\A\bwhile\b/
    @tipo = "palabra reservada"
end


#Token number
class TkNumber < RetinaToken
    @regex = /\A\bnumber\b/
    @tipo = "tipo de dato"
end


#Token boolean
class TkBoolean < RetinaToken
    @regex = /\A\bboolean\b/
    @tipo = "tipo de dato"
end


#Token times
class TkTimes < RetinaToken
    @regex = /\A\btimes\b/
    @tipo = "palabra reservada"
end


#Token begin
#Token times
class TkBegin < RetinaToken
    @regex = /\A\bbegin\b/
    @tipo = "palabra reservada"
end


#Token begin
class TkEnd < RetinaToken
    @regex = /\A\bend\b/
    @tipo = "palabra reservada"
end


#Token func
class TkFunc < RetinaToken
    @regex = /\A\bfunc\b/
    @tipo = "palabra reservada"
end


#Token return
class TkReturn < RetinaToken
    @regex = /\A\breturn\b/
    @tipo = "palabra reservada"
end





#Token true
class TkTrue < RetinaToken
    @regex = /\A\btrue\b/
    @tipo = "expresion tipo boolean"
end


#Token false
class TkFalse < RetinaToken
    @regex = /\A\bfalse\b/
    @tipo = "expresion tipo boolean"
end


#Token and
class TkAnd < RetinaToken
    @regex = /\A\band\b/
    @tipo = "operador logico"
end


#Token or
class TkOr < RetinaToken
    @regex = /\A\bor\b/
    @tipo = "operador logico"
end


#Token not
class TkNot < RetinaToken
    @regex = /\A\bnot\b/
    @tipo = "operador logico"
end




#Token tipo de valor de retorno
class TkTipoRetorno < RetinaToken
    @regex =  /\A\-\>/
    @tipo = "signo"
end


#Token igual (==)
class TkIgual < RetinaToken
    @regex =  /\A==/
    @tipo = "signo"
end


#Token desigual (/=)
class TkDesigual < RetinaToken
    @regex =  /\A\/=/
    @tipo = "signo"
end


#Token mayor o igual (>=)
class TkMayorOIgualQue < RetinaToken
    @regex = /\A\>\=/
    @tipo = "signo"
end


#Token menor o igual (=<)
class TkMenorOIgualQue < RetinaToken
    @regex = /\A\<\=/
    @tipo = "signo"
end


#Token mayor que (>)
class TkMayorQue < RetinaToken
    @regex = /\A\>(?!=)/
    @tipo = "signo"
end


#Token menor que (<)
class TkMenorQue < RetinaToken
    @regex = /\A\<(?!=)/
    @tipo = "signo"
end


#Token asignacion (=)
class TkAsignacion < RetinaToken
    @regex = /\A=(?!=)/
    @tipo = "signo"
end


#Token division entera
class TkDivisionEntera < RetinaToken
    @regex = /\A\bdiv\b/
    @tipo = "operador aritmetico"
end


#Token resto entero
class TkRestoEntero < RetinaToken
    @regex = /\A\bmod\b/
    @tipo = "operador aritmetico"
end


#Token mas
class TkMas < RetinaToken
    @regex = /\A\+/
    @tipo = "operador aritmetico"
end


#Token menos
class TkMenos < RetinaToken
    @regex = /\A\-(?!\>)/
    @tipo = "operador aritmetico"
end


#Token producto
class TkProducto < RetinaToken
    @regex = /\A\*/
    @tipo = "operador aritmetico"
end


#Token division exacta
class TkDivisionExacta < RetinaToken
    @regex = /\A\/(?!=)/
    @tipo = "operador aritmetico"
end


#Token resto exacto
class TkRestoExacto < RetinaToken
    @regex = /\A%/
    @tipo = "operador aritmetico"
end



#Token abre parentesis
class TkParentesisAbre < RetinaToken
    @regex = /\A\(/
    @tipo = "signo"
end


#Token cierra parentesis
class TkParentesisCierra < RetinaToken
    @regex = /\A\)/
    @tipo = "signo"
end

#Token coma
class TkComa < RetinaToken
    @regex = /\A,/
    @tipo = "signo"
end


#Token punto y coma
class TkPuntoYComa < RetinaToken
    @regex = /\A;/
    @tipo = "signo"
end


#Token identificador
class TkIdentificador < RetinaToken
    @regex = /\A[a-z][a-zA-Z_0-9]*/
    @tipo = "identificador"
end
