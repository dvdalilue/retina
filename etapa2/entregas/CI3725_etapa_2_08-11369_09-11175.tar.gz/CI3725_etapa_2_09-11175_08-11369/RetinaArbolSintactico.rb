=begin
  Proyecto 2 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Identacion default
INDENT_DEFAULT = 2


# Identa un string la cantidad de espacios indicado
def indent(str, pad = INDENT_DEFAULT)
    str.to_s.rjust(str.to_s.length + pad, ' ') + "\n"
end


# Arbol sintactico abstracto
class AST

    def initialize(funciones, bloquePrograma)
        @funciones = funciones
        @bloquesPrograma = bloquePrograma
    end

    def to_s

        identacion = INDENT_DEFAULT
        indentacionNext = identacion + INDENT_DEFAULT

        str = "\nAST:\n"
        if @funciones
            str += indent("funciones:", identacion)
            str += @funciones.to_s(indentacionNext)
        end

        if @bloquesPrograma
            str += indent("programa:", identacion)
            str += @bloquesPrograma.to_s(indentacionNext)
        end

        str
    end
end


# Hijos del arbol sintactico abstracto
class ASTChild

    # Representacion en string del arbol
    def to_s(identacion)

        # Primera parte del arbol: nombre
        str = indent(@nombreArbol +":", identacion)
        identacion += INDENT_DEFAULT
        indentacionNext = identacion + INDENT_DEFAULT

        # Segunda parte del arbol: atributos
        getAttributes().each do |attribute, value|

            # Saca el "@" del nombre del atributo
            attribute = attribute.to_s[1..-1]
            if attribute == 'nombreArbol' or value.nil?
                next
            end

            # Separa en espacios
            attribute = attribute.gsub(/(?=[A-Z])/, ' ').strip.downcase
            str += indent("#{attribute}:", identacion)
            str += value.to_s(indentacionNext)
        end

        str
    end

    # Obtiene los atributos de la instancia
    def getAttributes
        list = []
        instance_variables.map do |attribute|
            list.push([attribute, instance_variable_get(attribute)])
        end
        list
    end
end


# Arbol de las reglas FUNCIONES
class ArbolFuncionList < ASTChild

    def initialize(funcion, funcionList = nil)
        @funcion = funcion
        @funcionList = funcionList
    end


    def to_s(identacion)

        str = @funcion.to_s(identacion)

        if @funcionList
            str += @funcionList.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas FUNCION
class ArbolFuncion < ASTChild

    def initialize(identificador, parametros, tipoRetorno, instrucciones)
        @nombreArbol = "FUNCION"
        @identificador = ArbolIdentificador.new(identificador)
        @parametros = parametros
        @tipoRetorno = tipoRetorno
        @instrucciones = instrucciones
    end

end


# Arbol de las reglas FUNCION_PARAMS
class ArbolFuncionParams < ASTChild

    def initialize(tipo, identificador, funcionParams = nil)
        @tipo = tipo
        @identificador = ArbolIdentificador.new(identificador)
        @funcionParams = funcionParams
    end


    def to_s(identacion)

        str = indent("PARAMETRO:", identacion)
        identacionParametro = identacion + INDENT_DEFAULT
        indentacionNext = identacionParametro + INDENT_DEFAULT

        str += indent("tipo:", identacionParametro)
        str += @tipo.to_s(indentacionNext)

        str += indent("nombre:", identacionParametro)
        str += @identificador.to_s(indentacionNext)

        if @funcionParams
            str += @funcionParams.to_s(identacion)
        end

        str
    end

end


# Arbol de las reglas FUNCION_RETURN
class ArbolFuncionReturn < ASTChild
    attr_accessor :expresion

    def initialize(expresion)
        @nombreArbol = "RETORNO FUNCION"
        @expresion = expresion
    end

end



# Arbol de las reglas BLOQUES
class ArbolBloqueList < ASTChild

    def initialize(bloque, bloqueList = nil)
        @bloque = bloque
        @bloqueList = bloqueList
    end


    def to_s(identacion)

        str = @bloque.to_s(identacion)

        if @bloqueList
            str += @bloqueList.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas BLOQUE
class ArbolBloque < ASTChild
    attr_accessor :declaraciones, :instrucciones

    def initialize(declaraciones, instrucciones)
        @nombreArbol = "BLOQUE"
        @declaraciones = declaraciones
        @instrucciones = instrucciones
    end

end


# Arbol de las reglas DECLARACIONES
class ArbolBloqueDeclaraciones < ASTChild

    def initialize(declaracion, declaracionList = nil)
        @declaracion = declaracion
        @declaracionList = declaracionList
    end


    def to_s(identacion)

        str = @declaracion.to_s(identacion)

        if @declaracionList
            str += @declaracionList.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas DECLARACION
class ArbolDeclaracion < ASTChild

    def initialize(tipo, identificadores, expresionInicializacion = nil)
        @nombreArbol = "DECLARACION"
        @tipo = tipo

        if identificadores.class.name == "TkIdentificador"
            @identificador = ArbolIdentificador.new(identificadores)
        else
            @identificadores = identificadores
        end

        @inicializacion = expresionInicializacion
    end

end


# Arbol de las reglas DECLARACION_IDENTIFICADORES
class ArbolDeclaracionIdentificadores < ASTChild

    def initialize(identificador, listaIdentificadores = nil)
        @identificador = ArbolIdentificador.new(identificador)
        @listaIdentificadores = listaIdentificadores
    end


    def to_s(identacion)

        str = @identificador.to_s(identacion)

        if @listaIdentificadores
            str += @listaIdentificadores.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas INSTRUCCIONES
class ArbolBloqueInstrucciones < ASTChild

    def initialize(instruccion, instruccionList = nil)
        @instruccion = instruccion
        @instruccionList = instruccionList
    end


    def to_s(identacion)

        str = @instruccion.to_s(identacion)

        if @instruccionList
            str += @instruccionList.to_s(identacion)
        end

        str
    end

end




# Arbol de las reglas ASIGNACION
class ArbolAsignacion < ASTChild

    def initialize(identificador, expresion)
        @nombreArbol = "ASIGNACION"
        @ladoIzquierdo = ArbolIdentificador.new(identificador)
        @ladoDerecho = expresion
    end

end


# Arbol de las reglas ENTRADA
class ArbolEntrada < ASTChild

    def initialize(identificador)
        @nombreArbol = "ENTRADA"
        @identificador = ArbolIdentificador.new(identificador)
    end

end


# Arbol de las reglas SALIDA
class ArbolSalida < ASTChild

    def initialize(expresiones, salto = nil)
        @nombreArbol = 'SALIDA'
        if salto
            @nombreArbol = 'SALIDA CON SALTO'
        end
        @expresiones = expresiones
    end

end



# Arbol de las reglas SALIDA_EXPR
class ArbolSalidaExpresiones < ASTChild

    def initialize(expresion, expresiones = nil)
        @expresion = expresion
        @expresiones = expresiones
    end


    def to_s(identacion)

        str = @expresion.to_s(identacion)

        if @expresiones
            str += @expresiones.to_s(identacion)
        end

        str
    end

end


# Arbol de las reglas CONDICIONALES
class ArbolIf < ASTChild

    def initialize(expresion, instruccionesThen, instruccionesElse = nil)
        @nombreArbol = "CONDICIONAL"
        @expresion = expresion
        @instruccionesThen = instruccionesThen
        @instruccionesElse = instruccionesElse
    end

end



# Arbol de las reglas ITERACION_WHILE
class ArbolWhile < ASTChild

    def initialize(expresion, instrucciones)
        @nombreArbol = "ITERACION WHILE"
        @expresion = expresion
        @instrucciones = instrucciones
    end

end


# Arbol de las reglas ITERACION_FOR
class ArbolFor < ASTChild

    def initialize(identificador, from, to, by, instrucciones)
        @nombreArbol = "ITERACION FOR"
        @identificador = ArbolIdentificador.new(identificador)
        @expresionFrom = from
        @expresionTo = to
        @expresionBy = by
        @instrucciones = instrucciones
    end

end



# Arbol de las reglas ITERACION_REPEAT
class ArbolRepeat < ASTChild

    def initialize(expresion, instrucciones)
        @nombreArbol = "REPEAT"
        @expresion = expresion
        @instrucciones = instrucciones
    end

end



# Arbol de las reglas FUNCION
class ArbolFuncionLlamada < ASTChild

    def initialize(identificador, argumentos = nil)
        @nombreArbol = "LLAMADA FUNCION"
        @identificador = ArbolIdentificador.new(identificador)
        @argumentos = argumentos
    end

end


# Arbol de las reglas FUNCION_LLAMADA_ARGS
class ArbolFuncionLlamadaArgs < ASTChild

    def initialize(expresion, funcionArgs = nil)
        @expresion = expresion
        @funcionArgs = funcionArgs
    end


    def to_s(identacion)

        if @expresion.nil?
            return ''
        end

        str = indent("ARGUMENTO:", identacion)
        str += @expresion.to_s(identacion + INDENT_DEFAULT)

        if @funcionArgs
            str += @funcionArgs.to_s(identacion)
        end

        str
    end

end


# Arbol de las reglas TIPO
class ArbolTipo < ASTChild

    def initialize(nombre)
        @nombre = nombre.valor
    end

    def to_s(identacion)
        str = indent("TIPO:", identacion)
        str += indent("nombre: "+ @nombre, identacion + INDENT_DEFAULT)
    end

end


# Arbol de las reglas EXPR con operadores unarios
class ArbolOperadorUnario < ASTChild

    def initialize(operador, expresion)
        #@operador = operador
        @expresion = expresion

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @nombreArbol = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end

end


# Arboles de expresiones con operadores unarios
class ArbolNot < ArbolOperadorUnario;end
class ArbolMenosUnario < ArbolOperadorUnario;end



# Arbol de las reglas EXPR con operadores binarios
class ArbolOperadorBinario < ASTChild

    def initialize(expresionIzquierda, operador, expresionDerecha)
        #@operador = operador
        @ladoIzquierdo = expresionIzquierda
        @ladoDerecho = expresionDerecha

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @nombreArbol = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end

end

# Arboles de expresiones con operadores binarios
class ArbolIgual < ArbolOperadorBinario;end
class ArbolDesigual < ArbolOperadorBinario;end
class ArbolMayorOIgualQue < ArbolOperadorBinario;end
class ArbolMenorOIgualQue < ArbolOperadorBinario;end
class ArbolMayorQue < ArbolOperadorBinario;end
class ArbolMenorQue < ArbolOperadorBinario;end
class ArbolAnd < ArbolOperadorBinario;end
class ArbolOr < ArbolOperadorBinario;end
class ArbolProducto < ArbolOperadorBinario;end
class ArbolDivisionExacta < ArbolOperadorBinario;end
class ArbolRestoExacto < ArbolOperadorBinario;end
class ArbolDivisionEntera < ArbolOperadorBinario;end
class ArbolRestoEntero < ArbolOperadorBinario;end
class ArbolSuma < ArbolOperadorBinario;end
class ArbolResta < ArbolOperadorBinario;end



# Arbol de las reglas EXPR (sin operador)
class ArbolExpresion < ASTChild

    def initialize(expresion)
        @expresion = expresion
        @valorExpresion  = @expresion.valor
        @labelExpresion = 'valor'

        # Obtiene el nombre de la expresion a partir del nombre de la clase, separa en espacios
        @nombreExpresion = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    def to_s(identacion)
        str = indent(@nombreExpresion + ":", identacion)
        str += indent(@labelExpresion +": "+ @valorExpresion, identacion + INDENT_DEFAULT)
    end

end


# Arboles de expresiones sin operadores
class ArbolExpresionBooleana < ArbolExpresion; end
class ArbolLiteralNumerico < ArbolExpresion;end
class ArbolLiteralDeCadenaDeCaracteres < ArbolExpresion;end


# Arbol de identificadores
class ArbolIdentificador < ArbolExpresion

    def initialize(expresion)
        super
        @labelExpresion = 'nombre'
    end
end
