# AUTORES:
# Alessandra Marero 12-11091
# Julio Fuenmayor 13-10488

##########################
# Clase principal de AST #
##########################
class AST
	def print_ast (indent="")
		puts "#{indent}#{self.class}:"

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end


###############
# OPERACIONES #
###############
class OperacionUnaria < AST
	attr_accessor :operando

	def initialize(operando)
		@operando = operando
	end
end


class OperacionBinaria
	attr_accessor :izquierda, :derecha

	def initialize(lh, rh)
		@izquierda = lh
		@derecha = rh
	end

	def print_ast (indent="")
		puts "#{indent}#{self.class}: " if self.class != "OperacionBinaria"

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end


class OperacionTernaria < AST 
	attr_accessor :left, :midle, :right

	def initialize left, middle, right
		@left = left
		@middle = middle
		@right = right
	end
end


##################
# TIPOS DE DATOS #
##################
class TipoDato 
	attr_accessor :tipo 

	def initialize(tipo)
		@tipo = tipo 
	end

	def print_ast (indent="")
		puts "#{indent}Tipo de dato: #{@tipo}"

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end


class Booleano < TipoDato
	attr_accessor :valor
	def initialize(valor)
		@valor = valor
	end
	def print_ast(indent="")
		puts "#{indent}#{self.class}: #{@valor}"
	end
end


class String_ < TipoDato
	attr_accessor :digito
	def initialize(d)
		@digito = d
	end
	def print_ast(indent="")
		puts "#{indent}#{self.class}: #{@digito}"
	end
end

class Numero < TipoDato
	attr_accessor :valor
	def initialize(valor)
		@valor = valor
	end
end

class PalReservada < TipoDato
	attr_accessor :digito
	def initialize(d)
		@digito = d
	end
  	def print_ast indent=""
      	puts "#{indent} Palabra Reservada: #{@digito}"
    end
end

class Digito < AST
	attr_accessor :digito
	def initialize(d)
		@digito = d
	end
	def print_ast(indent="")
		puts "#{indent}#{self.class}: #{@digito.to_i}"
	end
end

class Identificador < String_; end
#################
# Comparaciones #
#################
class Distinto < OperacionBinaria; end
class Mayor < OperacionBinaria; end
class MayorIgual < OperacionBinaria; end
class Menor < OperacionBinaria; end
class MenorIgual < OperacionBinaria; end
class Equivalente < OperacionBinaria; end


#################
# Op. Aritmeticas #
#################
class Suma < OperacionBinaria; end
class Resta < OperacionBinaria; end
class Multiplicacion < OperacionBinaria; end
class DivisionEntera < OperacionBinaria; end
class DivisionExacta < OperacionBinaria; end
class ModuloEntero < OperacionBinaria; end
class ModuloExacto < OperacionBinaria; end
class MenosUnario < OperacionUnaria; end

#################
# Op. Logicas   #
#################
class Not < OperacionUnaria; end
class And < OperacionBinaria; end
class Or < OperacionBinaria; end

###################################################
# Declaraciones, Asignaciones, Entradas y Salidas  #
###################################################
class Declaracion < OperacionBinaria; end
class Asignacion < OperacionBinaria; end
class Entrada < OperacionUnaria
  def print_ast indent=""
	  puts "#{indent} Entrada "

	  attrs.each do |a|
		  a.print_ast indent + "  " if a.respond_to? :print_ast
	  end
  end
end

class Salida < OperacionUnaria
  def print_ast indent=""
	  puts "#{indent} Salida "

	  attrs.each do |a|
		  a.print_ast indent + "  " if a.respond_to? :print_ast
	  end
  end
end


class Return < OperacionUnaria; end

#############
# Funciones #
#############
class Funciones < AST
  attr_accessor :funcion, :parametros, :instr
  def initialize f, p, i
      @funcion = f
      @parametros = p
      @instr = i
  end
end

class Argumento < OperacionUnaria
  def print_ast indent=""
      puts "#{indent} Argumento: "

      attrs.each do |a|
          a.print_ast indent + "  " if a.respond_to? :print_ast
      end
  end
end
class Funcion < AST
  attr_accessor :name,:arg1, :arg2
  def initialize name,arg1,arg2
    @arg0=name
    @arg1=arg1
    @arg2=arg2
  end
  def print_ast indent=""
      puts "#{indent} Llamada a funcion:"

      attrs.each do |a|
          a.print_ast indent + "  " if a.respond_to? :print_ast
      end
  end
end

class Retornar < OperacionUnaria
  def print_ast indent=""
      puts "#{indent} Return"

      attrs.each do |a|
          a.print_ast indent + "  " if a.respond_to? :print_ast
      end
  end
end

class FuncionRet < AST
  attr_accessor :nombre, :parametros, :tipo, :bloqueret
  def initialize n, p, d, r
      @nombre = n
      @parametros = p
      @tipo = d
      @bloqueret = r

  end
end

class LlamadaFunc < Funcion; end
class FuncArgumento < Funcion; end
##########################
# Estructuras Especiales #
##########################
class Bloque < AST
	attr_accessor :instruccion

		def initialize(instruccion)
			@instruccion = instruccion
		end
end

class Condicional < OperacionTernaria; end

class Funcion < AST
	attr_accessor :name, :arg1, :arg2

	def initialize(name, arg1, arg2)
		@name = name
		@arg1 = arg1
		@arg2 = arg2
	end
end

class Instruccion < OperacionBinaria
	def print_ast indent=""
	puts "#{indent} Instruccion: #{@digit}"

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
	end

	def attrs
        instance_variables.map do |a|
            instance_variable_get a
        end
    end
end

class Programa < OperacionUnaria
  def print_ast indent=""
      puts "#{indent} Program:"

      attrs.each do |a|
          a.print_ast indent + "  " if a.respond_to? :print_ast
      end
  end
end










