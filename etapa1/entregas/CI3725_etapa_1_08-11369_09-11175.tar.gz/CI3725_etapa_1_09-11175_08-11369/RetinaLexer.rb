=begin
  Proyecto 1 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Programas requeridos
require_relative 'RetinaToken'


# Analizador lexicografico
class RetinaLexer
    attr_reader :tokens

    def initialize(fileContents)
        @fileContents = fileContents

        # Lista de tokens conseguidos
        @tokens = []

        # Lista de caracteres inesperados conseguidos
        @unexpectedList = []

        # Control de lineas y columnas
        @currentLine = 1
        @currentColumn = 1
    end


    # Actualiza el contenido del archivo desde la posicion indicada
    def updateFileContents(from)
        @fileContents = @fileContents[from .. @fileContents.length-1]
    end


    # Desplaza un numero de columnas indicado
    # tras haber reconocido un token
    def skipColumns(numCols)
        @currentColumn = @currentColumn + numCols
    end


    # Desplaza a una nueva linea del contenido del archivo
    def newLine()
        @currentLine = @currentLine + 1
        @currentColumn = 1
    end


    # Obtiene los tokens
    def tokenize()

        while !@fileContents.empty?

            # Ignora espacios y tabs
            if @fileContents =~ /\A[ \r\t\f]+/
                skipColumns($&.length)
                updateFileContents($&.length)
                next
            end

            # Ignora saltos de linea
            if @fileContents =~ /\A\n/
                newLine()
                updateFileContents($&.length)
                next
            end

            # Ignora comentarios
            if @fileContents =~ /\A#.*\n/
                newLine()
                updateFileContents($&.length)
                next
            end


            # Verifica si se hace match con algun token
            tokenMatch = false
            $tokensAvailable.each do |tokenClassName|

                # Accede a la expresion regular de cada token
                tokenClass = Object::const_get(tokenClassName)
                if @fileContents =~ tokenClass.regex

                    # Guarda el token
                    tokenFound = tokenClass.new(@currentLine, @currentColumn, $&)
                    @tokens.push(tokenFound)

                    # Actualiza contenido
                    tokenMatch = true
                    skipColumns($&.length)
                    updateFileContents($&.length)

                    break
                end
            end

            # Si no se consiguio match, es un caracter inesperado
            if !tokenMatch
                unexpected = RetinaLexerError.new(@currentLine, @currentColumn, @fileContents[0])
                @unexpectedList.push(unexpected)

                skipColumns(1)
                updateFileContents(1)
            end

        end

        # Lanza excepcion si se consiguieron caracteres inesperados
        if @unexpectedList.length > 0
            raise RetinaLexerException.new(@unexpectedList)
        end

        tokens
    end


    # Imprime la lista de tokens conseguidos
    def printTokens()
        @tokens.each { |token| puts token }
    end
end


# Maneja caracteres inesperados conseguidos
class RetinaLexerError

    def initialize(linea, columna, valor)
        @linea = linea
        @columna = columna
        @valor = valor
    end

    # Representacion en string
    def to_s
        "linea #{@linea}, columna #{@columna}: caracter inesperado '#{@valor}'\n"
    end
end


# Excepcion del lexer
class RetinaLexerException < RuntimeError

    def initialize(unexpectedList)
        @unexpectedList = unexpectedList
    end

    # Representacion en string
    def to_s
        str = ''
        @unexpectedList.each do |unexpected|
            str = "#{str}#{unexpected}"
        end
        str
    end
end
