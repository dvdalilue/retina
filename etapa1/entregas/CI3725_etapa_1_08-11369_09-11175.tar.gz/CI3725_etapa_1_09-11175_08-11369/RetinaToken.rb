=begin
  Proyecto 1 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Lista de clases de tokens de apoyo para el lexer
$tokensAvailable = [
    "TkLiteralCadenaCaracteres",
    "TkLiteralNumerico",
    "TkProgram",
    "TkWith",
    "TkRepeat",
    "TkDo",
    "TkWriteln",
    "TkWrite",
    "TkRead",
    "TkIf",
    "TkThen",
    "TkElse",
    "TkFor",
    "TkFrom",
    "TkTo",
    "TkWhile",
    "TkNumber",
    "TkBoolean",
    "TkTimes",
    "TkBegin",
    "TkEnd",
    "TkFunc",
    "TkReturn",
    "TkHome",
    "TkOpeneye",
    "TkCloseeye",
    "TkForward",
    "TkBackward",
    "TkRotatel",
    "TkRotater",
    "TkSetposition",
    "TkArc",
    "TkTrue",
    "TkFalse",
    "TkTipoRetorno",
    "TkNot",
    "TkMenos",
    "TkIgual",
    "TkDesigual",
    "TkProducto",
    "TkDivisionExacta",
    "TkRestoExacto",
    "TkDivisionEntera",
    "TkRestoEntero",
    "TkMas",
    "TkMayorIgual",
    "TkMenorIgual",
    "TkMayorQue",
    "TkMenorQue",
    "TkAnd",
    "TkOr",
    "TkAsignacion",
    "TkParentesisAbre",
    "TkParentesisCierra",
    "TkComa",
    "TkPuntoYComa",
    "TkIdentificador"
]



# Clase abstracta para modelar los tokens del lenguaje
class Token
    attr_reader :linea, :columna, :tipo, :valor

    # Inicializa un token
    def initialize(linea, columna, valor)
        @linea = linea
        @columna = columna
        @valor = valor
    end

    # Acceso a variable fuera de la clase
    def self.regex
        @regex
    end

    # Acceso a variable fuera de la clase
    def self.tipo
        @tipo
    end

    # Representacion en string
    def to_s
        selfClass = Object::const_get(self.class.name)
        "linea #{@linea}, columna #{@columna}: #{selfClass.tipo} '#{@valor}'"
    end

end



#Token literal de cadena de caracteres
class TkLiteralCadenaCaracteres < Token
    @regex = /\A"(?:[^\"\\\n]|\\\\|\\"|\\n)*"/
    @tipo = "literal de cadena de caracteres"

    def to_s
        "linea #{@linea}, columna #{@columna}: #{TkLiteralCadenaCaracteres.tipo} #{@valor}"
    end
end


#Token literal numerico
class TkLiteralNumerico < Token
    @regex = /\A\d+(?:\.\d+)?/
    @tipo = "literal numerico"
end


#Token program
class TkProgram < Token
    @regex = /\A\bprogram\b/
    @tipo = "palabra reservada"
end


#Token with
class TkWith < Token
    @regex = /\A\bwith\b/
    @tipo = "palabra reservada"
end


#Token repeat
class TkRepeat < Token
    @regex = /\A\brepeat\b/
    @tipo = "palabra reservada"
end


#Token do
class TkDo < Token
    @regex = /\A\bdo\b/
    @tipo = "palabra reservada"
end


#Token write
class TkWrite < Token
    @regex = /\A\bwrite\b/
    @tipo = "palabra reservada"
end


#Token writeln
class TkWriteln < Token
    @regex = /\A\bwriteln\b/
    @tipo = "palabra reservada"
end


#Token read
class TkRead < Token
    @regex = /\A\bread\b/
    @tipo = "palabra reservada"
end


#Token if
class TkIf < Token
    @regex = /\A\bif\b/
    @tipo = "palabra reservada"
end


#Token then
class TkThen < Token
    @regex = /\A\bthen\b/
    @tipo = "palabra reservada"
end


#Token else
class TkElse < Token
    @regex = /\A\belse\b/
    @tipo = "palabra reservada"
end


#Token for
class TkFor < Token
    @regex = /\A\bfor\b/
    @tipo = "palabra reservada"
end


#Token from
class TkFrom < Token
    @regex = /\A\bfrom\b/
    @tipo = "palabra reservada"
end


#Token to
class TkTo < Token
    @regex = /\A\bto\b/
    @tipo = "palabra reservada"
end


#Token while
class TkWhile < Token
    @regex = /\A\bwhile\b/
    @tipo = "palabra reservada"
end


#Token number
class TkNumber < Token
    @regex = /\A\bnumber\b/
    @tipo = "tipo de dato"
end


#Token boolean
class TkBoolean < Token
    @regex = /\A\bboolean\b/
    @tipo = "tipo de dato"
end


#Token times
class TkTimes < Token
    @regex = /\A\btimes\b/
    @tipo = "palabra reservada"
end


#Token begin
#Token times
class TkBegin < Token
    @regex = /\A\bbegin\b/
    @tipo = "palabra reservada"
end


#Token begin
class TkEnd < Token
    @regex = /\A\bend\b/
    @tipo = "palabra reservada"
end


#Token func
class TkFunc < Token
    @regex = /\A\bfunc\b/
    @tipo = "palabra reservada"
end


#Token return
class TkReturn < Token
    @regex = /\A\breturn\b/
    @tipo = "palabra reservada"
end


#### Funciones predefinidas ####

#Token home
class TkHome < Token
    @regex = /\A\bhome\b/
    @tipo = "identificador"
end


#Token openeye
class TkOpeneye < Token
    @regex = /\A\bopeneye\b/
    @tipo = "identificador"
end


#Token closeeye
class TkCloseeye < Token
    @regex = /\A\bcloseeye\b/
    @tipo = "identificador"
end


#Token forward
class TkForward < Token
    @regex = /\A\bforward\b/
    @tipo = "identificador"
end


#Token backward
class TkBackward < Token
    @regex = /\A\bbackward\b/
    @tipo = "identificador"
end


#Token rotatel
class TkRotatel < Token
    @regex = /\A\brotatel\b/
    @tipo = "identificador"
end


#Token rotater
class TkRotater < Token
    @regex = /\A\brotater\b/
    @tipo = "identificador"
end


#Token setposition
class TkSetposition < Token
    @regex = /\A\bsetposition\b/
    @tipo = "identificador"
end


#Token arc
class TkArc < Token
    @regex = /\A\barc\b/
    @tipo = "identificador"
end






#Token true
class TkTrue < Token
    @regex = /\A\btrue\b/
    @tipo = "expresion tipo boolean"
end


#Token false
class TkFalse < Token
    @regex = /\A\bfalse\b/
    @tipo = "expresion tipo boolean"
end


#Token and
class TkAnd < Token
    @regex = /\A\band\b/
    @tipo = "operador logico"
end


#Token or
class TkOr < Token
    @regex = /\A\bor\b/
    @tipo = "operador logico"
end


#Token not
class TkNot < Token
    @regex = /\A\bnot\b/
    @tipo = "operador logico"
end




#Token tipo de valor de retorno
class TkTipoRetorno < Token
    @regex =  /\A\->/
    @tipo = "signo"
end


#Token igual (==)
class TkIgual < Token
    @regex =  /\A==/
    @tipo = "signo"
end


#Token desigual (/=)
class TkDesigual < Token
    @regex =  /\A\/=/
    @tipo = "signo"
end


#Token mayor o igual (>=)
class TkMayorIgual < Token
    @regex = /\A>=/
    @tipo = "signo"
end


#Token menor o igual (=<)
class TkMenorIgual < Token
    @regex = /\A<=/
    @tipo = "signo"
end


#Token mayor que (>)
class TkMayorQue < Token
    @regex = /\A>/
    @tipo = "signo"
end


#Token menor que (<)
class TkMenorQue < Token
    @regex = /\A</
    @tipo = "signo"
end


#Token asignacion (=)
class TkAsignacion < Token
    @regex = /\A=/
    @tipo = "signo"
end


#Token division entera
class TkDivisionEntera < Token
    @regex = /\A\bdiv\b/
    @tipo = "operador aritmetico"
end


#Token resto entero
class TkRestoEntero < Token
    @regex = /\A\bmod\b/
    @tipo = "operador aritmetico"
end


#Token mas
class TkMas < Token
    @regex = /\A\+/
    @tipo = "operador aritmetico"
end


#Token menos
class TkMenos < Token
    @regex = /\A\-/
    @tipo = "operador aritmetico"
end


#Token producto
class TkProducto < Token
    @regex = /\A\*/
    @tipo = "operador aritmetico"
end


#Token division exacta
class TkDivisionExacta < Token
    @regex = /\A\//
    @tipo = "operador aritmetico"
end


#Token resto exacto
class TkRestoExacto < Token
    @regex = /\A%/
    @tipo = "operador aritmetico"
end



#Token abre parentesis
class TkParentesisAbre < Token
    @regex = /\A\(/
    @tipo = "signo"
end


#Token cierra parentesis
class TkParentesisCierra < Token
    @regex = /\A\)/
    @tipo = "signo"
end

#Token coma
class TkComa < Token
    @regex = /\A,/
    @tipo = "signo"
end


#Token punto y coma
class TkPuntoYComa < Token
    @regex = /\A;/
    @tipo = "signo"
end


#Token identificador
class TkIdentificador < Token
    @regex = /\A[a-z][a-zA-Z_0-9]*/
    @tipo = "identificador"
end


