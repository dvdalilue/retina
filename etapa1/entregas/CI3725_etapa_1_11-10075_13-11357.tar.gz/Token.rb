class Token # Clase Token
    def initialize(id, value, line, column)
        @id = id # ID
        @value = value # Valor
        @line = line # Numero de la linea donde se encuentra el token
        @column = column # Numero de la columna donde se encuentra el token
    end
  
    def to_s
        "Tk#{@id} #{@line} #{@column}" # Vuelve string
    end
   
end

class TkIdent < Token # Clase identificador: sirve para los nombres de variables, por ejemplo
    def initialize(value, line, column)
        super(:IDENT, value, line, column) # Inicializa llamando a la superclase Token con esos valores. Id pasa a ser alias IDENT
    end

    def to_s
        "linea #{@line}, columna #{@column}: identificador '#{@value}'"  # Vuelve string
    end

end

class TkChar < Token # Clase caracter: para los signos, como ( ) ;
    def initialize(value, line, column)
        super(:CHARACTER, value, line, column)  # Inicializa llamando a la superclase Token. Id pasa a ser alias CHAR
    end

    def to_s
        "linea #{@line}, columna #{@column}: signo '#{@value}'" # Vuelve string
    end

end

class TkNum < Token # Clase numero: self-explanatory
    def initialize(value, line, column)
        super(:NUM, value, line, column)  # Inicializa llamando a la superclase Token. Id pasa a ser alias NUM
    end

    def to_s
        "linea #{@line}, columna #{@column}: literal numérico '#{@value}'" # Vuelve string
    end
end

class TkReserved < Token # Clase Reserved: Para las palabras reservadas
    def initialize(value, line, column)
        super(:RESERVED, value, line, column)  # Inicializa llamando a la superclase Token. Id pasa a ser alias RESERVED
    end

    def to_s
        "linea #{@line}, columna #{@column}: palabra reservada '#{@value}'" # Vuelve string
    end
end

class TkType < Token # Clase tipo: para los tipo de datos. Enteros, floats...
    def initialize(value, line, column)
        super(:TYPE, value, line, column)  # Inicializa llamando a la superclase Token. Id pasa a ser alias TYPE
    end

    def to_s
        "linea #{@line}, columna #{@column}: tipo de dato '#{@value}'" # Vuelve string
    end
end