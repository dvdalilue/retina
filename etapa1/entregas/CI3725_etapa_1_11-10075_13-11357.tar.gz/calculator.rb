require_relative 'Lexer.rb'

begin

    tokens = Lexer.new(ARGV[0])
    if not tokens.hasErrors then 
        puts tokens.tokensList
    end
end