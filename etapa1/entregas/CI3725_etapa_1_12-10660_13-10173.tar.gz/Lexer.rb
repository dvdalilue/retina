require_relative 'Tokens'

class Lexer
  attr_reader :tokens, :errores

  def initialize input
    @tokens = [] #arreglo de tokens
    @errores = [] #arreglo de errores
    @input = input #string del archivo de entrada
    @linea = 1 #contador de linea
    @columna = 0 #variable qeu servira para calcular la columna
    @aux = @input # arrreglo que servira para calcular la linea y la columna
    @aux = @aux.split(/\n/)
    @numb_lineas = @aux.length #varible qeu servira para verificar cuando saltamos de linea
    $index_aux = 0 #variable que servia para no repetir palabras ya leidas al momento de verificar la columna
  end

  #metodo para leer los lexemas
  def catch_lexeme
    # retorna nil si es vacio
    return if @input.empty?
    # ignoramos los espacios en blanco
    @input =~ /\A(\s*|\t*)/
    @input = $'

    #creamos un arreglo para verificar lineas y columnas posteriormente
    aux = @input.split(/\n/)
    #verificamos si pasamos a otra linea
    if aux.length.eql? @numb_lineas
      #no se a psado de linea
      #puts aux.length.eql? @numb_lineas
    else
      #se paso de linea, por lo que rreseteamos el contador de index_aux
      #y agregamos o quitamos 1 a los demas contadores como sea necesario
      #puts "otra linea"
      @linea += 1
      @numb_lineas -= 1
      @columna += 1
      $index_aux = 0
    end

    # Local variable initialize with error, if all regex don't succeed
    class_to_be_instanciated = LexicographicError # Yes, this is class. Amaze here
    # verificamos los regex conrespecto al texto en el qeu estamos trabajando
    $tokens.each do |k,v|
      if @input =~ v
        # Taking advantage with the reflexivity and introspection of the
        # language is nice
        class_to_be_instanciated = Object::const_get(k)
        break
      end
    end

    y = @aux[@columna] #cadena de string de la linea en la que nos encontrramos
    if $&.nil? and class_to_be_instanciated.eql? LexicographicError
      # si es un error lexicografico lo creamos y posteriormente agregamos al areglo de errores
      @input =~ /\A(\w|\p{punct})/
      z = LexicographicError.new($&)
      @errores << "linea #{@linea}, columna #{y[$index_aux..y.length].index($&)+1+$index_aux}: #{z}"
      # se modifica index_aux para no volver a leer el token ya leido
      $index_aux = y[$index_aux..y.length].index($&)+1+$index_aux
    else
      # si no es un error, se crea y se agrega al arreglo de tokens
      x = class_to_be_instanciated.new($&)
      @tokens << "linea #{@linea}, columna #{y[$index_aux..y.length].index($&)+1+$index_aux}: #{x}"
      # se modifica index_aux para no volver a leer el token ya leido
      $index_aux = y[$index_aux..y.length].index($&)+1+$index_aux
    end
    # modificamos el input para omitir el token leido
    @input = @input[$&.length..@input.length-1]
    
    # retornamos los tokens
    return @tokens[-1]
  end

  #metodo que recorre el input hasta que se acabe 
  def recorrer
    while catch_lexeme; end
  end
end