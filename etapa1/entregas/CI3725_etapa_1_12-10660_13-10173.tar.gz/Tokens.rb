class Token

	attr_reader :lexema

	#Inicia el token con el lexema dado
	def initialize lexema
		@lexema = lexema
	end

	def to_s
		"#{self.class}"
	end
end

#listamos todos los tokens 
$tokens = {
	Literal_numerico:  /\A[0-9]+/    ,
	Literal_string:    /\A\".*\"/    ,
	Tipo_B:            /\Aboolean/   ,
	Tipo_N:            /\Anumber/    ,
	Document:          /\A\#.*/      ,
	Coma:              /\A\,/        ,
	Punto:             /\A\./        ,
	PuntoYComa:        /\A\;/        ,
	ParAbre:           /\A\(/        ,
	ParCierra:         /\A\)/        ,
	Menos:             /\A\-/        ,
	Mas:               /\A\+/        ,
	Mult:              /\A\*/        ,
	DivSign:           /\A\// 		 ,
	Menor:             /\A\</        ,
	MenorIgual:        /\A\<=/       ,
	Mayor:             /\A\>/        ,
	MayorIgual:        /\A\>=/       ,
	Igual:             /\A\=/        ,
	DobleIgual:        /\A\==/       ,
	Salto:             /\A\n/        ,
	Div:               /\Adiv/       ,
	Mod:               /\Amod/       ,
	True:              /\Atrue/      ,
	False:             /\Afalse/     ,
	With:              /\Awith/     ,
	Do:                /\Ado/        ,
	End:               /\Aend/       ,
	Then:              /\Athen/      ,
	If:                /\Aif/        ,
	Else:              /\Aelse/      ,
	While:             /\Awhile/     ,
	Program:           /\Aprogram/   ,
	Repeat:            /\Arepeat/    ,
	Times:             /\Atimes/     ,
	Func:              /\Afunc/      ,
	Write:             /\Awrite/     ,
	Writeln:           /\Awriteln/   ,
	Identificador:     /\A[a-z]\w*/  ,
}

# para cada clase la definimos la forma de convertirlo a string
class Literal_numerico < Token
	def to_s
		"literal numerico \'#{@lexema}\'"
	end
end

class Literal_string < Token
	def to_s
		"literal de string #{@lexema}"
	end
end

class Signo < Token
	def to_s
		"signo \'#{@lexema}\'"
	end
end

class Tipo_de_dato < Token
	def to_s
		"tipo de dato \'#{@lexema}\'"
	end
end

class Plabras_reservadas < Token
	def to_s
		"palabra reservada \'#{@lexema}\'"
	end
end

class LexicographicError < RuntimeError
  def initialize t
    @t = t
  end

  def to_s
    "caracter inesperado \'#{@t}\'"
  end
end


class Identificador < Token
	def to_s
		"indetificador \'#{@lexema}\'"
	end
end

class Tipo_B < Tipo_de_dato; end
class Tipo_N < Tipo_de_dato; end

class Salto < Token; end

class Document < Signo
	def to_s
		"signo '#'"
	end
end

class Coma < Signo; end
class Punto < Signo; end
class PuntoYComa < Signo; end
class ParAbre < Signo; end
class ParCierra < Signo; end
class Menos < Signo; end
class Mas < Signo; end
class Mult < Signo; end
class DivSign < Signo; end
class Menor < Signo; end
class MenorIgual < Signo; end
class Mayor < Signo; end
class MayorIgual < Signo; end
class Igual < Signo; end
class DobleIgual < Signo; end
class Div < Signo; end
class Mod < Signo; end

class True < Plabras_reservadas; end
class False < Plabras_reservadas; end
class With < Plabras_reservadas; end
class Do < Plabras_reservadas; end
class End < Plabras_reservadas; end
class Then < Plabras_reservadas; end
class If < Plabras_reservadas; end
class Else < Plabras_reservadas; end
class While < Plabras_reservadas; end
class Program < Plabras_reservadas; end
class Repeat < Plabras_reservadas; end
class Times < Plabras_reservadas; end
class Func < Plabras_reservadas; end
class Write < Plabras_reservadas; end
class Writeln < Plabras_reservadas; end
