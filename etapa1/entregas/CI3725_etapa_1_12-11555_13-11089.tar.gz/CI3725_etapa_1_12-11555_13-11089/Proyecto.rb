#Tabla de has con las distintas expresiones regulares con las que verificaremos cada token
$tokens = {
	LiteralesNumericos: 		/\A[0-9]+\.[0-9]+|\A[0-9]+/,
	PalabrasReservadas: 		/\Aread\b|\Awrite\b|\Awriteln\b|\Aif\b|\Athen\b|\Aend\b|\Awith\b|\Ado\b|\Aprogram\b|\Afor\b|\Afrom\b|\Ato\b|\Awhile\b|\Aby\b|\Arepeat\b|\Atimes\b|\Afunc\b|\Abegin\b|\Atrue\b|\Afalse\b|\Ads\b|\Aelse\b/,
	CadenaDeCaracteres:			/\A"([^\\\n]?\\\\|[^\\\n]?\\n|[^\\\n]?\\"|[^\\\n])*?"/,
	Signos: 					/\A\-\>|\A\/\=|\A\>\=|\A\<\=|\A\=\=|\A\+|\A\-|\A\*|\A\/|\A\=|\A\>|\A\<|\A\,|\A\;|\A\(|\A\)|\A\%|\Adiv\b|\Amod\b/,
	TipoDeDato: 				/\Anumber\b|\Aboolean\b/,
	Identificadores: 			/\A[a-z][A-Za-z0-9\_]*/,
	CaracterInesperado: 		/\A\S/
}

#Clase token la cual sera heredada por cada uno de los tipos de tokens
#    t: contenido del token
#    l: linea en la que se encuentra en el archivo
#    c: columna en la qye se encuentra en el archivo
class Token
	def initialize t, l, c
		@text = t
		@line = l
		@column = c
	end
end

#Las clases que vienen a continuacion heredan de token y se les agrega la funcion de impresion

class LiteralesNumericos < Token
	def to_s 
		"linea #{@line}, columna #{@column}: literal numerico '#{@text}' "
	end
end


class PalabrasReservadas < Token
	def to_s 
		"linea #{@line}, columna #{@column}: palabra reservada '#{@text}' "
	end
end


class Signos < Token
	def to_s 
		"linea #{@line}, columna #{@column}: signo '#{@text}' "
	end
end


class TipoDeDato < Token
	def to_s 
		"linea #{@line}, columna #{@column}: tipo de dato '#{@text}' "
	end
end


class Identificadores < Token
	def to_s 
		"linea #{@line}, columna #{@column}: identificador '#{@text}' "
	end
end


class CaracterInesperado < Token
	def to_s 
		"linea #{@line}, columna #{@column}: caracter inesperado '#{@text}' "
	end
end


class CadenaDeCaracteres < Token
	def to_s
		"linea #{@line}, columna #{@column}: cadena de caracteres '#{@text}' "
	end
end

#Clase lexer que realiza la descomposicion en tokens del archivo
#    Tokens: lista que contiene los tokens que han sido identificados
#    TokensError: lista que contiene tokens que no cumplen con ninguna de las especificaciones de Retina
#    Archivo: String que contiene el archivo a descomponer
#    linea: Contador que especifica la linea actual
#    columna: Contador que especifica la columna actual
#    TokenClass: Esta variable especifica la clase a la cual pertenece el token encontrado

class Lexer

	def initialize archivo
		@Tokens = []
		@TokensError = []
		@Archivo = archivo
		@linea = 1
		@columna = 1
		@TokenClass = Token
	end
	
	#Funcion que descompone el archivo en tokens y los clasifica
	def capturador
		#La funcion termina si no hay mas nada que procesar en el string
		return if @Archivo.length == 0
		#Eliminamos los espacios entre los tokens y calculamos la columna
		@Archivo =~ /\A[ \t\r\f]*\#[^\n]*|\A[ \t\r\f]+/
		if not$&.nil?
			@columna += $&.length
			@Archivo = $'
		end
		#Verificamos si hay un salto de linea y en caso de haberlo actualizamos los datos de linea y columna
		@Archivo =~ /\A\n/
		if not$&.nil?
			@linea += 1
			@columna = 1
			@Archivo = $'
			self.capturador
		end
		
		#Contador para verificar si ha encontrado un error
		i = 0
		#Con el string separado del siguiente token a procesar, lo corremos por las expresiones regulares que establecimos arriba y es clasificado
		$tokens.each do |k,v|
			i += 1
			if @Archivo =~ v
				@TokenClass = Object::const_get(k)
				#Si el contador ha llegado a 7 significa que hemos encontrado un error y se agrega a la lista de errores
				if i == 7
					@TokensError<<@TokenClass.new($&, @linea, @columna)
					@columna += $&.length
					@Archivo = $'
					self.capturador()
				else
					@Tokens<<@TokenClass.new($&, @linea, @columna)
					@columna += $&.length
					@Archivo = $'
					self.capturador()
					break
				end
			end
		end
	end

	#Funcion que toma la lista correspondiente d etokens y los imprime
	def impresion
		x = @TokensError
		if @TokensError.empty?
			x = @Tokens
		end
		x.each do |m|
			puts m
		end
	end
end