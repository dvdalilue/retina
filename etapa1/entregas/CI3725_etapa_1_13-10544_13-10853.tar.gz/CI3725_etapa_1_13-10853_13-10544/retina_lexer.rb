#!/usr/bin/ruby
# encoding: utf-8
=begin

UNIVERSIDAD SIMÓN BOLÍVAR
Traductores e Interpretadores
Fase 1 de Proyecto : Lexer de Retina
Elaborado por:
	-Verónica Mazutiel, 13-10853
	-Melanie Gomes, 13-10544

=end

$lexLeidos = [] #Arreglo donde se guardarán los token encontrados
$inesperados = [] # Arreglo que guardará los caracteres invalidos del lenguaje

# Diccionario global que guarda los tokens leidos por el lenguaje retina
$tokens = {
	/^number$|^boolean$/							=> "tipo de dato",
	/^true$|^false$/								=> "literal booleano",
	/^and$|^not$|^or$/								=> "operador lógico",
	/^program$|^begin$|^end$|^with$|^do$/ 			=> "palabra reservada",
	/^if$|^then$|^else$|^while$|^for$/				=> "palabra reservada",
	/^repeat$|^times$|^read$|^write$|^writeln$/		=> "palabra reservada",
	/^from$|^to$|^by$|^func$|^return$|^->$/			=> "palabra reservada",
	/^==$|^<$|^\/=$|^>=$|^<=$|^>$/					=> "operador de comparación",
	/^\($|^\)$|^=$|^;$/								=> "signo",
	/^\+$|^mod$|^div$|^%$|^\/$|^\*$|^-$/			=> "operador aritmético",
	/^[a-z][a-zA-Z0-9_]*$/							=> "identificador",
	/^"[a-zA-Z\d\s[[:punct:]]]*"$/					=> "string",
	/^([1-9][0-9]*|0)(\.[0-9]+)?$/					=> "literal numérico",
}


#Funcion que chequea en el diccionario de Tokens los strings leídos en el archivo
def checkTockens(string,l,c)
	
	#Si no hay nada en el string termina la funcion
	if string.empty? then return end
	#En caso contrario se chequea en el diccionario 
	$tokens.each do |expr,lexema|
		if string =~ expr
			#si coincide se agrega a la lista de los lexemas leidos
			$lexLeidos.push([l,c,string,lexema])
			return
		end
	end
	#Cuando no coincide con ninguna expresion regular definida se agrega
	#a la lista de caracteres inesperados
	$inesperados.push([l,c,string])
end

#Función que recorre el arreglo de Tokens e imprime su contenido
def printTokens(array)
	array.each do |line,column,token,tokenName|
		puts "linea #{line}, columna #{column}: #{tokenName} '#{token}'"
	end
end
#Función que recorre el arreglo de caracteres inesperados e imprime su contenido
def printErrors(array)
	array.each do |line,column,token|
		puts "linea #{line}, columna #{column}: caracter inesperado :'#{token}'"
	end
end

def readFile(file)
# Leer cada linea del archivo

	esCadena= false #Boleano para chequear si hay una cadena de caracteres 
	contador = 0 #Contador para la cadena de caracteres
	contadorLinea=0 #Contador para las lineas
	comparacion=false #Boleano para verificar si hubo un caracter de comparacion(==,<=,>=,/=)
	
	file.each_line do |l| #Para cada linea en el archivo se itera
		l<< ' '
		string  = "" #Aqui se van concatenando los caracteres 
		columna = 1	#Contador de la columna
		actual = '' #Se mantiene el caracter actual para compararlo con el siguiente
		contadorLinea += 1
		l.split("").each_with_index do |after,curColumn| #Se separan las lineas por caracteres				
			
			#Caso en el que se lee un string
			if esCadena #Si se encontro una cadena de strings entre comillas
				if actual == "\"" #Si se encuentra una comilla
					if contador == 0 
						esCadena = false 
						string << actual #Se concatenan los caracteres
						checkTockens(string,contadorLinea,columna) 
						string = ""
						columna = curColumn+1
					else
						contador = 0
						string << actual
					end
				else
					contador = actual == "\\"? 1-contador : 0
					string << actual
				end
			
			else
				case actual
				when "#" #Si se encuentra el caracter de comentario se salta a la próxima linea
					checkTockens(string,contadorLinea,columna)
					break
					
				when " ","\t","\n","," 
					#Si se encuentra un espacio de cualquier tipo se evalua la cadena de caracteres
					#actual contra el diccionario de Tokens
					checkTockens(string,contadorLinea,columna)
					string = ""
					columna = curColumn+1
					
				when ";","(",")","=",">","<","/","+","%","*","-"
					#Al encontrar un signo de comparacion se chequea el flag comparacion
					#si no esta encendido se puede leer el siguiente caracter con normalidad
					
					if 	!comparacion
						#Si el caracter siguiente no es un = se prosigue a leer normalmente
						if after != "=" 
							checkTockens(string,contadorLinea,columna)
							checkTockens(actual,contadorLinea,curColumn)		
							string = ""
							#Como es un signo de 1 caracter se salta una columna
							columna = curColumn+1
								
						else  
							checkTockens(string,contadorLinea,columna)
							checkTockens(actual<<after,contadorLinea,curColumn)
							string = ""		
							#Como entro en un signo de comparacion de dos caracteres se saltan 2 columnas
							columna = curColumn+2
							comparacion=true

						end
					else
						#Si esta encendido se salta la operacion y se cambia apaga el flag
						comparacion=false
					end
					
				when "\"" #Se comienza a leer una cadena de strings
					esCadena = true
					string << actual
					
				else
					string << actual #Se hace la respectiva concatenacion
				end
			end
			actual = after #Se hace el cambio del actual por el siguiente
		end
		#Se chequean los caracteres guardados 
		checkTockens(string,contadorLinea,columna)
	end
end