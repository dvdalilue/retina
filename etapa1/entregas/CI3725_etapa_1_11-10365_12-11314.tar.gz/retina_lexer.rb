# Lexer utilizado en el lenguaje "retina".
# 
# calculator_lexer.rb fue utilizado como plantilla.
#
# Autores: Jonathan Reyes (12-11314)
#          Rosana Garcia  (11-10365)
# 

class Token
  attr_reader(:item, :line, :column)

  
  def initialize(item, line, column)
    @item = item
    @line = line
    @column = column
  end

  def to_s
    "linea #{line}, columna #{column}: #{self.class} \'#{item}\'"
  end
end

$line = 1
$column = 1
$temp = nil

$tokens = {
    CharacterString:          /\A\"[(?:\\\\|\\\"")[^\"\n\\]]*\"/,
  	Number:                   /\A0*([0-9]+(?:\.[0-9]+)?)/,
  	Boolean:                  /\A(true|false)/,
    Sign:                     /\A(;|\(|\)|\||=)/,
  	AritmethicOperator: 	    /\A(\+|\-|\*|\/|%|div|mod)/,
  	LogicOperator:            /\A(not|and|or)/,
  	Comparator: 	            /\A(==|\/=|>=|<=|<|>)/,
  	ReservedWord:	            /\A(program|with|do|repeat|for|from|to|begin|end|func|read|write|writeln|if|then|else|times)(?=\s)/,
    DataType:                 /\A(string|number|boolean)(?=\s)/,
    Identifier:               /\A([a-z]\w*)/

  
}

class LexicographicError < RuntimeError
  def initialize(item,line,column)
    @item = item
    @line = line
    @column = column
  end

  def to_s
    "Linea #{@line}, columna #{@column}: Lexema inesperado \'#{@item}\'"
  end
end

class CharacterString < Token; end
class Number < Token; end
class Boolean < Token; end
class Identifier < Token; end
class AritmethicOperator < Token; end
class LogicOperator < Token; end
class Comparator < Token; end
class ReservedWord < Token; end
class DataType < Token; end
class Sign < Token; end

class Lexer
  attr_reader(:tokens,:unknown)

  def initialize(input)
    @tokens = []
    @unknown = []
    @input = input
  end

  def catch_lexeme
    # Return nil, if there is no input
    if @input.empty?
      return nil;
    end

    # Ignore every white space and comment at the begining of string, and assign string following after match to input variable.
    if @input =~ /\A(\s|#.*\n)*/
      @input = $'
    end

    # Count the number of lines ignored
    $temp = $&
    while $temp =~ /\A.*\n/
      $line += 1
      $column = 1
      $temp = $'
    end

    # Count amount of blank space in line before next token
    $column += $temp.length

    # Empty the string buffer 
    $temp = nil

    # Local variable initialize with error, if all regex don't succeed
    class_to_be_instanciated = LexicographicError # Yes, this is class. Amaze here
    # For every key and value, check if the input match with the actual regex
    $tokens.each do |k,v|
      if @input =~ v
        $temp = $&
        
        # Taking advantage with the reflexivity and introspection of the
        # language is nice
        class_to_be_instanciated = Object::const_get(k)
        break
      end
    end

    # If a blank space was ignored and reached end of file, just end processing loop
    if @input.empty?
      return false
    end
    

    # Raise errors found
    if $temp.nil? and class_to_be_instanciated.eql? LexicographicError
      @input =~ /\A\S(?=\s)/
      @unknown << LexicographicError.new($&,$line,$column)
      @input = @input[$&.length..@input.length-1]
      #puts @unknown[-1].nil?
      return @unknown[-1]
    end
    # Append token found to the token list
    @tokens << class_to_be_instanciated.new($temp,$line,$column)
    # Update column position
    $column += $temp.length
    # Update input
    @input = @input[$temp.length..@input.length-1]
    # Return token found
    #puts @tokens[-1].nil?
    return @tokens[-1]
  end
end