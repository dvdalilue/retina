# AUTORES:
# Alessandra Marero 12-11091
# Julio Fuenmayor 13-10488

#Diccionario que contiene los tokens y sus regex correspondientes
$tokens = {
Equivalent: /[\s]*\==[\s]*/,
Geq: 		/\A\>\=$/,
Leq: 		/\A\<\=$/,
Digit: 		/\A\d+$/,
Point: 		/\A\.$/,
Sum: 		/\A\+$/,
Minus: 		/\A\-$/,
Product: 	/\A\*$/,
Equals: 	/\A\=/,
OpenPa: 	/\A\($/,
ClosePa: 	/\A\)$/,
Percenctage: /\A\%$/,
Not: 		/\Anot$/,
And: 		/\Aand$/,
Or: 		/\Aor$/,
Div: 		/\Adiv$/,
Mod: 		/\Amod$/,
Backslash: 	/\A\\$/,
Slash: 		/\A\/$/,
Greater: 	/\A\>$/,
Lower: 		/\A\<$/,
Colon: 		/\A\,$/,
Semicolon: 	/\A\;$/,
Boolean: 	/\Atrue$/,	
False: 		/\Afalse$/,
Home: 		/\Ahome$/,
Palabr: 	/\Aopeneye$/,
Closeeye: 	/\Acloseeye$/,
Forward: 	/\Aforward$/,
Backward: 	/\Abackward$/,
Rotatel: 	/\Arotatel$/,
Rotater: 	/\Arotater$/,
SetPosition: /\Asetposition$/,
Arc: 		/\Aarc$/,
Writeln: 	/\Awriteln$/,
Write: 		/\Awrite$/,
Read: 		/\Aread$/,
Quotes: 	/\A\"$/,
Numeral: 	/\#(\s|\n)[a-zA-Z0-9]*[^\n]/,
Numeral: 	/\A(\#[^\n]*)$/,
Underscore: /\A\_$/,
Hyphen: 	/\A\-/,     
With: 		/\Awith$/,
Do: 		/\Ado$/,
End: 		/\Aend$/,
Number: 	/\Anumber$/,
Boolean: 	/\Aboolean$/,
If: 		/\Aif$/,	
Then: 		/\Athen$/,
Else:  		/\Aelse$/,
While:  	/\Awhile$/,
For: 		/\Afor$/,
From:  		/\Afrom$/,
To: 		/\Ato$/,
Program: 	/\Aprogram$/,
Repeat: 	/\Arepeat$/,
Times: 		/\Atimes$/,
Func:  		/\Afunc$/,
Begin:  	/\Abegin$/,

Alphabet:  	/\A[a-zA-Z0-9]*/,
}


#Clase que se utiliza para guardar informacion de los tokens reconocidos
class Token 
	attr_accessor :linea
	attr_accessor :columna
	attr_accessor :tipo
	attr_accessor :match
	
	def initialize(linea,columna, tipo, match)
		@linea = linea
		@columna = columna
		@tipo = tipo
		@match = match
	end 
end

#Clase que contiene un metodo para reconocer los tokens dentro del archivo de entrada
class Lexer
	attr_reader :input
	attr_reader :conocidos
	attr_reader :desconocidos
	attr_accessor :numero_linea

	def initialize(input)
		@desconocidos = [] #Estructura donde se almacenan los tokens no reconocidos
		@conocidos = []		#Estructura donde e almacenan los token reconocidos
		@input = input
		@pos = 1
		$numero_linea = 0
	end

	def match_token

		@error = true
		while !@input.empty?
			return if @input.empty?

			@input =~ /\A[^\S\n]*/ #Ignora los saltos de linea y los espacios en blanco al principio
			@pos = @pos + $&.length if $& != nil
			@input = $'

			$tokens.each do |token, regex|
				if @input =~ regex
					
					#Imprime los token encontrados. 
					puts "linea #{@numero_linea}, columna #{@pos}: #{token} '#{$&}' " unless $&.empty?
					lexema = Token.new(@numero_linea, @pos, token, $&)
					@conocidos << lexema

					@input = @input[$&.length..@input.length-1]
					@pos = @pos + $&.length
					break 
				end		
			end
		

				

			@input =~ /\A(\W|\p{Any})/
			puts "linea #{@numero_linea}, columna #{@pos}: '#{$&}' " unless $&.empty? || $& == " " || $& == "\n"
			if $& != "" && $& != " " && $& != "\n"  
				lexema2 = Token.new(@numero_linea, @pos, "Caracter desconocido: ", $&)
				@desconocidos << lexema2
			end
			@input = @input[$&.length..@input.length-1]
			@pos = @pos + $&.length
			


					
		end
	end
end
