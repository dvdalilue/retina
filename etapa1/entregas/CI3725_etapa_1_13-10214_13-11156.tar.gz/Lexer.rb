#! /usr/bin/ruby
# Universidad Simon Bolivar
# Trimestre Enero-Marzo 2017
# Traductores e Interpretadores [CI3725]
# Rafael Cisneros, 13-11156
# Miguel Canedo, 13-10214
# Proyecto, Entrega 1 (Lexer)

# Expresiones regulares para identificar los tokens
$tokens = {
 'literal numerico' => /\A[0-9]+(\.[0-9]+)?/,
 'signo' => /\A(;|=(?!=)|\+|\-|\/|%|\*|\(|\)|==|\/=|>=|<=|>(?!=)|<(?!=)|mod|div)/,
 'tipo de dato' => /\A(boolean|number)/,
 'literal booleano' => /\A(true|false)/,
 'palabra reservada' => /\A(program|not|and|or|read|write|writeln|with|do|end|if|then|while|for|from|to|repeat|times|begin|func)\b/,
 'identificador' => /\A[a-z][a-zA-Z0-9_]*/,
 'cadena de caracteres' => /\A\"([^\"\\\n]|(\\[\\\"n]))*\"/,
 'comentario' => /\#.*$/
}

# Clase que representa un Token (lexema)
class Token
	attr_reader :tipo

	# Constructor de la Clase Token
	def initialize id, tipo, fila, columna
		@id = id 	# Lo que se detecto al hacer match con alguna Expresion Regular
		@tipo = tipo	# El tipo de Token segun el match con alguna Expresion Regular
		@fila = fila	# Fila en el archivo donde se consiguio dicho Token
		@columna = columna # Columna en el archivo donde se consiguio dicho Token
	end

	def to_s
		"linea #{@fila.to_s}, columna #{@columna.to_s}: #{@tipo} '#{@id.to_s}'"
	end
end

# Clase que representa al Lexer.
class Lexer
	# Constructor de la clase Lexer
	def initialize entrada
		@entrada = entrada # String que contiene el contenido del archivo
		@linea = 1 # Valor inicial de la fila
		@columna = 1 # Valor inicial de columna
		@tokens = [] # Lista de tokens
		@errores = [] # Lista de errores
		
	end

	def leer_archivo
		@entrada =~ /\A\s*/
		@entrada = $'
		$&.each_char do |chr|
			if chr == "\n"
				@linea += 1
				@columna = 1
			else
				@columna += 1
			end
		end

		if @entrada.empty?
			return
		end

		entro = false
		$tokens.each do |tipo, regex|
			if @entrada =~ regex
				if tipo != 'comentario'
					nuevoToken = Token.new($&, tipo, @linea, @columna)
					@tokens << nuevoToken
				end
				entro = true
				break
			end
		end

		if not entro
			@entrada =~ /\A(\w|\p{punct})/
			error = Token.new($&, "caracter inesperado", @linea, @columna)
			@errores << error
		end

		@columna += $&.length
		@entrada = $'

		leer_archivo
	end

	def to_s
		(if @errores.empty? then @tokens else @errores end).map { |token| token.to_s }.join "\n"
	end
end

########################################################################
########################## Programa Principal ##########################
########################################################################

unless ARGV[0] =~ /\w+\.rtn/ # Chequeamos la extension del archivo de entrada
	abort("Extension del archivo desconocida")
end

unless File::exists?(ARGV[0]) # Chequeamos la existencia del archivo de entrada
	abort("Archivo no encontrado")
end

# Creamos el Lexer
lexer = Lexer.new(File::read(ARGV[0]))

lexer.leer_archivo

puts lexer