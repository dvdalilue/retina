# AUTORES:
# Alessandra Marero 12-11091
# Julio Fuenmayor 13-10488

require_relative 'TablaSimbolos'
require_relative 'Errores'

$tablaSimbolos = TablaSimbolos.new("", "Tabla Raiz")
$tablaFunciones = TablaFunciones.new("Tabla Funciones")
$idTabla = Array.new()
$funcionActual 
$retorno


class AnalizadorContexto

	def initialize(ast)
		@ast = ast
	end


	def explorar()
		$idTabla.push(1)
		analizar_contexto(@ast)
		return $tablaSimbolos
	end


	# Analiza la raiz del arbol
	def analizar_contexto(arbol)
		funcionesRetina()
		# Si las hay, analiza las definiciones de las funciones
		analizador_funciones(arbol.funciones, $tablaSimbolos) unless arbol.funciones.nil?

		# Analiza el cuerpo principal del programa
		analizador_bloqueprogram(arbol.bloqueprogram, $tablaSimbolos)
		$idTabla.pop()
	end


	def analizador_funciones(funciones, tablaSimbolos)
		analizador_funcion(funciones.funcion, tablaSimbolos)
		analizador_funciones(funciones.proxFunc, tablaSimbolos) unless funciones.proxFunc.nil?

	end

	def analizador_funcion(funcion, tablaSimbolos)

		nombre = funcion.nombre
		
		#Chequea si la funcion devuelve algun tipo, sino, devuelve void
		if funcion.tipo.nil?
			tipo = "void"
		else
			tipo = funcion.tipo.tipo
		end

		#Revisa si la funcion fue previamente declarada
		if not ($tablaFunciones.esMiembro?(nombre)) then
			nuevaTablaSim = crearTablaSimbolos(nombre, tablaSimbolos)
			parametros = Array.new
			parametros = analizador_parametros(funcion.parametros, nuevaTablaSim, parametros) unless funcion.parametros.nil?
			$tablaFunciones.insertar(nombre, tipo, parametros, funcion)
		else
			raise ErrorContexto.new(funcion, "Funcion ya declarada", Array[nombre.upcase]) 
		end


		$funcionActual = nombre
		$retorno = false
		analizador_instrucciones(funcion.bloqueinstr, nuevaTablaSim)
		if(not tipo.eql? "void" and $retorno.eql? false) then
			error = "la funcion no devuelve nada pero tiene un tipo de retorno asignado."
			info = [$funcionActual.upcase, error]
			raise ErrorContexto.new(funcion, "tipo de retorno invalido", info)
		end
		$idTabla.pop()
	end

	def analizador_parametros(parametros, tablaSimbolos, params)
		param = analizador_parametro(parametros.param, tablaSimbolos) unless parametros.param.nil?
		params << param
		params = analizador_parametros(parametros.parametros, tablaSimbolos, params) unless parametros.parametros.nil?
		return params
	end

	def analizador_parametro(parametro, tablaSimbolos)
		nombre = parametro.identificador
		tipo = parametro.tipo.tipo

		#Revisa si el parametro ya existia
		if(not tablaSimbolos.esMiembro?(nombre)) then
			tablaSimbolos.insertar(nombre,tipo)
		else
			raise ErrorContexto.new parametro, "Identificador de parametro repetido", Array[nombre]
		end

		return {"Nombre"=>nombre, "Tipo"=>tipo}

	end

	def analizador_instrucciones(instrucciones, tablaSimbolos)
		analizador_instrucciones(instrucciones.proxInstr, tablaSimbolos) unless instrucciones.proxInstr.nil?
		analizador_instruccion(instrucciones.instruccion, tablaSimbolos) unless instrucciones.instruccion.nil?
	end

	def analizador_instruccion(instr, tablaSimbolos)
		case instr
		when Condicional
			analizador_condicional(instr, tablaSimbolos)	
		when Asignacion
			analizador_asignacion(instr, tablaSimbolos)		
		when Bloque
			analizador_bloque(instr, tablaSimbolos)		
		when Salida
			analizador_salida(instr, tablaSimbolos)		
		when Entrada
			analizador_entrada(instr, tablaSimbolos)
		when CicloWhile
			analizador_cicloWhile(instr, tablaSimbolos)
		when CicloFor
			analizador_cicloFor(instr, tablaSimbolos)		
		when CicloRepeat
			analizador_cicloRepeat(instr, tablaSimbolos)
		when LlamadaFunc
			analizador_llamadaFunc(instr, tablaSimbolos)
		when Retornar
			analizador_retornar(instr, tablaSimbolos)

		end
	end


	def analizador_condicional(condicional, tablaSimbolos)

		tipoCond = analizador_expresion(condicional.left, tablaSimbolos)
		if (not tipoCond.eql? "boolean") then
			condicional.left.print_ast("")
			raise ErrorContexto.new condicional, "La condicion de arriba no es de tipo booleano", Array[tipoCond]
		end

		# Analaliza if y else, si hay else. 
		analizador_instrucciones(condicional.middle, tablaSimbolos)
		analizador_instrucciones(condicional.right, tablaSimbolos) unless condicional.right.nil?
	end

	def analizador_asignacion(asignacion, tablaSimbolos)
		tipoID = analizador_identificador(asignacion.id, tablaSimbolos)
		tipoExpresion = analizador_expresion(asignacion.valor, tablaSimbolos)
		if(not tipoID.eql? tipoExpresion) then
			asignacion.print_ast("")
			tipos = [tipoID, tipoExpresion]
			raise ErrorContexto.new(asignacion, "hay un error de tipos en asignacion", tipos)
		end
	end

	def analizador_identificador(id, tablaSimbolos)
		nombre = id.nombre
		#puts nombre

		# Verificar si la variable fue declarada
		if (tablaSimbolos.buscar(nombre).nil?) then
			raise ErrorContexto.new nombre, "variable no declarada", Array[nombre]
		else 
			token = tablaSimbolos.buscar(nombre)
			return token[:tipo]
		end
	end

	def analizador_identificadorAsig(id, tablaSimbolos)

		# Verificar si la variable fue declarada
		if (tablaSimbolos.buscar(id).nil?) then
			raise ErrorContexto.new id, "variable no declarada", Array[id.nombre]
		else 
			return tablaSimbolos.buscar(id)
		end
	end

	def analizador_bloque(bloque, tablaSimbolos)
		nuevaTablaSim = crearTablaSimbolos("Bloque With", tablaSimbolos)
		# Guardar declaracion de variables en nueva tabla de simbolos. 
		analizador_declaraciones(bloque.declaraciones, nuevaTablaSim) unless bloque.declaraciones.nil?
		analizador_instrucciones(bloque.instrucciones, nuevaTablaSim) unless bloque.instrucciones.nil?
		$idTabla.pop()
	end


	def analizador_declaraciones(declaraciones, tablaSimbolos)
		analizador_declaracion(declaraciones.decl, tablaSimbolos) unless declaraciones.proxDecl.nil?
		analizador_declaraciones(declaraciones.proxDecl, tablaSimbolos) unless declaraciones.decl.nil?
	end

	def analizador_declaracion(declaracion, tablaSimbolos)
		tipo = declaracion.tipo.tipo
		if(declaracion.asignacion.nil?) then 
			analizador_identificadores(declaracion.identificador, tipo, tablaSimbolos)
		else
			id = declaracion.asignacion.id.nombre
			if(not tablaSimbolos.esMiembro?(id))
				tablaSimbolos.insertar(id, tipo)
				analizador_asignacion(declaracion.asignacion, tablaSimbolos)
			else 
				raise ErrorContexto.new declaracion, "variable previamente declarada", Array[id]
			end
		end
	end

	def analizador_identificadores(identificadores, tipo, tablaSimbolos)
		id = identificadores.id.nombre
		if(not tablaSimbolos.esMiembro?(id))
			tablaSimbolos.insertar(id, tipo)
		else 
			raise ErrorContexto.new identificadores, "variable previamente declarada", Array[id]	
		end	
		analizador_identificadores(identificadores.proxID, tipo, tablaSimbolos) unless identificadores.proxID.nil?
	end

	def analizador_salida(salida, tablaSimbolos)
		analizador_argSalida(salida.argSalida, tablaSimbolos) unless salida.argSalida.nil?
		if !(salida.ultimoElem.instance_of? String_) then
			analizador_expresion(salida.ultimoElem, tablaSimbolos)
		end
	end

	def analizador_argSalida(argSalida, tablaSimbolos)
		analizador_argSalida(argSalida.izquierda, tablaSimbolos) unless argSalida.izquierda.nil?

		#Caso en que el ultimo argumento no es una cadena de caracteres sino una funcion
		if(not argSalida.derecha.nil? and not argSalida.derecha.instance_of? String_) then
			analizador_expresion(argSalida.derecha, tablaSimbolos)
		end
	end

	def analizador_entrada(instr, tablaSimbolos)

		variable = instr.operando

		#Verifica que la variable haya sido previamente declarada
		if tablaSimbolos.buscar(variable).nil? then
			raise ErrorContexto.new(variable, "variable no declarada", variable)
		end

	end

	def analizador_cicloWhile(instr, tablaSimbolos)

		condicion = analizador_expresion(instr.condicion ,tablaSimbolos)

		raise ErrorContexto.new(instr.condicion, "La condicion no es de tipo booleano") unless condicion.eql? "boolean"

		analizador_instrucciones(instr.instruccion, tablaSimbolos)

	end

	def analizador_cicloFor(instr, tablaSimbolos)		
		nuevaTablaSim = crearTablaSimbolos("Ciclo For", tablaSimbolos)
		#puts "contador: #{instr.contador.nombre}"
		nuevaTablaSim.insertar(instr.contador.nombre, "number") 
		
		#Chequea la correctitud de los tipos del contador y los intervalos del ciclo
		intervaloInferior = analizador_expresion(instr.intervaloInferior, nuevaTablaSim)
		raise ErrorContexto.new(instr.intervaloInferior, "Intervalo inferior no es de tipo number" ) unless intervaloInferior.eql? "number" 
		
		intervaloSuperior = analizador_expresion(instr.intervaloSuperior, nuevaTablaSim)
		raise ErrorContexto.new(instr.intervaloSuperior, "Intervalo superior no es de tipo number") unless intervaloSuperior.eql? "number" 

		#Si llegase a existir un incremento en el for, se comprueba su tipo
		if not instr.incremento.nil? then
			incremento = analizador_expresion(instr.incremento, nuevaTablaSim)

			raise ErrorContexto.new(instr.incremento, "Tipo de incremento no es de tipo number") unless incremento.eql? "number" 
		end

		analizador_instrucciones(instr.instruccion, nuevaTablaSim)
		$idTabla.pop()
	end

	def analizador_cicloRepeat(instr, tablaSimbolos)
		tipo = analizador_expresion(instr.expresion, tablaSimbolos)
		raise ErrorContexto.new(instr.expresion, "El tipo de expresion en Repeat no es de tipo number") unless tipo.eql? "number" 

		analizador_instrucciones(instr.instruccion, tablaSimbolos)
	end


	def analizador_llamadaFunc(funcion, tablaSimbolos)

		nombre = funcion.nombre

		#Funcion previamente declarada
		if $tablaFunciones.esMiembro?(nombre) then

			parametros = $tablaFunciones.getParametros(nombre)

			params = Array.new

			parametros.each do |param|
				params << param
			end

			#Chequea que los parametros con los cuales se declaro la funcion coincidan con los parametros
			#con los que se esta llamando la funcion
			analizador_argumentos(funcion.attrs, params, tablaSimbolos)

			funcion.defFuncion = $tablaFunciones.buscar_defFuncion(nombre)

			return $tablaFunciones.buscar(nombre)[:tipo]
	
		#Funcion no declarada
		else
			#raise ErrorContexto.new(funcion, "funcion no declarada", Array[nombre.upcase])
		end
	end


	def analizador_argumentos(args, params, tablaSimbolos)

		#No se pasan argumentos...
		if args.nil? then
			#... pero la funcion tiene parametros
			if params.any? then
				raise ErrorContexto.new(params, "Numero de parametros insuficientes")
			end

		#Se estan pasando argumentos...
		else
			#... pero la funcion no tiene parametros
			if not params.any? then
				raise ErrorContexto.new(params, "Se excede el numero de parametros")
			
			#... y la funcion tiene parametros
			else

				#Se comparan el tipo de los argumentos y de los parametros
				argumento = args.izquierda
				tipoargumento = analizador_expresion(argumento, tablaSimbolos)

				parametro = params.shift

				if tipoargumento != parametro["Tipo"] then
					raise ErrorContexto.new(parametro, "El tipo de los argumentos no coinciden con el tipo de los parametros de la funcion. ", [parametro["Tipo"], tipoargumento])
				end
			
				#Analiza el resto de los argumentos
				analizador_argumentos(args.derecha, params, tablaSimbolos)

			end
		end
	end


	def analizador_retornar(instr, tablaSimbolos)
		
		tipo = $tablaFunciones.buscar($funcionActual)[:tipo]

		# Chequea que si la funcion no devuelve nada, el tipo de la funcion necesariamente sea void
		if instr.operando.nil?
			if not tipo.eql? "void" then
				error = "la funcion no devuelve nada pero tiene un tipo de retorno asignado."
				info = [$funcionActual.upcase, error]
				raise ErrorContexto.new(instr, "tipo de retorno invalido", info)
			end
		else
			# Chequea que si el tipo de la funcion es void, la funcion no devuelva nada 
			$retorno = true

			if tipo.eql? "void" then
				error = "la funcion devuelve algo pero no tiene un tipo de retorno asignado."
				info = [$funcionActual.upcase, error]
				raise ErrorContexto.new(instr, "tipo de retorno invalido", info)
			end
			tipoExpresion = analizador_expresion(instr.operando, tablaSimbolos)
	
			if(not tipo.eql? tipoExpresion) then
				raise ErrorContexto.new instr, "el tipo de retorno no es el mismo que el tipo de funcion", Array[$funcionActual.upcase]
			end
		end
	end

	def analizador_expresion(expresion, tablaSimbolos)
		case expresion
		when Booleano
			return "boolean"
		when "number"
			return "numero"
		when "boolean"
			return "booleano"
		when Digito
			return "number"
		when Identificador
			return analizador_identificador(expresion, tablaSimbolos)
		when LogicoUnario
			return analizador_logicoUnario(expresion, tablaSimbolos)
		when LogicoBinario
			return analizador_logicoBinario(expresion, tablaSimbolos)
		when Comparacion
			return analizador_comparacion(expresion, tablaSimbolos)
		when AritmeticaBinaria
			return analizador_aritmeticaBinaria(expresion, tablaSimbolos)
		when AritmeticaUnaria
			return analizador_aritmeticaUnaria(expresion, tablaSimbolos)
		when LlamadaFunc
			return analizador_llamadaFunc(expresion, tablaSimbolos)
		end
	end

	def analizador_logicoBinario(instr, tablaSimbolos)
		tipoIzqda = analizador_expresion(instr.izquierda, tablaSimbolos)
		tipoDerecha = analizador_expresion(instr.derecha, tablaSimbolos)

		if((tipoIzqda.eql? "boolean" and tipoDerecha.eql? "boolean")) then 
			return "boolean"
		else
			instr.print_ast("")
			raise ErrorContexto.new instr, "Los operandos logicos de la instruccion de arriba no son del tipo booleano"
		end
	end

	def analizador_logicoUnario(instr, tablaSimbolos)
		#puts "Entre a analizador logico unario: "
		tipoOperando = analizador_expresion(instr.operando, tablaSimbolos)
		#puts tipoOperando
		#puts "hola"
		if(tipoOperando.eql? "boolean") then 
			return "booleano"
		else 
			raise ErrorContexto.new instr, "el operando logico no es del tipo booleano", Array[instr.operando]
		end
	end

	def analizador_comparacion(instr, tablaSimbolos)
		tipoIzqda = analizador_expresion(instr.izquierda, tablaSimbolos)
		tipoDerecha = analizador_expresion(instr.derecha, tablaSimbolos)
		operador = instr.op
		
		if (operador.eql? "Equivalente" or operador.eql? "Diferente" or operador.eql? 'Mayor Igual' or operador.eql? 'Menor Igual' or operador.eql? 'Mayor' or operador.eql? 'Menor') then
			if(tipoIzqda.eql? tipoDerecha) then
				return "boolean"
			else
				instr.print_ast("")
				raise ErrorContexto.new instr, "Los operandos de comparacion de arriba no son del mismo tipo"
			end
		end
	end

	def analizador_aritmeticaBinaria(instr, tablaSimbolos)
		tipoIzqda = analizador_expresion(instr.izquierda, tablaSimbolos)
		tipoDerecha = analizador_expresion(instr.derecha, tablaSimbolos)
		if(tipoIzqda.eql? "number" and tipoDerecha.eql? "number") then 
			return "number"	
		else
			instr.print_ast("")
			raise ErrorContexto.new instr, "Los operandos aritmeticos de arriba no son del tipo numero"
		end
	end

	def analizador_aritmeticaUnaria(instr, tablaSimbolos)
		tipoOperando = analizador_expresion(instr.operando, tablaSimbolos)
		if(tipoOperando.eql? "number" or tipoOperando.eql? "digito") then 
			return "number"
		else 
			raise ErrorContexto.new instr, "El operando aritmetico no es del tipo numero" , Array[instr.operando.nombre]
		end
	end

	def funcionesRetina()
		$tablaFunciones.insertar("home","void",Array[])
		$tablaFunciones.insertar("openeye","void",Array[])
		$tablaFunciones.insertar("closeeye","void",Array[])
		$tablaFunciones.insertar("forward","void",Array[{"ident"=>"steps", "type"=>"number"}])
		$tablaFunciones.insertar("backward","void",Array[{"ident"=>"steps", "type"=>"number"}])
		$tablaFunciones.insertar("rotater","void",Array[{"ident"=>"degree", "type"=>"number"}])
		$tablaFunciones.insertar("rotatel","void",Array[{"ident"=>"degree", "type"=>"number"}])
		$tablaFunciones.insertar("setposition","void",Array[{"ident"=>"x", "type"=>"number"}, {"ident"=>"y", "type"=>"number"}])
		$tablaFunciones.insertar("arc","void",Array[{"ident"=>"degree", "type"=>"number"}, {"ident"=>"radius", "type"=>"number"}])

	end

	def analizador_bloqueprogram(programa, tablaSimbolos)
		nuevaTablaSim = crearTablaSimbolos("Program", tablaSimbolos)
		analizador_instrucciones(programa.operando, nuevaTablaSim)
		$idTabla.pop
	end

	def crearTablaSimbolos(nombre,padre)
		ultimoID = $idTabla.pop
		if(padre.nombre.eql? "Tabla Raiz") then
			nuevaTablaSim = TablaSimbolos.new ultimoID.to_s, nombre
		else
			nuevaTablaSim = TablaSimbolos.new padre.id + "." + ultimoID.to_s, nombre
		end
		$idTabla.push(ultimoID+1)
		$idTabla.push(1)
		nuevaTablaSim.set_padre(padre)
		padre.agregarHijo(nuevaTablaSim)
		
		return nuevaTablaSim
	end

end
