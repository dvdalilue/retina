
# Se encarga de los errores de ejecucion de Retina. 
class ErrorEjecucion < RuntimeError

	def initialize(token, tipoError, nombres = nil)
		@token = token
		@tipoError = tipoError
		@nombres = nombres
	end

	def to_s
		puts "Error en la ejecucion:"

		case @tipoError
		when "division por cero"
			"Division por cero."
		
		when "division por cero en division exacta"
			"Division por cero en division exacta."
		
		when "division por cero en resto"
			"Division por cero en resto."
		
		when "division por cero en resto exacto"
			"Division por cero en resto exacto."
		
		when "input invalido"
			"Input invalido '" + @nombres.to_s + "'. Debe ser booleano o numero."	
		
		when "input de tipo booleano esperado"
			"Se espera un input del tipo booleano para la variable '" + @token.operando.nombre + "' y '" + @nombres.to_s + "' es del tipo numero."
		
		when "input de tipo numero esperado"
			"Se espera un input del tipo numero para la variable '" + @token.operando.nombre + "' y '" + @nombres.to_s + "' es del tipo booleano."
		end
	end

end