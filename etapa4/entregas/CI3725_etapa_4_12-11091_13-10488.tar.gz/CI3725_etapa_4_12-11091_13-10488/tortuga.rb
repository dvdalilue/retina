# Clase Tortuga para crear imagenes pbm para el interpretador de Retina
#
# Entrega #4 de Retina
#
# Autores: Alessandra Marrero 12-11091
# 		   Julio Fuenmayor 13-10488

class Tortuga

	def initialize(ancho = 1001, alto = 1001, x = 0, y = 0, inclinacion = 180, dibuja = true)
		@ancho = ancho.to_i
		@alto = alto.to_i
		@x0 = x.to_i
		@y0 = y.to_i
		@inclinacion = inclinacion.to_i
		@dibuja = dibuja
		@pi = Math::PI
		@imagen = Array.new(@alto) { Array.new(@ancho) { 0 } } #Se inicializa un arreglo multidimensional de 0s
		@imagen[centrarX(@x0)][centrarY(@y0)] = 1 # Se marca la posicion inicial de la imagen (centro (0,0))
	end

	#Comprueba si un cierto identificador es una funcion nativa de retina
	def es_funcion_retina(funcion)
		return ["home","openeye", "closeeye","forward", "backward", "rotater", "rotatel", "setposition", "arc"].include? funcion
	end

	#Reconoce una funcion nativa de retina y la ejecuta
	def funcion_retina(funcion, arg1, arg2)
		case funcion
		when "home" 
			home()
		when "openeye" 
			openeye()
		when "closeeye"
			closeeye() 
		when "forward"
			forward(arg1.to_i) 
		when "backward" 
			backward(arg1.to_i)
		when "rotater" 
			rotater(arg1.to_i)
		when"rotatel" 
			rotatel(arg1.to_i)
		when "setposition"
			setposition(arg1.to_i, arg2.to_i) 
		when "arc"
		end
	end

	#Devuelve a la tortuga a la posicion 0,0
	def home()
		@x0 = 0
		@y0 = 0
	end

	#Habilita el dibujado
	def openeye()
		@dibuja = true
	end

	#Deshabilita el dibujado
	def closeeye()
		@dibuja = false
	end

	#Traza una linea recta 'hacia adelante' de 'number' pixeles en una cierta direccion
	def forward(number)
		direccion = @inclinacion * @pi / 180

		#calcula con trigonometria la posicion dentro de la matriz de las nuevas coordenadas
		x1 = (@x0 + number*Math.cos(direccion)).round 
		y1 = (@y0 + number*Math.sin(direccion)).round

		if @dibuja then
			trazar_recta(@x0, @y0, x1, y1)
		end

		@x0 = x1
		@y0 = y1
	end

	#Traza una linea recta 'hacia atras' de 'number' pixeles en una cierta direccion
	def backward(number)
		direccion = @inclinacion * @pi / 180

		x1 = (@x0 - number*Math.cos(direccion)).round
		y1 = (@y0 - number*Math.sin(direccion)).round

		if @dibuja then
			trazar_recta(@x0, @y0, x1, y1)
		end

		@x0 = x1
		@y0 = y1
	end

	#Rota la direccion de dibujado en sentido horario	
	def rotater(number)
		@inclinacion = (@inclinacion - number.to_i) % 360
	end

	#Rota la direccion de dibujado en sentido antihorario
	def rotatel(number)
		@inclinacion = (@inclinacion.to_i + number.to_i).to_i % 360
	end

	#Posiciona a la tortuga en una ciera posicion
	def setposition(x,y)
		@x0 = x.round
		@y0 = y.round
	end

	#Transforma la coordenada cartesiana en una posicion dentro de la matriz
	def centrarX(x)
		return (((@ancho-1)/2) + x).round 
	end

	#Transforma la coordenada cartesiana en una posicion dentro de la matriz
	def centrarY(y)
		return (((@ancho-1)/2) - y).round 
	end

	#Verifica que la posicion (x,y) se encuentra dentro de la matriz
	def puntoValido(x,y)
		return (0 <= y and y <= @ancho and 0 <= x and x <= @alto)
	end

	#Calcula la serie de pares ordenados (x,y) que conformar la recta a ser dibujada
	#se utiliza la ecuacion de la recta punto-pediente para obtener dichos puntos
	# Y - Yo = m(X - Xo)
	def calcular_recta(x0, y0, x1, y1)
		trazo = [] #almacena pares (x,y)

		#Verifica si se va a dibujar una linea en sentido contrario (hacia la izquierda)
		if x0 > x1 then 
			x0, x1 = x1, x0
			y0, y1 = y1, y0
		end

		dx = x1 - x0
		dy = y1 - y0
		y = y0

		#Pendiente no nula:
		if dx != 0 then
			m = dy / dx
			for x in x0..x1
				y = m*(x - x0) + y0
				trazo << {:x => x, :y => y}
			end
		else #Pendiente nula
			if y1 - y0 < 0 then
				y0,y1 = y1, y0
			
				for p in y0..y1
					trazo << {:x => @x0, :y => p}
					y = y + p
				end
			else
				for p in y0..y1
					trazo << {:x => @x0, :y => p}
					y = y + p
				end
			end
		end
		return trazo
	end

	#Se verifica que los pares obtenidos por calcular_recta se encuentren dentro de la matriz
	#y dibuja la imagen
	def trazar_recta(x0, y0, x1, y1)
		recta = calcular_recta(x0,y0, x1, y1)

		recta.each do |par_ordenado|
			x = par_ordenado[:x]
			y = par_ordenado[:y]
			
			if puntoValido(centrarX(x),centrarY(y)) then
				@imagen[centrarX(x)][centrarY(y)] = 1	
			end
		end
	end

	#Retorna como salida un archivo .pbm con el mismo nombre del archivo de entrada en donde
	#se encuentra la imagen dibujada por retina
	def generarImagen()
		nombre = File.basename(ARGV[0], ".rtn")
		nombre << ".pbm"

		output = File.open(nombre, "w")

		output.puts("P1")
		output.puts("#{@alto} #{@ancho}")

		@imagen.each do |x|
			x.each do |y|
				output.print y
				output.print ' '
			end
			output.puts
		end

		output.close
	end



end


#Algunas pruebas:

=begin
tortuga = Tortuga.new(20, 20)


tortuga.rotatel(45)
tortuga.backward(4)
tortuga.rotater(90)
tortuga.backward(4)
tortuga.rotatel(45)
tortuga.backward(4)
tortuga.rotater(175)
tortuga.backward(4)
tortuga.rotatel(45)
tortuga.backward(4)
tortuga.rotatel(45)
tortuga.backward(4)
tortuga.rotatel(45)
tortuga.backward(4)
tortuga.rotatel(45)
tortuga.backward(4)
tortuga.generarImagen()

=end


