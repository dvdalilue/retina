# Entrega #4 de Retina
#
# Autores: Alessandra Marrero 12-11091
# 		   Julio Fuenmayor 13-10488


require_relative 'tortuga'
require_relative 'ErroresEjecucion'

$valorRetorno
$imagen = Tortuga.new

class Interprete

	def initialize ast 
		@ast = ast
	end

	#Interpretar el AST
	def interpretar 
		#puts "Entre a interpretar: "
		#puts @ast.instance_variables
		#puts

		interpretar_contexto(@ast) #aqui hay funciones y bloqueprogram
	end

	# Se comienza a interpretar el AST.
	def interpretar_contexto(arbol)
		#puts "Entre a interpretar_contexto: "
		#puts arbol.instance_variables
		#puts
		interpretador_bloqueprogram(arbol.bloqueprogram) #aqui hay funciones y bloqueprogram

	end

	# Se interpreta el bloque del programa principal.
	def interpretador_bloqueprogram(programa)
		#puts "Entre a interpretar_bloqueprogram: "
		#puts programa.instance_variables
		#puts
		nuevaTablaSim = crearTablaSimbolos()
		interpretador_instrucciones(programa.operando, nuevaTablaSim) #aqui hay operando
	end

	# Se interpretan la lista de instrucciones del programa. 
	def interpretador_instrucciones(instrucciones, tablaSimbolos) 
		ret = interpretador_instrucciones(instrucciones.proxInstr, tablaSimbolos) unless instrucciones.proxInstr.nil?		
		if (ret == "return") then
			return ret1
		end
		interpretador_instruccion(instrucciones.instruccion, tablaSimbolos) unless instrucciones.instruccion.nil?
	end

	# Se interpreta una instruccion. 
	def interpretador_instruccion(instr, tablaSimbolos)
		case instr
		when Condicional
			interpretador_condicional(instr, tablaSimbolos)	
		when Asignacion
			interpretador_asignacion(instr, tablaSimbolos)		
		when Bloque
			interpretador_bloque(instr, tablaSimbolos)		
		when Salida
			interpretador_write(instr, tablaSimbolos)		
		when Entrada
			interpretador_entrada(instr, tablaSimbolos)
		when CicloWhile
			interpretador_cicloWhile(instr, tablaSimbolos)
		when CicloFor
			interpretador_cicloFor(instr, tablaSimbolos)		
		when CicloRepeat
			interpretador_cicloRepeat(instr, tablaSimbolos)
		when LlamadaFunc
			interpretador_llamadaFunc(instr, tablaSimbolos)
		when Retornar
			interpretador_retornar(instr, tablaSimbolos)
			return "return"

		end
	end

		

	def interpretador_condicional(condicional, tablaSimbolos)
		condicion = interpretador_expresion(instr.left, tablaSimbolos)

		if condicion then
			interpretador_instrucciones(instrucciones.middle, tablaSimbolos)
		else
			interpretador_instrucciones(instrucciones.right, tablaSimbolos) unless instrucciones.right.nil?
		end
	end

	def interpretador_asignacion(asignacion, tablaSimbolos) #tiene id y valor
		#puts "ENtre a interpretador_asignacion: "
		#puts asignacion.instance_variables
		identificador = asignacion.id.nombre
		#puts identificador.instance_variables
		valor = interpretador_expresion(asignacion.valor, tablaSimbolos)
		#puts "Valor: " + valor.to_s
		#puts "Identificador: " + identificador.to_s
		#puts "Identificador: " + identificador.to_s
		#puts "Valor: " + valor.to_s
		tablaSimbolos.set_valor(identificador, valor)
		#puts "Actualice #{identificador} con: " + tablaSimbolos.buscar(identificador)
	end

	# Devuelve el valor almacenado en una variable
	def interpretador_identificador(id, tablaSimbolos) 
		#puts "Entre a interpretador_identificador: "
		#puts id.instance_variables
		nombre = id.nombre
		#puts "Identificador tiene: "
		#puts identificador

		#puts identificador
		return tablaSimbolos.buscar_valor(nombre)
	end

	def interpretador_bloque(bloque, tablaSimbolos)
		nuevaTablaSim = crearTablaSimbolos(tablaSimbolos)
		interpretador_declaraciones(bloque.declaraciones, nuevaTablaSim)
		interpretador_instrucciones(bloque.instrucciones, nuevaTablaSim)
	end


	def interpretador_declaraciones(declaraciones, tablaSimbolos)
		#puts "Declaraciones>> #{declaraciones.decl.nil?}"
		interpretador_declaracion(declaraciones.decl, tablaSimbolos) unless declaraciones.decl.nil?
		interpretador_declaraciones(declaraciones.proxDecl, tablaSimbolos) unless declaraciones.proxDecl.nil?
	end



	def interpretador_declaracion(declaracion, tablaSimbolos)
		#puts "Entre a interpretador declaracion: "
		tipo = declaracion.tipo.tipo
		#puts "Tipo de declaracion: " + tipo.to_s
		#puts "Tipo: "
		#puts tipo
		#puts "Declaracion: "
		#puts declaracion.instance_variables
		if (not declaracion.asignacion.nil?) then 
			#puts "Declaracion: "
			#puts declaracion.instance_variables
			#puts "-> @asignacion: "
			#puts declaracion.asignacion.instance_variables
			#puts declaracion.asignacion.id.nombre
			#puts declaracion.asignacion.valor.digito

			id = declaracion.asignacion.id.nombre
			#puts "id: " + id
			tablaSimbolos.insertar(id, tipo)
			#puts "La asignacion tiene: "
			#puts declaracion.asignacion.instance_variables
			interpretador_asignacion(declaracion.asignacion, tablaSimbolos)
		else 
			tipo = declaracion.tipo.tipo
			if (tipo.eql? "number") then 
				valor = 0
			elsif(tipo.eql? "boolean") then 
				valor = false
			end 
			#puts "interpretador declaracion: #{declaracion.identificador}"
			#puts "interpretador declaracion1: #{declaracion.identificador.proxID.nombre}"
			#puts "interpretador declaracion2: #{declaracion.identificador.id.nombre}"
			interpretador_identificadores(declaracion.identificador, tipo, valor, tablaSimbolos)
		end 
	end 



	def interpretador_identificadores(identificadores, tipo, valor, tablaSimbolos)

		ident = identificadores.id.nombre
		tablaSimbolos.insertar(ident, tipo)
		tablaSimbolos.set_valor(ident, valor)
		analizador_identificadores(identificadores.proxID, tipo, valor, tablaSimbolos) unless identificadores.proxID.nil?
	end
	


	def interpretador_write(salida, tablaSimbolos)
		interpretador_argSalida(salida.argSalida, tablaSimbolos, salida.saltoLinea) unless salida.argSalida.nil?
		interpretador_salida(salida.ultimoElem, tablaSimbolos, true)
	end



	def interpretador_salida(salida, tablaSimbolos, newline, last = false)

		# If item is not a string, then evaluate the expression
		if(not salida.instance_of? String_) then
			output = interpretador_expresion(salida, tablaSimbolos)
		# salida is a string
		else
			# Remove quotation marks from the beginning and end of the token
			output = salida.valor[1..-2]
			# Remove escape characters
			i = 0
			while(i < output.length) do
				if(output[i].eql? '\\') then
					output[i]=''
				end
				i = i + 1
			end
			# Insert newline characters
			i = 0
			while(i < output.length-1) do
				if(output[i].eql? '\\' and output[i+1].eql? 'n') then
					output[i]="\n"
					output[i+1]=''
				end
				i = i + 1
			end
		end

		# Print salida to standard output
		if(newline) then
			# Print newline after the salida
			$stdout.puts output
		else
			print output
			# Print space character for following salidas if not last
			if(not last) then
				print " "
			end
			$stdout.flush
		end
	end

	
	def interpretador_argSalida(argSalida, tablaSimbolos, newline)
		interpretador_argSalida(argSalida.izquierda, tablaSimbolos, newline) unless argSalida.izquierda.nil?
		interpretador_salida(argSalida.derecha, tablaSimbolos, newline) unless argSalida.derecha.nil?
	end
	
	def interpretador_entrada(entrada, tablaSimbolos)
		id = entrada.operando.nombre
		tipo = tablaSimbolos.buscar(id)

		input = $stdin.gets
		input = input.chomp
		input = input.lstrip
		input = input.rstrip

		if(input.eql? "true") then 
			valor = true
		elsif(input.eql? "false") then 
			valor = false
		elsif(input =~ /\A([1-9][0-9]*|0)(\.[0-9]+)?\z/) then 
			valor = input.to_f
		else 
			raise ErrorEjecucion.new entrada, "input invalido", input
		end

		if(tipo.eql? "boolean") then
			if((not valor.eql? true) and (not valor.eql? false)) then
				raise ErrorEjecucion.new entrada, "input de tipo booleano esperado", valor
			end
		elsif(tipo.eql? "number") then
			if(not valor.is_a? Numeric) then
				raise ErrorEjecucion.new entrada, "input de tipo numero esperado", valor
			end
		end
		tablaSimbolos.set_valor(id, valor)

	end

	def interpretador_cicloWhile(instr, tablaSimbolos)
		condicion = interpretador_expresion(instr.condicion, tablaSimbolos)
		while(condicion) do 
			interpretador_instrucciones(instr.instruccion, tablaSimbolos)
			condicion = interpretador_expresion(instr.condicion, tablaSimbolos)
		end
	end

	def interpretador_cicloFor(instr, tablaSimbolos)		
		nuevaTablaSim = crearTablaSimbolos(tablaSimbolos)
		contador =  instr.contador.nombre
		#ints = instr.intervaloSuperior.nombre.dup
		#inti = instr.intervaloInferior.nombre.dup
		nuevaTablaSim.insertar(contador, "number")
		
		#puts "ints : #{interpretador_expresion(instr.intervaloSuperior, nuevaTablaSim)}"
		
		#nuevaTablaSim.insertar(ints, "number")
		#nuevaTablaSim.insertar(inti, "number")
		intervaloInferior = interpretador_expresion(instr.intervaloInferior, nuevaTablaSim).to_i
		intervaloSuperior = interpretador_expresion(instr.intervaloSuperior, nuevaTablaSim).to_i
		nuevaTablaSim.set_valor(contador, intervaloInferior)
		#puts "contador> #{intervaloInferior}"
		#puts "variable: #{intervaloInferior}"
		#puts "Entre a interpretar for:"
		#puts "intervalo inferior: #{intervaloInferior}"


		if(instr.incremento.nil?) then 
			#intervaloInferior = intervaloInferior.floor
			#intervaloSuperior = intervaloSuperior.floor
			nuevaTablaSim.set_valor(contador, intervaloInferior)
			valorContador = intervaloInferior
			while((intervaloInferior <= valorContador) and (valorContador <= intervaloSuperior)) do 
				interpretador_instrucciones(instr.instruccion, nuevaTablaSim)
				valorContador = nuevaTablaSim.buscar_valor(contador).to_i
				intervaloInferior = interpretador_expresion(instr.intervaloInferior, nuevaTablaSim)
				intervaloSuperior = interpretador_expresion(instr.intervaloSuperior, nuevaTablaSim)
				intervaloInferior = intervaloInferior.to_i.floor
				intervaloSuperior = intervaloSuperior.to_i.floor
				valorContador = valorContador + 1
				nuevaTablaSim.set_valor(contador, valorContador)
			end
		elsif(not instr.incremento.nil?) then 
			incremento = interpretador_expresion(instr.incremento, nuevaTablaSim)
			nuevaTablaSim.set_valor(contador, intervaloInferior)
			valorContador = intervaloInferior.to_i
			while((intervaloInferior <= valorContador) and (valorContador <= intervaloSuperior)) do 
				interpretador_instrucciones(instr.instruccion, nuevaTablaSim)
				valorContador = nuevaTablaSim.buscar_valor(contador).to_i
				intervaloInferior = interpretador_expresion(instr.intervaloInferior, nuevaTablaSim).to_i
				intervaloSuperior = interpretador_expresion(instr.intervaloSuperior, nuevaTablaSim).to_i
				incremento = interpretador_expresion(instr.incremento, nuevaTablaSim).to_i
				valorContador = valorContador + incremento
				nuevaTablaSim.set_valor(contador, valorContador)
			end
		end
	end

	def interpretador_cicloRepeat(instr, tablaSimbolos)
		i = 1
		valorExpresion = interpretador_expresion(instr.expresion, tablaSimbolos).to_i
		while((1 <= i) and (i <= valorExpresion.to_i)) do 
			interpretador_instrucciones(instr.instruccion, tablaSimbolos)
			valorExpresion = interpretador_expresion(instr.expresion, tablaSimbolos).to_i
			i = i+1
		end

	end

	def interpretador_llamadaFunc(funcion, tablaSimbolos)
		nombre = funcion.nombre.nombre
		if($imagen.es_funcion_retina(nombre)) then 
			if (not funcion.attrs.nil?) then 
				arg1 = funcion.attrs.izquierda
				if (not funcion.attrs.attrs.nil?) then 
					arg2 = funcion.attrs.derecha
				end
			end
			arg1 = interpretador_expresion(arg1, tablaSimbolos) unless arg1.nil?
			arg2 = interpretador_expresion(arg2, tablaSimbolos) unless arg2.nil?

			$imagen.funcion_retina(nombre, arg1, arg2)
			return; 
		end;

		defFuncion = funcion.defFuncion
		puts "funcion>> defFuncion"
		tablaSimbolosFunc = crearTablaSimbolos()
		interpretador_argumentos(funcion.attrs, defFuncion.parametros ,tablaSimbolos, tablaSimbolosFunc)
		interpretador_instrucciones(defFuncion.bloqueinstr, tablaSimbolosFunc)
		return $valorRetorno
	end


	def interpretador_argumentos(args, params, tablaSimbolos, tablaSimbolosFunc)
		if(not args.nil?) then 
			valorArg = interpretador_expresion(args.izquierda, tablaSimbolos)
			#puts params.instance_variables
			nombreParam = params.param.identificador
			tipoParam = params.param.tipo
			tablaSimbolosFunc.insertar(nombreParam, tipoParam)
			tablaSimbolosFunc.set_valor(nombreParam, valorArg)
			interpretador_argumentos(args.derecha, params.parametros, tablaSimbolos, tablaSimbolosFunc)
		end
	end

	# Se interpretan las instrucciones de retorno. 
	def interpretador_retornar(instr, tablaSimbolos)
		if(instr.operando.nil?) then 
			$valorRetorno = nil
		else 
			$valorRetorno = interpretador_expresion(instr.operando, tablaSimbolos)
		end
	end

	# Se interpreta una expresion. 
	def interpretador_expresion(expresion, tablaSimbolos)
		case expresion
		when Booleano
			return interpretador_booleano(expresion)
		when Digito
			return interpretador_digito(expresion)
		when Identificador
			return interpretador_identificador(expresion, tablaSimbolos)
		when LogicoBinario
			return interpretador_logicoBinario(expresion, tablaSimbolos)
		when LogicoUnario
			return interpretador_logicoUnario(expresion, tablaSimbolos)
		when Comparacion
			return interpretador_comparacion(expresion, tablaSimbolos)
		when AritmeticaBinaria
			return interpretador_aritmeticaBinaria(expresion, tablaSimbolos)
		when AritmeticaUnaria
			return interpretador_aritmeticaUnaria(expresion, tablaSimbolos)
		when LlamadaFunc
			return interpretador_llamadaFunc(expresion, tablaSimbolos)
		end
	end

	def interpretador_booleano(expresion)
		valor = expresion.valor

		if (valor == "true") then
			return true
		elsif(valor == 'false') then
			return false
		end
	end

	def interpretador_digito(expresion)
		valor = expresion.digito
		return valor
	end

	def interpretador_logicoBinario(instr, tablaSimbolos)
		#puts "Entre a interpretador_logicoBinario"
		opIzqda = interpretador_expresion(instr.izquierda, tablaSimbolos)
		opDerecha = interpretador_expresion(instr.derecha, tablaSimbolos)
		operador = instr.op

		#puts "op izquierda: #{opIzqda}"
		#puts "op derecha: #{opDerecha}"
		#puts "operador: #{operador}"

		if (operador.eql? "Conjuncion") then 
			return (opIzqda and opDerecha)
		elsif (operador.eql? "Disjuncion") then
			return (opIzqda or opDerecha)
		end

		#Falta error?
	end

	def interpretador_logicoUnario(instr, tablaSimbolos)
		#puts "Entre a logico unario"
		valor = interpretador_expresion(instr.operando, tablaSimbolos)
		operador = instr.operador
		if(operador.eql? "Negacion Logica") then
			return (not valor)
		end
	end


	def interpretador_comparacion(instr, tablaSimbolos)
		opIzqda = interpretador_expresion(instr.izquierda, tablaSimbolos)
		opDerecha = interpretador_expresion(instr.derecha, tablaSimbolos)
		operador = instr.op
		
		if (operador.eql? "Equivalente") then
			return opIzqda.to_i == opDerecha.to_i
		elsif (operador.eql? "Diferente") then
			return opIzqda.to_i != opDerecha.to_i
		elsif (operador.eql? 'Mayor Igual') then
			return opIzqda.to_i >= opDerecha.to_i
		elsif (operador.eql? 'Menor Igual') then  
			return opIzqda.to_i <= opDerecha.to_i
		elsif (operador.eql? 'Mayor') then 
			return opIzqda.to_i > opDerecha.to_i
		elsif (operador.eql? 'Menor') then
			return opIzqda.to_i < opDerecha.to_i
		end

		# Falta error? 

	end

	def interpretador_aritmeticaBinaria(instr, tablaSimbolos)
		opIzqda = interpretador_expresion(instr.izquierda, tablaSimbolos)
		opDerecha = interpretador_expresion(instr.derecha, tablaSimbolos)

		operando = instr.op

		if (operando.eql? "Suma") then
			return (opIzqda.to_i + opDerecha.to_i)
		elsif (operando.eql? "Resta") then
			return (opIzqda.to_i - opDerecha.to_i)
		elsif (operando.eql? "Multiplicacion") then
			return (opIzqda.to_i * opDerecha.to_i)
		elsif (operando.eql? "Division") then
			if(opDerecha.to_i.eql? 0.0) then
				raise ErrorEjecucion.new instr, "division por cero"
			end
			return (opIzqda.to_i / opDerecha.to_i).truncate 
		elsif (operando.eql? "Resto") then
			if(opDerecha.to_i.eql? 0.0) then
				raise ErrorEjecucion.new instr, "division por cero en resto"
			end
			return (opIzqda.to_i % opDerecha.to_i).truncate
		elsif (operando.eql? "Division exacta") then
			if(opDerecha.to_i.eql? 0.0) then
				raise ErrorEjecucion.new instr, "division por cero en division exacta"
			end
			return (opIzqda.to_i / opDerecha.to_i) 
		elsif (operando.eql? "Resto exacto") then
			if(opDerecha.to_i.eql? 0.0) then
				raise ErrorEjecucion.new instr, "division por cero en resto exacto"
			end
			return (opIzqda.to_i % opDerecha.to_i)
		end
	end

	def interpretador_aritmeticaUnaria(instr, tablaSimbolos)
		valor = interpretador_expresion(instr.operando, tablaSimbolos)
		operador = instr.operador
		if(operador.eql? "Negacion Aritmetica") then
			return (-valor)
		end
	end

	def crearTablaSimbolos(padre=nil)
		nuevaTablaSim = TablaSimbolos.new
		nuevaTablaSim.set_padre(padre)
		return nuevaTablaSim
	end

end
