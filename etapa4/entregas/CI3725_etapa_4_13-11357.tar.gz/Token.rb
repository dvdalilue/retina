#! /usr/bin/ruby

# Proyecto de Traductores e Interpretadores [CI3725]
# César Silva // 13-11357
# Tokens

# Clase Token
class Token 
    attr_reader :value, :line, :column

    def initialize(value, line, column)
        @value = value # Valor al hacer match 
        @line = line # Numero de la linea donde se encuentra el token
        @column = column # Numero de la columna donde se encuentra el token
    end
  
    def to_s
        "linea #{@fila}, columna #{@columna}: #{self.class.name} '#{@texto}'"
    end
   
end

# Regexs para identificar los tokens
tok = {
 'Tipo' => /\A(boolean|number)\b/,
 'Number' => /\A[0-9]+(\.[0-9]+)?/,
 'Boolean' => /\A(true|false)\b/,
 'Flecha' => /\A\->/,
 'PuntoYComa' => /\A;/,
 'Coma' => /\A,/,
 'AbreParentesis' => /\A\(/,
 'CierraParentesis' => /\A\)/,
 'Igual' => /\A==/,
 'Diferente' => /\A\/=/,
 'MenorIgualQue' => /\A<=/,
 'MayorIgualQue' => /\A>=/,
 'MenorQue' => /\A</,
 'MayorQue' => /\A>/,
 'Asignacion' => /\A=/,
 'Suma' => /\A\+/,
 'Resta' => /\A\-/,
 'Multiplicacion' => /\A\*/,
 'Division' => /\A\//,
 'Modulo' => /\A%/,
 'Id' => /\A[a-z][a-zA-Z0-9_]*/,
 'String' => /\A\"([^\"\\\n]|(\\[\\\"n]))*\"/
}

# Palabras reservadas del lenguaje
palabras_reservadas = %w(program by not and or mod div read write writeln with do end if then else while for from to repeat times begin func return)
pr = Hash::new

# Agregamos las palabras reservadas a una Tabla de Hash de tal forma que su clave sea ella misma capitalizada y su valor sea su regex.
palabras_reservadas.each do |w| 
    pr[w.capitalize] = /\A#{w}\b/ 
end

# Unimos las tablas de hash con los tokens y las palabras reservadas para asi tenerlos en una sola variable global
$tokens = pr.merge(tok)

# Ahora creamos dinamicamente una clase para cada token, de forma que hereden sus caracteristicas de la clase Token.
$tokens.each do |token, regex|
    nueva_clase = Class::new(Token) do # Creacion dinamica de clases
        @regex = regex # Expresion regular 

        # Constructor de las clases
        def initialize(value, line, column)
            @value = value  
            @line = line    
            @column = column 
        end
    end
    Object::const_set("Tk#{token}", nueva_clase) # Le damos nombre a la clase
end
