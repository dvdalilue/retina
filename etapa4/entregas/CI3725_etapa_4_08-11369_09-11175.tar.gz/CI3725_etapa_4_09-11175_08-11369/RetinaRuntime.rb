=begin
  Proyecto 4 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Excepciones a tiempo de ejecucion
class RetinaRuntimeException < RuntimeError

    def initialize(tipoError, elementoPosicion, datosMsj, lineaColumna = nil)
        @tipoError = tipoError
        @elementoPosicion = elementoPosicion
        @datosMsj = datosMsj
        @lineaColumna = lineaColumna.nil? ? @elementoPosicion.getLineaColumna : lineaColumna
    end

    def to_s

        # Obtiene los numeros de linea y columna
        linea, columna = @lineaColumna


        # Determina el mensaje segun el tipo de error
        str = "\nError: "
        case @tipoError
        when 'variableYaDefinida'
            str += "la variable '%<nombreVariable>s' ya se encuentra definida"

        when 'variableNoDefinida'
            str += "la variable '%<nombreVariable>s' no ha sido definida"

        when 'funcionNoDefinida'
            str += "la función '%<nombreFuncion>s' no ha sido definida"

        when 'funcionNoDevolvioRetorno'
            str += "la función '%<nombreFuncion>s' no devolvió un valor de retorno"

        when 'parametroFuncionNoInicializado'
            str += "el parametro '%<nombreParametro>s' de la función '%<nombreFuncion>s' no fue inicializado"

        when 'returnFueraDeFuncion'
            str += "la instrucción 'return' se encuentra declarada fuera de una función"

        when 'operacionResultadoInvalido'
            str += "la operación '%<expresion>s' generó una expresión ('%<valor>s') que no es de tipo '%<tipoEsperado>s'"

        when 'operacionNumeroInvalidoOverflow'
            str += "la operación '%<expresion>s' generó un número ('%<valor>s') no representable por la máquina"

        when 'divisionPor0'
            str += "no es posible realizar la operación. Division por 0"

        when 'expresionReadTipoInvalido'
            str += "la expresión '%<expresion>s' ingresada no es de tipo '%<tipoEsperado>s'"

        when 'forMutableIdentificador'
            str += "'for' con iteraciones indeterminadas: el identificador recibio una modificación no deseada"

        when 'forMutableExpresion'
            str += "'for' con iteraciones indeterminadas: la expresion '%<forPart>s' recibio una modificación no deseada"

        when 'imagenNoGenerada'
            str += "no pudo generarse la imagen final asociada al programa ejecutado"

        end

        # Formatea el mensaje segun los datos adecuados
        str = str % @datosMsj

        # Incluye linea y columna
        if !linea.nil? and !columna.nil?
            str += " [lin: #{linea}, col: #{columna}]"
        end

        str
    end
end
