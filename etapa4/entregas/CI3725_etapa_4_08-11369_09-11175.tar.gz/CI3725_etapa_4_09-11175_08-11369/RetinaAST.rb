=begin
  Proyecto 4 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end



# Valores default para los tipos
BOOLEAN_DEFAULT_VAL = false
NUMBER_DEFAULT_VAL = 0


# Identacion default
INDENT_DEFAULT = 2


# Indicadores para manejo de llamadas a funciones
# durante la evaluacion del AST
$llamadaFuncionDetenerInstruccionesPorReturn = false



# Identa un string la cantidad de espacios indicado
def indent(str, pad = INDENT_DEFAULT)
    str.to_s.rjust(str.to_s.length + pad, ' ') + "\n"
end


# Construye la excepcion de tipo invalido segun los tipos de nodos y expresiones indicadas
def raiseErrorExpresionTipoInvalido(expresionBase, expresionChequeo, elementoPosicion)

    # Construcciones para poder hacer las comparaciones de tipos
    nodoBoolean = ArbolExpresionBooleana.new(TkBoolean.new(0, 0, BOOLEAN))
    nodoNumber = ArbolLiteralNumerico.new(TkNumber.new(0, 0, NUMBER))
    case expresionBase
        when BOOLEAN
            expresionBase = nodoBoolean
        when NUMBER
            expresionBase = nodoNumber
    end

    case expresionChequeo
        when BOOLEAN
            expresionChequeo = nodoBoolean
        when NUMBER
            expresionChequeo = nodoNumber
    end


    if expresionChequeo.class.name == 'ArbolFuncionLlamada'
        # Caso llamada funcion

        if expresionChequeo.getTipo().nil?
            raise RetinaContextException.new('llamadaFuncionTipoNulo', elementoPosicion,
                {nombreFuncion: expresionChequeo.getNombre(), tipoEncontrado: expresionChequeo.getTipo(),
                    tipoEsperado: expresionBase.getTipo()})
        else
            raise RetinaContextException.new('llamadaFuncionTipoInvalido', elementoPosicion,
                {nombreFuncion: expresionChequeo.getNombre(), tipoEncontrado: expresionChequeo.getTipo(),
                    tipoEsperado: expresionBase.getTipo()})
        end

    else
        # Caso default: cualquier otra expresion
        raise RetinaContextException.new('expresionTipoInvalido', elementoPosicion,
            {expresion: expresionChequeo.toCode(), tipoEncontrado: expresionChequeo.getTipo(), tipoEsperado: expresionBase.getTipo()})
    end

end


# Chequea que el valor indicado es del tipo indicado
# Se usa para chequear que el resultado de una operacion
# sea efectivamente del tipo esperado
def checkValorByType(valor, tipoExpresion, expresion)

    if tipoExpresion == NUMBER

        if [Float::INFINITY, Float::NAN].include?(valor)
            raise RetinaRuntimeException.new('operacionNumeroInvalidoOverflow', expresion,
                {expresion: expresion.toCode(), valor: valor})
        end

        if !valor.is_a?(Numeric)
            raise RetinaRuntimeException.new('operacionResultadoInvalido', expresion,
                {expresion: expresion.toCode(), valor: valor, tipoEsperado: tipoExpresion})
        end
    end

    if tipoExpresion == BOOLEAN && ![true, false].include?(valor)
        raise RetinaRuntimeException.new('operacionResultadoInvalido', expresion,
                {expresion: expresion.toCode(), valor: valor, tipoEsperado: tipoExpresion})
    end

end



# Nodos del arbol sintactico abstracto
class RetinaASTNode
    attr_reader :tipoNodo
    attr_accessor :valor


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable = nil)

        # No continua si esta marcado para no chequearse
        if @noCheck
            return
        end

        # Si se indica, genera un nuevo scope local
        if @localScope
            @symTable = RetinaSymTable.new(self, parentSymTable)

            # Agrega el programa como subalcance de su padre
            parentSymTable.agregarSubAlcance(@symTable)

            parentSymTable = @symTable
        end

        # Chequeo de cada sub-nodo definido
        getChildNodes().each do |nodeName, node|

            if node.nil?
                next
            end

            node.check(parentSymTable)
        end
    end


    # Evalua el nodo y obtiene su valor
    def evaluate(parentSymTable = nil)

        # No continua si esta marcado para no evaluarse
        if @noEvaluate
            return
        end

        # Si existe local scope, se revisa en su tabla de simbolos
        if @localScope
            parentSymTable = @symTable
        end

        # Evaluacion de cada sub-nodo definido
        getChildNodes().each do |nodeName, node|

            if node.nil?
                next
            end

            node.evaluate(parentSymTable)
        end

    end


    # Obtiene la linea y columna asociados al nodo
    def getLineaColumna

        lineaColumna = [0, 0]
        if @tokenInicio
            lineaColumna = [@tokenInicio.linea, @tokenInicio.columna]
        end

        lineaColumna
    end


    # Representacion en string del nodo
    def printAST(identacion = 0)

        # Primera parte del arbol: nombre
        str = @tipoNodo +":"
        if !@linea.nil?
            str += " (linea: #{@linea})"
        end
        str = indent(str, identacion)

        identacion += INDENT_DEFAULT
        indentacionNext = identacion + INDENT_DEFAULT

        # Segunda parte del arbol: nodos hijos
        getNodes().each do |nodeName, node|

            if node.nil?
                next
            end

            # Separa en espacios
            nodeName = nodeName.gsub(/(?=[A-Z])/, ' ').strip.downcase
            str += indent("#{nodeName}:", identacion)
            str += node.printAST(indentacionNext)
        end

        str
    end


    # Obtiene los nodos hijos del nodo actual
    # a traves de la obtencion de los atributos de la clase
    # Excluye los atributos que no son nodos del arbol y que son de utilidad para metadata
    def getChildNodes
        excludeList = ['tipoNodo', 'tokenInicio', 'operador', 'parentesis', 'tipoExpresion', 'tipoOperandoEsperado',
            'symTable', 'globalScope', 'localScope', 'noCheck', 'tieneInstruccionReturn', 'tipoLlamadaFuncion',
            'noEvaluate', 'pilaValor']

        nodeList = []
        instance_variables.map do |attribute|
            # Saca el "@" del nombre del atributo
            attributeName = attribute.to_s[1..-1]

            if !excludeList.include?(attributeName)
                nodeList.push([attributeName, instance_variable_get(attribute)])
            end
        end

        nodeList
    end
end



# Root del Arbol sintactico abstracto
class RetinaAST < RetinaASTNode
    attr_reader :symTable

    def initialize(funciones, program)
        @tipoNodo = "RetinaAST"
        @globalScope = true

        @funciones = funciones
        @program = program
    end


    # Realiza los chequeos estaticos y de contexto
    def check

        # Tabla de simbolos del scope global
        @symTable = RetinaSymTable.new(self)

        # Agrega funciones de movimiento al scope global
        self.agregarFuncionesMovimiento()


        # Chequeo funciones
        if @funciones
            @funciones.check(@symTable)
        end

        # Chequeo programa
        @program.check(@symTable)
    end


    # Evalua el nodo
    def evaluate

        # Evaluacion del programa
        @program.evaluate(@symTable)
    end



    # Agrega funciones de movimiento al scope global
    # Utiliza las herramientas provistas por el lexer y parser
    # para poder normalizar los chequeos estaticos
    def agregarFuncionesMovimiento

        # Definicion de funciones de movimiento
        tokenInicio = TkFunc.new(0, 0, 'func')
        parametros1 = ArbolFuncionParams.new(ArbolTipo.new(TkNumber.new(0, 0, NUMBER)), TkIdentificador.new(0, 0, 'num1'))
        parametros2 = ArbolFuncionParams.new(ArbolTipo.new(TkNumber.new(0, 0, NUMBER)), TkIdentificador.new(0, 0, 'num1'),
                        ArbolFuncionParams.new(ArbolTipo.new(TkNumber.new(0, 0, NUMBER)), TkIdentificador.new(0, 0, 'num2')))

        home = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'home'), nil, nil, nil)
        openeye = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'openeye'), nil, nil, nil)
        closeeye = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'closeeye'), nil, nil, nil)
        forward = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'forward'), parametros1.clone, nil, nil)
        backward = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'backward'), parametros1.clone, nil, nil)
        rotatel = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'rotatel'), parametros1.clone, nil, nil)
        rotater = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'rotater'), parametros1.clone, nil, nil)
        setposition = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'setposition'), parametros2.clone, nil, nil)
        arc = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'arc'), parametros2.clone, nil, nil)

        # Verifica cada funcion y la agrega a la tabla de simbolos global
        listaFunciones = [home, openeye, closeeye, forward, backward, rotatel, rotater, setposition, arc]
        listaFunciones.each do |funcion|
            funcion.check(@symTable, true)
        end

    end
end


# Arbol de las reglas FUNCIONES
class ArbolFuncionList < RetinaASTNode

    def initialize(funcion, funcionList = nil)
        @funcion = funcion
        @funcionList = funcionList
    end


    def printAST(identacion)

        str = @funcion.printAST(identacion)

        if @funcionList
            str += @funcionList.printAST(identacion)
        end

        str
    end

end



# Arbol de las reglas FUNCION
class ArbolFuncion < RetinaASTNode
    attr_reader :parametros, :tipoRetorno
    attr_accessor :tieneInstruccionReturn

    def initialize(tokenInicio, identificador, parametros, tipoRetorno, instrucciones)
        @tipoNodo = "FUNCION"
        @localScope = true
        @tokenInicio = tokenInicio
        @tieneInstruccionReturn = nil

        @identificador = ArbolIdentificador.new(identificador)
        @parametros = parametros
        @tipoRetorno = tipoRetorno
        @instrucciones = instrucciones
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable, reserved = nil)

        # Chequea que no exista una funcion con el mismo nombre
        if parentSymTable.lookupFuncion(self)
            raise RetinaContextException.new('funcionYaDefinida', self, {nombreFuncion: @identificador.getNombre})
        end

        # Nuevo scope, nueva tabla de simbolos
        @symTable = RetinaSymTable.new(self, parentSymTable)

        # Si es una funcion reservada, no debe ser posible imprimirla en el arbol
        if reserved
            @symTable.reserved = true
        end

        # Agrega la funcion como subalcance de root
        parentSymTable.agregarSubAlcance(@symTable)

        # Verifica los parametros
        if @parametros
            @parametros.check(@symTable)
        end

        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(@symTable)
        end

        # Si existe tipo de retorno, verifica que exista
        # al menos una instruccion return
        if @tipoRetorno && !@tieneInstruccionReturn
            raise RetinaContextException.new('funcionRequiereReturn', self,
                {nombreFuncion: self.getNombre(), tipo: @tipoRetorno.getNombre()})
        end
    end


    # Evalua la funcion. Los parametros debieron haber sido inicializados
    # con los valores de los argumentos al momento de la llamada
    def evaluate(parentSymTable, llamadaFuncion)

        # Evalua los parametros
        if @parametros
            @parametros.evaluate(@symTable, llamadaFuncion)
        end


        if !@symTable.reserved
            # Caso 1: funciones definidas en el programa

            # Evalua las instrucciones
            if @instrucciones
                @instrucciones.evaluate(@symTable)
            end

        else
            # Caso 2: funciones reservadas de Retina

            # Ejecuta las acciones para la salida de la imagen de Retina
            methodName = self.getNombre()
            case methodName
            when 'home', 'openeye', 'closeeye'
                $retinaImage.method(methodName).call

            when 'forward', 'backward', 'rotatel', 'rotater'
                $retinaImage.method(methodName).call(@parametros.getValor())

            when 'setposition', 'arc'
                $retinaImage.method(methodName).call(@parametros.getValor(), @parametros.funcionParams.getValor())

            end
        end


        # Si existe tipo de retorno, verifica que se haya
        # calculado un valor de retorno para la misma
        if @tipoRetorno && @valor.nil?
            raise RetinaRuntimeException.new('funcionNoDevolvioRetorno', llamadaFuncion, {nombreFuncion: self.getNombre()})
        end

    end


    # Obtiene el valor de retorno de la funcion
    def getValor
        @valor
    end


    # Obtiene el nombre de la funcion
    def getNombre
        @identificador.getNombre
    end


    # Obtiene el numero de parametros de la funcion
    def getNumeroParametros

        numParams = 0
        if @parametros

            param = @parametros
            while param
                param = param.funcionParams
                numParams = numParams + 1
            end
        end

        numParams
    end


    # Permite indicar que la funcion tiene una instruccion
    # return definida en su alcance
    def setTieneInstruccionReturn
        @tieneInstruccionReturn = true
    end
end


# Arbol de las reglas FUNCION_PARAMS
class ArbolFuncionParams < RetinaASTNode
    attr_reader :funcionParams

    def initialize(tipo, identificador, funcionParams = nil)
        @tipoNodo = "PARAMETRO"

        @tipo = tipo
        @identificador = ArbolIdentificador.new(identificador)
        @funcionParams = funcionParams
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable)

        # Agrega el parametro como variable
        @identificador.tipoExpresion = @tipo.valor
        parentSymTable.agregarVariable(@identificador)

        if @funcionParams
            @funcionParams.check(parentSymTable)
        end
    end


    # Evalua el nodo
    def evaluate(parentSymTable, llamadaFuncion)

        # Si el valor es nulo, es porque la llamada a la funcion
        # no logro copiar el valor correctamente
        if @identificador.valor.nil?
            raise RetinaRuntimeException.new('parametroFuncionNoInicializado', llamadaFuncion,
                {nombreParametro: @identificador.getNombre(), nombreFuncion: parentSymTable.alcanceObject.getNombre()})
        end

        # Evalua el resto de parametros
        if @funcionParams
            @funcionParams.evaluate(parentSymTable, llamadaFuncion)
        end
    end


    # Actualiza el valor del parametro
    def setValor(parentSymTable, valor = nil)

        # Actualiza el valor del parametro en la tabla de simbolos de la funcion
        @identificador.valor = valor
        parentSymTable.actualizarVariable(@identificador)
    end


    # Obtiene el valor del parametro
    def getValor
        @identificador.valor
    end


    # Obtiene el tipo del parametro
    def getTipo
        @tipo.valor
    end


    def printAST(identacion)

        str = indent("#{@tipoNodo}:", identacion)
        identacionParametro = identacion + INDENT_DEFAULT
        indentacionNext = identacionParametro + INDENT_DEFAULT

        str += indent("tipo:", identacionParametro)
        str += @tipo.printAST(indentacionNext)

        str += indent("nombre:", identacionParametro)
        str += @identificador.printAST(indentacionNext)

        if @funcionParams
            str += @funcionParams.printAST(identacion)
        end

        str
    end

end


# Arbol de las reglas FUNCION_RETURN
class ArbolFuncionReturn < RetinaASTNode
    attr_accessor :expresion

    def initialize(tokenInicio, expresion)
        @tipoNodo = "RETORNO FUNCION"
        @expresion = expresion
        @tokenInicio = tokenInicio
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable)

        # Identifica la funcion a la cual pertenece el return
        funcionAlcance = parentSymTable.getSuperAlcancePorTipo('funcion')
        if funcionAlcance.nil?
            raise RetinaContextException.new('returnFueraDeFuncion', self, {})
        end
        funcion = funcionAlcance.alcanceObject


        # Verifica la funcion tenga tipo de retorno
        if funcion.tipoRetorno.nil?
            raise RetinaContextException.new('funcionNoTieneTipoRetorno', self, {nombreFuncion: funcion.getNombre()})
        end


        # Verifica la expresion sea correcta y sea del tipo de retorno de la funcion
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != funcion.tipoRetorno.valor
            raise RetinaContextException.new('funcionReturnTipoInvalida', @expresion, {tipoEncontrado: @expresion.getTipo(),
                nombreFuncion: funcion.getNombre(), tipoEsperado: funcion.tipoRetorno.valor})
        end

        # Actualiza la funcion, indicando que existe una instruccion return en su interior
        funcion.setTieneInstruccionReturn()
    end


    def evaluate(parentSymTable)

        # Evalua la expresion
        @expresion.evaluate(parentSymTable)

        # Obtiene la funcion a la cual pertenece el return
        funcionAlcance = parentSymTable.getSuperAlcancePorTipo('funcion')
        if funcionAlcance.nil?
            raise RetinaRuntimeException.new('returnFueraDeFuncion', self, {})
        end
        funcion = funcionAlcance.alcanceObject

        # Guarda el valor de retorno
        funcion.valor = @expresion.getValor()
    end
end


# Arbol de las reglas PROGRAM
class ArbolProgram < RetinaASTNode

    def initialize(instrucciones)
        @tipoNodo = "PROGRAM"
        @localScope = true

        @instrucciones = instrucciones
    end

    def printAST(identacion)
        indentacionNext = identacion + INDENT_DEFAULT

        str = indent("instrucciones:", identacion)
        if @instrucciones
            str += @instrucciones.printAST(indentacionNext)
        else
            str += indent("None", indentacionNext)
        end

        str
    end
end


# Arbol de las reglas BLOQUE
class ArbolBloque < RetinaASTNode

    def initialize(declaraciones, instrucciones)
        @tipoNodo = "BLOQUE"
        @localScope = true

        @declaraciones = declaraciones
        @instrucciones = instrucciones
    end


    def evaluate(parentSymTable)

        if @declaraciones
            @declaraciones.unEvaluatePrevious(@symTable)
            @declaraciones.evaluate(@symTable)
        end

        if @instrucciones
            @instrucciones.evaluate(@symTable)
        end
    end
end


# Arbol de las reglas DECLARACIONES
class ArbolBloqueDeclaraciones < RetinaASTNode

    def initialize(declaracion, declaracionList = nil)
        @declaracion = declaracion
        @declaracionList = declaracionList
    end


    def printAST(identacion)
        str = @declaracion.printAST(identacion)

        if @declaracionList
            str += @declaracionList.printAST(identacion)
        end

        str
    end

    # Deshace la evaluacion de las variables definidas
    # en el bloque para permitir reevaluar todo nuevamente
    # Util para bloques dentro de funciones o ciclos
    def unEvaluatePrevious(parentSymTable)

        @declaracion.unEvaluatePrevious(parentSymTable)

        if @declaracionList
            @declaracionList.unEvaluatePrevious(parentSymTable)
        end
    end

end


# Arbol de las reglas DECLARACION
class ArbolDeclaracion < RetinaASTNode
    attr_reader :identificador

    def initialize(tipo, identificadores, expresionInicializacion = nil)
        @tipoNodo = "DECLARACION"
        @tipo = tipo

        if identificadores.class.name == "TkIdentificador"
            @identificador = ArbolIdentificador.new(identificadores)
        else
            @identificadores = identificadores
        end

        @inicializacion = expresionInicializacion
    end


    def check(parentSymTable)

        if @identificador
            # Caso un solo identificador

            # Verifica primero la inicializacion
            @inicializacion.check(parentSymTable)

            # Agrega la variable
            @identificador.tipoExpresion = @tipo.valor
            parentSymTable.agregarVariable(@identificador)

            # Verifica que ambos lados tengan el mismo tipo
            if @identificador.getTipo() != @inicializacion.getTipo()
                raiseErrorExpresionTipoInvalido(@identificador, @inicializacion, @inicializacion)
            end

        else
            # Caso varios identificadores en una misma linea
            @identificadores.tipo = @tipo
            @identificadores.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        if @identificador
            # Caso un solo identificador

            # Evalua la inicializacion
            @inicializacion.evaluate(parentSymTable)

            # Inicializa la variable con el valor conseguido
            # y actualiza en la tabla de simbolos
            @identificador.valor = @inicializacion.getValor()
            parentSymTable.actualizarVariable(@identificador)

        else
            # Caso varios identificadores en una misma linea
            @identificadores.evaluate(parentSymTable)
        end
    end


    # Deshace la evaluacion de las variables definidas
    # en el bloque para permitir reevaluar todo nuevamente
    # Util para bloques dentro de funciones o ciclos
    def unEvaluatePrevious(parentSymTable)

        if @identificador
            # Caso un solo identificador

            if !@identificador.valor.nil?
                @identificador.valor = nil
                parentSymTable.actualizarVariable(@identificador)
            end

        else
            # Caso varios identificadores en una misma linea
            @identificadores.unEvaluatePrevious(parentSymTable)
        end

    end

end


# Arbol de las reglas DECLARACION_IDENTIFICADORES
class ArbolDeclaracionIdentificadores < RetinaASTNode
    attr_accessor :tipo

    def initialize(identificador, listaIdentificadores = nil)
        @tipo = nil
        @identificador = ArbolIdentificador.new(identificador)
        @listaIdentificadores = listaIdentificadores
    end


    def check(parentSymTable)

        # Agrega la variable del bloque
        @identificador.tipoExpresion = @tipo.valor
        parentSymTable.agregarVariable(@identificador)

        if @listaIdentificadores
            @listaIdentificadores.tipo = @tipo
            @listaIdentificadores.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # Inicializa la variable en su valor default y actualiza en la tabla de simbolos
        @identificador.valor = @identificador.getTipo() == BOOLEAN ? BOOLEAN_DEFAULT_VAL : NUMBER_DEFAULT_VAL
        parentSymTable.actualizarVariable(@identificador)

        if @listaIdentificadores
            @listaIdentificadores.evaluate(parentSymTable)
        end
    end


    # Deshace la evaluacion de las variables definidas
    # en el bloque para permitir reevaluar todo nuevamente
    # Util para bloques dentro de funciones o ciclos
    def unEvaluatePrevious(parentSymTable)

        if !@identificador.valor.nil?
            @identificador.valor = nil
            parentSymTable.actualizarVariable(@identificador)
        end

        if @listaIdentificadores
            @listaIdentificadores.unEvaluatePrevious(parentSymTable)
        end
    end


    def printAST(identacion)
        str = @identificador.printAST(identacion)

        if @listaIdentificadores
            str += @listaIdentificadores.printAST(identacion)
        end

        str
    end

end



# Arbol de las reglas INSTRUCCIONES
class ArbolInstrucciones < RetinaASTNode

    def initialize(instruccion, instruccionList = nil)
        @instruccion = instruccion
        @instruccionList = instruccionList
    end


    def check(parentSymTable)

        if @instruccion

            if @instruccion.class.name == 'ArbolFuncionLlamada'
                # Caso especial llamada a funcion
                @instruccion.check(parentSymTable, self)
            else
                # Caso default: cualquier otra instruccion
                @instruccion.check(parentSymTable)
            end
        end

        if @instruccionList
            @instruccionList.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # En el caso que se haya conseguido una instruccion return
        # se ignora al resto de instrucciones
        if $llamadaFuncionDetenerInstruccionesPorReturn
            return
        end


        if @instruccion

            if @instruccion.class.name == 'ArbolFuncionReturn'
                # Caso especial retorno de funcion
                @instruccion.evaluate(parentSymTable)

                # Evita que el resto de funciones sea llamado
                $llamadaFuncionDetenerInstruccionesPorReturn = true

                return

            else
                # Caso default: cualquier otra instruccion
                @instruccion.evaluate(parentSymTable)
            end
        end

        if @instruccionList
            @instruccionList.evaluate(parentSymTable)
        end
    end


    def printAST(identacion)

        str = ''
        if @instruccion
            str += @instruccion.printAST(identacion)
        end

        if @instruccionList
            str += @instruccionList.printAST(identacion)
        end

        str
    end

end




# Arbol de las reglas ASIGNACION
class ArbolAsignacion < RetinaASTNode

    def initialize(identificador, expresion)
        @tipoNodo = "ASIGNACION"

        @ladoIzquierdo = ArbolIdentificador.new(identificador)
        @ladoDerecho = expresion
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable)

        # Verifica la variable este declarada y la expresion sea valida
        @ladoIzquierdo.check(parentSymTable)
        @ladoDerecho.check(parentSymTable)

        # Verifica que la variable y la expresion tengan el mismo tipo
        if @ladoIzquierdo.getTipo() != @ladoDerecho.getTipo()
            raiseErrorExpresionTipoInvalido(@ladoIzquierdo, @ladoDerecho, @ladoDerecho)
        end
    end


    def evaluate(parentSymTable)

        # Evalua la expresion asignada
        @ladoDerecho.evaluate(parentSymTable)

        # Asigna el valor a la variable
        @ladoIzquierdo.valor = @ladoDerecho.getValor()
        parentSymTable.actualizarVariable(@ladoIzquierdo)
    end

end


# Arbol de las reglas ENTRADA
class ArbolEntrada < RetinaASTNode

    def initialize(identificador)
        @tipoNodo = "ENTRADA"
        @identificador = ArbolIdentificador.new(identificador)
    end


    def evaluate(parentSymTable)

        # Obtiene el valor por entrada estandar y verifica si es una expresion valida
        # segun el tipo de la variable que recibira el valor
        STDOUT.flush
        valor = STDIN.gets().chomp

        if @identificador.getTipo() == BOOLEAN

            if valor =~ /\A(true|false)\z/
                valor = $& == 'true' ? true : false
            else
                raise RetinaRuntimeException.new('expresionReadTipoInvalido', @identificador,
                    {expresion: valor, tipoEsperado: BOOLEAN})
            end
        end

        if @identificador.getTipo() == NUMBER

            if valor =~ /\A(\-[1-9]\d*|\d+|\-0)(?:\.\d+)?\z/
                # Remueve 0's a la izquierda. Si se queda vacio el string, se trata del 0
                valor = $&.gsub(/^[0]+/, '')
                valor = valor.empty? ? '0' : valor
                valor = valor.include?(".") ? Float(valor) : Integer(valor)
            else
                raise RetinaRuntimeException.new('expresionReadTipoInvalido', @identificador,
                    {expresion: valor, tipoEsperado: NUMBER})
            end
        end

        # Actualiza el valor de la variable
        @identificador.valor = valor
        parentSymTable.actualizarVariable(@identificador)
    end
end


# Arbol de las reglas SALIDA
class ArbolSalida < RetinaASTNode

    def initialize(expresiones, salto = nil)
        @tipoNodo = 'SALIDA'
        if salto
            @tipoNodo = 'SALIDA CON SALTO'
        end
        @expresiones = expresiones
    end


    def check(parentSymTable)

        if @expresiones.class.name == 'ArbolFuncionLlamada'
            # Caso especial llamada a funcion
            @expresiones.check(parentSymTable, self)
        else
            # Caso default: cualquier otra instruccion
            @expresiones.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # Evalua las expresiones
        @expresiones.evaluate(parentSymTable)

        if @tipoNodo == 'SALIDA CON SALTO'
            puts
        end
    end
end



# Arbol de las reglas SALIDA_EXPR
class ArbolSalidaExpresiones < RetinaASTNode

    def initialize(expresion, expresiones = nil)
        @expresion = expresion
        @expresiones = expresiones
    end


    def check(parentSymTable)

        if @expresion.class.name == 'ArbolFuncionLlamada'
            # Caso especial llamada a funcion
            @expresion.check(parentSymTable, self)
        else
            # Caso default: cualquier otra instruccion
            @expresion.check(parentSymTable)
        end

        # Chequea el resto de expresiones
        if @expresiones
            @expresiones.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # Evalua la expresion
        # y muestra por salida estandar el valor obtenido
        @expresion.evaluate(parentSymTable)
        valor = @expresion.getValor()

        if @expresion.class.name == 'ArbolLiteralDeCadenaDeCaracteres'
            valor = @expresion.getValor().to_s
                        .gsub(/\A\"(.*)\"\z/, '\1') # Reemplaza comillas dobles del principio y fin
                        .gsub(/\\"/, '"')           # Reemplaza especiales: comillas dobles, backslashes y salto de linea
                        .gsub(/\\\\/, "\\")
                        .gsub(/\\n/, "\n")
        end

        print valor

        # Evalua el resto de expresiones
        if @expresiones
            @expresiones.evaluate(parentSymTable)
        end
    end


    def printAST(identacion)

        str = @expresion.printAST(identacion)

        if @expresiones
            str += @expresiones.printAST(identacion)
        end

        str
    end

end


# Arbol de las reglas CONDICIONALES
class ArbolIf < RetinaASTNode

    def initialize(expresion, instruccionesThen, instruccionesElse = nil)
        @tipoNodo = "CONDICIONAL"
        @expresion = expresion
        @instruccionesThen = instruccionesThen
        @instruccionesElse = instruccionesElse
    end


    def check(parentSymTable)

        # Verifica la expresion sea valida y sea de tipo booleano
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != BOOLEAN
            raiseErrorExpresionTipoInvalido(BOOLEAN, @expresion, @expresion)
        end

        # Verifica las instrucciones
        if @instruccionesThen
            @instruccionesThen.check(parentSymTable)
        end
        if @instruccionesElse
            @instruccionesElse.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # Evalua la expresion
        @expresion.evaluate(parentSymTable)

        # Ejecuta las instrucciones segun el valor de la expresion
        if @expresion.getValor()

            if @instruccionesThen
                @instruccionesThen.evaluate(parentSymTable)
            end

        elsif @instruccionesElse
            @instruccionesElse.evaluate(parentSymTable)
        end
    end
end



# Arbol de las reglas ITERACION_WHILE
class ArbolWhile < RetinaASTNode

    def initialize(expresion, instrucciones)
        @tipoNodo = "ITERACION WHILE"
        @expresion = expresion
        @instrucciones = instrucciones
    end


    def check(parentSymTable)

        # Verifica la expresion sea valida y sea de tipo booleano
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != BOOLEAN
            raiseErrorExpresionTipoInvalido(BOOLEAN, @expresion, @expresion)
        end

        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # Evalua la expresion
        @expresion.evaluate(parentSymTable)

        # Ejecuta las instrucciones hasta que no se cumpla la condicion
        while @expresion.getValor()

            if @instrucciones
                @instrucciones.evaluate(parentSymTable)
            end

            # Evalua la expresion para la siguiente iteracion
            @expresion.evaluate(parentSymTable)
        end
    end

end


# Arbol de las reglas ITERACION_FOR
class ArbolFor < RetinaASTNode

    def initialize(identificador, from, to, by, instrucciones)
        @tipoNodo = "ITERACION FOR"
        @localScope = true

        @identificador = ArbolIdentificador.new(identificador)
        @expresionFrom = from
        @expresionTo = to
        @expresionBy = by
        @instrucciones = instrucciones
    end


    def check(parentSymTable)

        # Nuevo scope, nueva tabla de simbolos
        @symTable = RetinaSymTable.new(self, parentSymTable)

        # Agrega la funcion como subalcance del padre
        parentSymTable.agregarSubAlcance(@symTable)


        # Agrega la variable de inicializacion del for
        @identificador.tipoExpresion = NUMBER
        @symTable.agregarVariable(@identificador)


        # Verifica la expresion 'from' sea valida y de tipo number
        @expresionFrom.check(parentSymTable)
        if @expresionFrom.getTipo() != NUMBER
            raiseErrorExpresionTipoInvalido(NUMBER, @expresionFrom, @expresionFrom)
        end

        # Verifica la expresion 'to' sea valida y de tipo number
        @expresionTo.check(parentSymTable)
        if @expresionTo.getTipo() != NUMBER
            raiseErrorExpresionTipoInvalido(NUMBER, @expresionTo, @expresionTo)
        end

        # Verifica la expresion 'by' sea valida y de tipo number
        if @expresionBy
            @expresionBy.check(parentSymTable)
            if @expresionBy.getTipo() != NUMBER
                raiseErrorExpresionTipoInvalido(NUMBER, @expresionBy, @expresionBy)
            end
        end


        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(@symTable)
        end
    end


    def evaluate(parentSymTable)

        # Evalua e inicializa los valores de las cotas e incremento para el identificador
        from, to, incrementoBy = self.evaluateForValoresPartes(parentSymTable)
        fromOriginal, toOriginal, incrementoByOriginal = [from, to, incrementoBy]


        # Verifica que no haya rango vacio
        if from > to
            return
        end


        # Inicializa el contador del for
        @identificador.valor = from
        @symTable.actualizarVariable(@identificador)

        # Ejecuta las instrucciones
        while @identificador.getValor() <= to

            # Respalda el valor del identificador antes de ejecutar las instrucciones
            identificadorBefore = @identificador.getValor()

            if @instrucciones
                @instrucciones.evaluate(@symTable)
            end


            # Verifica la inmutabilidad del for antes de la siguiente iteracion
            self.evaluateForVerificarInmutabilidad(parentSymTable, identificadorBefore,
                fromOriginal, toOriginal, incrementoByOriginal)

            # Incrementa el valor del contador
            @identificador.valor += incrementoBy
            @symTable.actualizarVariable(@identificador)
        end

    end


    # Evalua e inicializa los valores de las cotas e incremento para el identificador
    def evaluateForValoresPartes(parentSymTable)

        # Evalua las expresiones que conforman el for
        @expresionFrom.evaluate(parentSymTable)
        @expresionTo.evaluate(parentSymTable)
        if @expresionBy
            @expresionBy.evaluate(parentSymTable)
        end

        # Establece los valores segun ciertas condiciones
        from = @expresionFrom.getValor()
        to = @expresionTo.getValor()
        if @expresionBy
            incrementoBy = @expresionBy.getValor()
        else
            # En el caso que no se especifique el 'by',
            # se debe aplicar la funcion piso a las cotas
            incrementoBy = 1
            from = from.floor
            to = to.floor
        end

        [from, to, incrementoBy]
    end


    # Verifica la inmutabilidad del for, comparando los valores originales con los actuales
    def evaluateForVerificarInmutabilidad(parentSymTable, identificadorBefore, fromOriginal, toOriginal, incrementoByOriginal)

        # Obtiene los valores actuales de las partes del for para verificar si cambiaron
        identificadorCurrent, alcanceIdentificador = @symTable.lookup(@identificador)
        if identificadorCurrent.nil?
            raise RetinaRuntimeException.new('variableNoDefinida', self, {nombreVariable: @identificador.getNombre})
        end
        identificadorCurrent = identificadorCurrent.getValor()

        fromCurrent, toCurrent, incrementoByCurrent = self.evaluateForValoresPartes(parentSymTable)


        if identificadorCurrent != identificadorBefore
            raise RetinaRuntimeException.new('forMutableIdentificador', @identificador, {})
        end

        if fromCurrent != fromOriginal
            raise RetinaRuntimeException.new('forMutableExpresion', @expresionFrom, {forPart: 'from'})
        end

        if toCurrent != toOriginal
            raise RetinaRuntimeException.new('forMutableExpresion', @expresionTo, {forPart: 'to'})
        end

        if @expresionBy && incrementoByCurrent != incrementoByOriginal
            raise RetinaRuntimeException.new('forMutableExpresion', @expresionBy, {forPart: 'by'})
        end
    end

end



# Arbol de las reglas ITERACION_REPEAT
class ArbolRepeat < RetinaASTNode

    def initialize(expresion, instrucciones)
        @tipoNodo = "REPEAT"
        @expresion = expresion
        @instrucciones = instrucciones
    end


    def check(parentSymTable)

        # Verifica la expresion sea valida y sea de tipo numerico
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != NUMBER
            raiseErrorExpresionTipoInvalido(NUMBER, @expresion, @expresion)
        end

        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(parentSymTable)
        end
    end


    def evaluate(parentSymTable)

        # Evalua la expresion
        @expresion.evaluate(parentSymTable)

        # Evalua las instrucciones tantas veces como indique la expresion
        repeticion = 1
        while repeticion <= @expresion.getValor().floor

            if @instrucciones
                @instrucciones.evaluate(parentSymTable)
            end

            repeticion += 1
        end

    end
end



# Arbol de las reglas FUNCION
class ArbolFuncionLlamada < RetinaASTNode
    attr_accessor :parentesis

    def initialize(identificador, argumentos = nil)
        @tipoNodo = "LLAMADA FUNCION"
        @parentesis = false
        @tipoLlamadaFuncion = nil

        @identificador = ArbolIdentificador.new(identificador)
        @argumentos = argumentos
    end


    def check(parentSymTable, parentCheck = nil)

        # Chequea que exista la funcion
        funcionAlcance = parentSymTable.lookupFuncion(@identificador)
        if funcionAlcance.nil?
            raise RetinaContextException.new('funcionNoDefinida', @identificador, {nombreFuncion: @identificador.getNombre})
        end
        funcion = funcionAlcance.alcanceObject

        # Verifica que el numero de argumentos concuerde con el numero
        # de parametros de la funcion llamada
        numArgumentos = self.getNumeroArgumentos()
        numParametros = funcion.getNumeroParametros()
        if numArgumentos != numParametros
            raise RetinaContextException.new('llamadaFuncionNumArgsInvalido', @identificador,
                    {nombreFuncion: @identificador.getNombre, numParametros: numParametros, numArgumentos: numArgumentos})
        end

        # Verifica los argumentos
        if @argumentos
            @argumentos.check(parentSymTable, funcion.getNombre, funcion.parametros, 1)
        end

        # Si la funcion retorna un tipo, la llamada es una expresion de dicho tipo
        if funcion.tipoRetorno
            @tipoLlamadaFuncion = funcion.tipoRetorno.valor
        end

        # Si la llamada es una instruccion, se comportaria como expresion libre
        # si devuelve un tipo, por lo que debe mostrarse error
        if parentCheck.class.name == 'ArbolInstrucciones' && @tipoLlamadaFuncion
            raise RetinaContextException.new('llamadaFuncionExpresionLibre', @identificador,
                    {nombreFuncion: @identificador.getNombre, tipoRetorno: @tipoLlamadaFuncion})
        end

        # Si la llamada se hace en un write o writeln y la funcion no devuelve
        # expresion alguna, debe mostrarse error
        if ['ArbolSalida', 'ArbolSalidaExpresiones'].include?(parentCheck.class.name) && @tipoLlamadaFuncion.nil?
            raise RetinaContextException.new('llamadaFuncionTipoNulo', @identificador,
                {nombreFuncion: @identificador.getNombre, tipoEsperado: "#{NUMBER}' o '#{BOOLEAN}"})
        end
    end


    def evaluate(parentSymTable)

        # Chequea que exista la funcion
        funcionAlcance = parentSymTable.lookupFuncion(@identificador)
        if funcionAlcance.nil?
            raise RetinaRuntimeException.new('funcionNoDefinida', @identificador, {nombreFuncion: @identificador.getNombre})
        end
        funcion = funcionAlcance.alcanceObject


        # Evalua los argumentos y copia sus valores a los parametros de la funcion
        # Respalda los valores actuales de los parametros por si es una funcion recursiva
        if @argumentos
            @argumentos.evaluate(parentSymTable, funcionAlcance, funcion.parametros)
        end


        # Evalua la funcion con los valores indicados
        begin
            funcion.evaluate(funcionAlcance.parent, self)

        rescue Exception => e

            # Error recursion infinita
            # En este escenario no hay mas memoria, por lo que no se puede usar el raise
            if e.message == 'stack level too deep'
                linea, columna = self.getLineaColumna
                puts "\nError: se detectó recursión infinita [lin: #{linea}, col: #{columna}]"
            end

            # Error de ejecucion
            if e.class.name == 'RetinaRuntimeException'
                puts e
            end


            # Exit lanza un error 'SystemExit', por lo que exit se llamara
            # tantos rescue's como stack levels existan
            exit
        end


        # Obtiene el valor retornado por la funcion (si aplica)
        @valor = nil
        if funcion.tipoRetorno
            @valor = funcion.getValor()
        end


        # Restaura los valores originales de los parametros antes de la llamada
        if @argumentos
            @argumentos.evaluateRestore(parentSymTable, funcionAlcance, funcion.parametros)
        end


        # Finalizada la evaluacion, apaga todos los flags
        funcion.valor = nil
        $llamadaFuncionDetenerInstruccionesPorReturn = false
    end


    # Obtiene el valor retornado por la funcion
    # o nil en caso que la funcion no tenga tipo de retorno
    def getValor
        @valor
    end


    # Obtiene el nombre de la funcion llamada
    def getNombre
        @identificador.getNombre
    end


    # Obtiene el tipo de expresion que representa la llamada
    def getTipo
        @tipoLlamadaFuncion
    end


    # Obtiene la linea y columna del comienzo de la llamada
    def getLineaColumna
        @identificador.getLineaColumna
    end


    # Obtiene el numero de argumentos de la llamada a la funcion
    def getNumeroArgumentos

        numArgs = 0
        if @argumentos

            argumento = @argumentos
            while argumento
                argumento = argumento.funcionArgs
                numArgs = numArgs + 1
            end
        end

        numArgs
    end


    # Obtiene la representacion en codigo
    def toCode
        str = "#{self.getNombre}("
        if @argumentos
            str += @argumentos.toCode
        end
        str += ')'
    end

end


# Arbol de las reglas FUNCION_LLAMADA_ARGS
class ArbolFuncionLlamadaArgs < RetinaASTNode
    attr_reader :funcionArgs

    def initialize(expresion, funcionArgs = nil)
        @expresion = expresion
        @pilaValor = []
        @funcionArgs = funcionArgs
    end


    def check(parentSymTable, funcionNombre, funcionParametro, numArg)

        # Verifica la expresion del argumento sea valido y sea del tipo esperado
        # de acuerdo al orden de los parametros de la funcion
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != funcionParametro.getTipo()
            raise RetinaContextException.new('llamadaFuncionTipoParametroInvalido', @expresion,
                {numeroArg: numArg, nombreFuncion: funcionNombre, tipoEncontrado: @expresion.getTipo(),
                    tipoEsperado: funcionParametro.getTipo()})
        end

        # Verifica el resto de argumentos
        if @funcionArgs && funcionParametro
            @funcionArgs.check(parentSymTable, funcionNombre, funcionParametro.funcionParams, numArg + 1)
        end
    end


    def evaluate(parentSymTable, funcionAlcance, funcionParametro)

        # Respalda el valor actual del parametro
        @pilaValor.push(funcionParametro.getValor())

        # Evalua la expresion del argumento e inicializa el valor
        # del parametro correspondiente en la funcion
        @expresion.evaluate(parentSymTable)
        # puts "evaluateValor backup #{funcionParametro.getValor()}, param value: #{@expresion.getValor()}"
        funcionParametro.setValor(funcionAlcance, @expresion.getValor())


        # Evalua el resto de argumentos
        if @funcionArgs && funcionParametro
            @funcionArgs.evaluate(parentSymTable, funcionAlcance, funcionParametro.funcionParams)
        end
    end


    def evaluateRestore(parentSymTable, funcionAlcance, funcionParametro)

        # Restaura el valor original del parametro antes de la llamada
        # puts "evaluateValor restore #{@pilaValor.last}, replace param value: #{funcionParametro.getValor}"
        funcionParametro.setValor(funcionAlcance, @pilaValor.pop())


        # Evalua el resto de argumentos
        if @funcionArgs && funcionParametro
            @funcionArgs.evaluateRestore(parentSymTable, funcionAlcance, funcionParametro.funcionParams)
        end
    end


    # Obtiene la representacion en codigo
    def toCode
        str = "#{@expresion.toCode}"
        if @funcionArgs
            str += ", #{@funcionArgs.toCode}"
        end
        str
    end


    def printAST(identacion)

        if @expresion.nil?
            return ''
        end

        str = indent("ARGUMENTO:", identacion)
        str += @expresion.printAST(identacion + INDENT_DEFAULT)

        if @funcionArgs
            str += @funcionArgs.printAST(identacion)
        end

        str
    end

end


# Arbol de las reglas TIPO
class ArbolTipo < RetinaASTNode
    attr_reader :valor

    def initialize(token)
        @noCheck = true
        @noEvaluate = true

        @valor = token.valor
    end

    # Obtiene el valor del tipo (number o boolean)
    def getValor
        @valor
    end


    def printAST(identacion)
        str = indent("TIPO:", identacion)
        str += indent("nombre: "+ @valor, identacion + INDENT_DEFAULT)
    end

end


# Arbol de las reglas EXPR con operadores unarios
class ArbolOperadorUnario < RetinaASTNode
    attr_reader :expresion, :tipoOperandoEsperado
    attr_accessor :parentesis

    def initialize(operador, expresion)
        @operador = operador
        @expresion = expresion

        @tipoOperandoEsperado = nil
        @tipoExpresion = nil
        @parentesis = false

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @tipoNodo = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    def check(parentSymTable)

        # Chequea que la expresion sea valida
        @expresion.check(parentSymTable)

        # Determina que la expresion sea del tipo esperado
        if @expresion.getTipo() != @tipoOperandoEsperado
            raiseErrorExpresionTipoInvalido(@tipoOperandoEsperado, @expresion, @expresion)
        end
    end


    def evaluate(parentSymTable)

        # Evalua la expresion
        @expresion.evaluate(parentSymTable)

        # Deja a los hijos la operacion y obtencion del valor
    end


    # Obtiene el valor de la expresion
    def getValor
        @valor
    end


    # Obtiene el tipo de la expresion
    def getTipo
        @tipoExpresion
    end


    # Obtiene la linea y columna del comienzo de la expresion
    def getLineaColumna
        [@operador.linea, @operador.columna]
    end


    # Representacion en codigo de la expresion
    def toCode
        str = "#{@operador.valor} #{@expresion.toCode()}"
        if @parentesis
            str = "(#{str})"
        end
        str
    end

end


# Arboles de expresiones con operadores unarios
class ArbolNot < ArbolOperadorUnario

    def initialize(operador, expresion)
        super
        @tipoOperandoEsperado = BOOLEAN
        @tipoExpresion = BOOLEAN
    end


    def evaluate(parentSymTable)
        super
        @valor = !@expresion.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolMenosUnario < ArbolOperadorUnario

    def initialize(operador, expresion)
        super
        @tipoOperandoEsperado = NUMBER
        @tipoExpresion = NUMBER
    end


    def evaluate(parentSymTable)
        super
        @valor = -1 * @expresion.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end



# Arbol de las reglas EXPR con operadores binarios
class ArbolOperadorBinario < RetinaASTNode
    attr_reader :expresion, :tipoOperandoEsperado
    attr_accessor :parentesis

    def initialize(expresionIzquierda, operador, expresionDerecha)
        @operador = operador
        @ladoIzquierdo = expresionIzquierda
        @ladoDerecho = expresionDerecha

        @tipoOperandoEsperado = nil
        @tipoExpresion = nil
        @parentesis = false

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @tipoNodo = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    def check(parentSymTable)

        # Chequea que las dos expresiones sean validas
        @ladoIzquierdo.check(parentSymTable)
        @ladoDerecho.check(parentSymTable)

        # Chequeo de tipos
        if ['ArbolIgual', 'ArbolDesigual'].include?(self.class.name)
            # Operadores igual y desigual pueden ser BOOLEAN y NUMBER

            # Determina que las expresiones sean del mismo tipo
            if @ladoIzquierdo.getTipo() != @ladoDerecho.getTipo()
                raiseErrorExpresionTipoInvalido(@ladoIzquierdo, @ladoDerecho, @ladoDerecho)
            end

        else

            # Determina que las expresiones sean del tipo esperado
            if @ladoIzquierdo.getTipo() != @tipoOperandoEsperado
                raiseErrorExpresionTipoInvalido(@tipoOperandoEsperado, @ladoIzquierdo, @ladoIzquierdo)
            end

            if @ladoDerecho.getTipo() != @tipoOperandoEsperado
                raiseErrorExpresionTipoInvalido(@tipoOperandoEsperado, @ladoDerecho, @ladoDerecho)
            end
        end

    end


    def evaluate(parentSymTable)

        # Evalua las dos expresiones
        # Si alguna es una llamada a funcion, la evalua primero porque los valores
        # de variables cambiaran si es una llamada recursiva
        if @ladoIzquierdo.class.name == 'ArbolFuncionLlamada'
            @ladoIzquierdo.evaluate(parentSymTable)
            @ladoDerecho.evaluate(parentSymTable)
        else
            @ladoDerecho.evaluate(parentSymTable)
            @ladoIzquierdo.evaluate(parentSymTable)
        end

        # Deja a los hijos la operacion y obtencion del valor
    end


    # Obtiene el valor de la expresion
    def getValor
        @valor
    end


    # Obtiene el tipo de la expresion
    def getTipo
        @tipoExpresion
    end


    # Obtiene la linea y columna del comienzo de la expresion
    def getLineaColumna
        @ladoIzquierdo.getLineaColumna()
    end


    # Representacion en codigo de la expresion
    def toCode
        str = "#{@ladoIzquierdo.toCode()} #{@operador.valor} #{@ladoDerecho.toCode()}"
        if @parentesis
            str = "(#{str})"
        end
        str
    end

end

# Arboles de expresiones con operadores binarios
class ArbolOperadorBinarioComparacion < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoOperandoEsperado = NUMBER
        @tipoExpresion = BOOLEAN
    end
end

class ArbolOperadorBinarioLogico < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoOperandoEsperado = BOOLEAN
        @tipoExpresion = BOOLEAN
    end
end

class ArbolOperadorBinarioAritmetico < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoOperandoEsperado = NUMBER
        @tipoExpresion = NUMBER
    end
end


class ArbolIgual < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoExpresion = BOOLEAN
    end


    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() == @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolDesigual < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoExpresion = BOOLEAN
    end


    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() != @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolMayorOIgualQue < ArbolOperadorBinarioComparacion

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() >= @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolMenorOIgualQue < ArbolOperadorBinarioComparacion

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() <= @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolMayorQue < ArbolOperadorBinarioComparacion

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() > @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolMenorQue < ArbolOperadorBinarioComparacion

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() < @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolAnd < ArbolOperadorBinarioLogico

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() && @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolOr < ArbolOperadorBinarioLogico

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() || @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolProducto < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() * @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolDivisionExacta < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super

        if @ladoDerecho.getValor() == 0
            raise RetinaRuntimeException.new('divisionPor0', @ladoDerecho, {})
        end

        @valor = @ladoIzquierdo.getValor().fdiv(@ladoDerecho.getValor())
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolRestoExacto < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super

        if @ladoDerecho.getValor() == 0
            raise RetinaRuntimeException.new('divisionPor0', @ladoDerecho, {})
        end

        @valor = @ladoIzquierdo.getValor() % @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolDivisionEntera < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super

        if @ladoDerecho.getValor() == 0
            raise RetinaRuntimeException.new('divisionPor0', @ladoDerecho, {})
        end

        @valor = @ladoIzquierdo.getValor().div(@ladoDerecho.getValor())
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolRestoEntero < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super

        if @ladoDerecho.getValor() == 0
            raise RetinaRuntimeException.new('divisionPor0', @ladoDerecho, {})
        end

        @valor = @ladoIzquierdo.getValor().modulo(@ladoDerecho.getValor())
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolSuma < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() + @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end


class ArbolResta < ArbolOperadorBinarioAritmetico

    def evaluate(parentSymTable)
        super
        @valor = @ladoIzquierdo.getValor() - @ladoDerecho.getValor()
        checkValorByType(@valor, @tipoExpresion, self)
    end
end



# Arbol de las reglas EXPR (sin operador)
class ArbolExpresion < RetinaASTNode
    attr_reader :expresion
    attr_accessor :tipoExpresion, :parentesis

    def initialize(expresion)
        @expresion = expresion

        @tipoExpresion = nil
        @parentesis = false
        @label = 'valor'
        @noCheck = true
        @noEvaluate = true

        # Obtiene el nombre de la expresion a partir del nombre de la clase, separa en espacios
        @nombreExpresion = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    # Obtiene el valor de la expresion
    def getValor
        @expresion.valor
    end


    # Obtiene el tipo de la expresion
    def getTipo
        @tipoExpresion
    end


    # Obtiene la linea y columna del comienzo de la expresion
    def getLineaColumna
        [@expresion.linea, @expresion.columna]
    end


    # Representacion en codigo de la expresion
    def toCode
        str = "#{@expresion.valor}"
        if @parentesis
            str = "(#{str})"
        end
        str
    end


    # Representacion en string del nodo
    def printAST(identacion)
        str = indent(@nombreExpresion + ":", identacion)
        str += indent(@label +": "+ @expresion.valor, identacion + INDENT_DEFAULT)
    end

end


# Arboles de expresiones sin operadores
class ArbolExpresionBooleana < ArbolExpresion

    def initialize(expresion)
        super
        @tipoExpresion = BOOLEAN
    end
end

class ArbolLiteralNumerico < ArbolExpresion

    def initialize(expresion)
        super
        @tipoExpresion = NUMBER
    end
end

class ArbolLiteralDeCadenaDeCaracteres < ArbolExpresion; end


# Arbol de identificadores
class ArbolIdentificador < ArbolExpresion

    def initialize(expresion)
        super
        @label = 'nombre'
        @noEvaluate = false
    end


    # Obtiene el nombre de la expresion
    def getNombre
        @expresion.valor
    end


    # Obtiene el valor almacenado en la tabla de simbolos
    def getValor
        @valor
    end


    def check(parentSymTable)

        # Determina si la variable esta declarada
        identificador, alcanceIdentificador = parentSymTable.lookup(self, true)
        if identificador.nil?
            raise RetinaContextException.new('variableNoDefinida', self, {nombreVariable: self.getNombre})
        end

        @tipoExpresion = identificador.tipoExpresion
    end


    def evaluate(parentSymTable)

        # Determina si la variable esta declarada y tiene valor
        identificador, alcanceIdentificador = parentSymTable.lookup(self, true, true)
        if identificador.nil?
            raise RetinaRuntimeException.new('variableNoDefinida', self, {nombreVariable: self.getNombre})
        end

        @valor = identificador.valor
        checkValorByType(@valor, @tipoExpresion, self)
    end

end
