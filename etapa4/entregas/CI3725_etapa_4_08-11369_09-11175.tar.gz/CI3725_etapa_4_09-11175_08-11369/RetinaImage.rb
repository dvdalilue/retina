=begin
  Proyecto 4 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Manejo y generacion de imagen
# de acuerdo a las intrucciones de Retina
class RetinaImage

    attr_reader :posicionTortuga

    MATRIZ_BITS_CENTRO_POS = 500
    MATRIZ_BITS_LENGTH = 1001


    def initialize(rtnFilename)

        # Posicion, direccion y arreglo de bits inicial
        @posicionTortuga = [MATRIZ_BITS_CENTRO_POS, MATRIZ_BITS_CENTRO_POS]
        @coordenadasTortuga = [0, 0]
        @openeyeTortuga = true
        @anguloDireccionTortuga = 90
        @bits = Array.new(MATRIZ_BITS_LENGTH){Array.new(MATRIZ_BITS_LENGTH, 0)}

        # Inicializa el punto central
        @bits[MATRIZ_BITS_CENTRO_POS][MATRIZ_BITS_CENTRO_POS] = 1

        # Nombre del archivo .rtn
        @rtnFilename = rtnFilename
    end


    # Operaciones Retina

    def home
        @posicionTortuga = [MATRIZ_BITS_CENTRO_POS, MATRIZ_BITS_CENTRO_POS]
    end


    def openeye
        @openeyeTortuga = true
    end


    def closeeye
        @openeyeTortuga = false
    end


    def forward(numPixeles)

        if numPixeles < 0
            return self.backward(numPixeles.abs)
        end

        # Utiliza la ecuacion parametrica de la circunferencia para calcular
        # la ubicacion del punto destino
        xCurrent, yCurrent = @posicionTortuga
        x = xCurrent + Math.cos(self.degreeToRad(@anguloDireccionTortuga)) * numPixeles
        y = yCurrent - Math.sin(self.degreeToRad(@anguloDireccionTortuga)) * numPixeles

        if @openeyeTortuga
            self.trazarLineaDesdeTortuga(x, y)
        end

        self.setposition(x, y, false)
    end


    def backward(numPixeles)

        if numPixeles < 0
            return self.forward(numPixeles.abs)
        end

        # Utiliza la ecuacion parametrica de la circunferencia para calcular
        # la ubicacion del punto destino
        xCurrent, yCurrent = @posicionTortuga
        x = xCurrent - Math.cos(self.degreeToRad(@anguloDireccionTortuga)) * numPixeles
        y = yCurrent + Math.sin(self.degreeToRad(@anguloDireccionTortuga)) * numPixeles

        if @openeyeTortuga
            self.trazarLineaDesdeTortuga(x, y)
        end

        self.setposition(x, y, false)
    end


    def rotatel(numPixeles)

        if numPixeles < 0
            return rotater(numPixeles.abs)
        end

        @anguloDireccionTortuga = (@anguloDireccionTortuga + numPixeles) % 360
    end


    def rotater(numPixeles)

        if numPixeles < 0
            return rotatel(numPixeles.abs)
        end

        @anguloDireccionTortuga = (@anguloDireccionTortuga - numPixeles) % 360
    end


    def setposition(posicionX, posicionY, adjustToGrid = true)

        if adjustToGrid
            @posicionTortuga = [MATRIZ_BITS_CENTRO_POS + posicionX, MATRIZ_BITS_CENTRO_POS - posicionY]
            @coordenadasTortuga = [posicionX, posicionY]
        else
            @posicionTortuga = [posicionX, posicionY]
            @coordenadasTortuga = [posicionX - MATRIZ_BITS_CENTRO_POS, MATRIZ_BITS_CENTRO_POS - posicionY]
        end
        # puts "tortuga: #{@posicionTortuga}, coordenadas #{@coordenadasTortuga}\n\n"
    end


    def arc(grados, radio)
        # Ya no es necesario implementar
    end


    # Convierte grados sexagesimales a radianes
    def degreeToRad(degrees)
        degrees * Math::PI / 180
    end


    # Utiliza el algoritmo de trazo de linea de Bresenham para trazar
    # una linea desde la posicion actual de la tortuga hasta el punto de coordenadas indicadas
    def trazarLineaDesdeTortuga(x, y)

        # Obtiene la posicion actual de la tortuga
        # Puede estar fuera del plano
        xCurrent, yCurrent = @posicionTortuga
        # puts "to draw (#{xCurrent}, #{yCurrent}) - (#{x}, #{y}) @ #{@anguloDireccionTortuga} degrees\n"


        # Determina cotas de parada especiales
        tipoCotaX = 'creciente'
        if x < xCurrent
            tipoCotaX = 'decreciente'
        end

        tipoCotaY = 'creciente'
        if y < yCurrent
            tipoCotaY = 'decreciente'
        end

        # puts "cotas: X: #{tipoCotaX}, Y: #{tipoCotaY}"

        # Aplica el algoritmo de Bresenham para marcar los pixeles
        dx = (x - xCurrent).abs
        sx = xCurrent < x ? 1 : -1
        dy = (y - yCurrent).abs
        sy = yCurrent < y ? 1 : -1
        err = (dx > dy ? dx : -dy)/2

        while true

            # puts "pixel #{xCurrent},#{yCurrent} - X: #{xCurrent} vs #{x} (#{xCurrent == x}), Y: #{yCurrent} vs #{y} (#{yCurrent == y})"

            # Por defecto se pinta el pixel
            draw = true

            # Condiciones de parada si sobrepasa las coordenadas destino
            if tipoCotaX == 'creciente' && xCurrent > x
                return
            elsif tipoCotaX == 'decreciente' && xCurrent < x
                return
            end

            if tipoCotaY == 'creciente' && yCurrent > y
                return
            elsif tipoCotaY == 'decreciente' && yCurrent < y
                return
            end

            # Identifica si se puede pintar el pixel
            if xCurrent >= MATRIZ_BITS_LENGTH || yCurrent >= MATRIZ_BITS_LENGTH
                draw = false
            end

            if xCurrent < 0 || yCurrent < 0 || xCurrent.nil? || yCurrent.nil?
                draw = false
            end


            # Pinta el pixel (si aplica)
            if draw
                # No hay problema si se solicita una posicion con decimales,
                # esto es: @bits[0] = @bits[0.1] = @bits[0.9999]
                @bits[yCurrent][xCurrent] = 1
            end


            # Si las dos coordenadas hacen match, no debemos dibujar mas
            if xCurrent == x && yCurrent == y
                break
            end

            # Calcula el diferencial para el siguiente pixel
            e2 = err;
            if e2 > -dx
                err -= dy
                xCurrent += sx
            end

            if e2 < dy
                err += dx
                yCurrent += sy
            end
        end
    end


    # Genera el archivo de salida final
    def generate

        begin
            # Construye el contenido del archivo final
            imgContents  = "P1\n"
            imgContents += "#Imagen generada para el programa '#{@rtnFilename}'\n"
            imgContents += "#{MATRIZ_BITS_LENGTH} #{MATRIZ_BITS_LENGTH}\n"

            for i in (0 .. @bits.length-1)

                imgContents += @bits[i].join(" ")

                if i != @bits.length-1
                    imgContents += "\n"
                end
            end

            # Genera el nombre del archivo de salida
            rtnImageFilename = File.basename(@rtnFilename, '.rtn') +".pbm"

            # Genera la imagen
            rtnImageFilename = File.new(rtnImageFilename, "w+")
            if rtnImageFilename
                rtnImageFilename.syswrite(imgContents)
            else
                raise "Error escritura"
            end

        rescue Exception => e
            raise RetinaRuntimeException.new('imagenNoGenerada', nil, {}, [nil, nil])
        end
    end

end
