=begin
  Proyecto 4 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end

En caso de que el programa no mantenga su permiso de ejecución, se le debe dar el permiso ejecutando el siguiente comando:
chmod +x retina
