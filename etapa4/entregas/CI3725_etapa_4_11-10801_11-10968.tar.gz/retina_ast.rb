#! /usr/bin/ruby
#  Etapa 1 - Analizador Lexicográfico para el lenguaje Retina
#   Alumnos: Johanny Prado 11-10801
#            Edgar Silva   11-10968
# Fecha Ultima modificacion: 12/02/2017

Ident = 2

class AST
  #def identador(cant=iden,token)
  #    token.rjust(iden +token.to_s.length,' ') + "\n" 
  #end  
  

   
  def print_ast indent=""
        puts "#{indent}#{self.class}:"

        attrs.each do |a|
            a.print_ast indent + "  " if a.respond_to? :print_ast
        end
    end

    def attrs
        instance_variables.map do |a|
            instance_variable_get a
        end
    end
end

class S < AST # Completada
   attr_accessor :s
   def initialize s
        @s = s
   end
end  


class Saux < AST 
    attr_accessor :bloqIns,
                  :funciones,
                  :symTab

    def initialize bloqIns,funciones=nil
        @bloqIns = bloqIns
        @funciones = funciones
        @symTab = nil
    end 

    def to_s
        ident=Ident
        sig_nivel = ident + Ident
        token = "\nAST:\n"

        if @bloqIns
          token = identador("Bloque:",ident) + token
          token = @bloqIns.to_s(sig_nivel)
        end
       
    end
end  

class InstBlq < AST # Completada
   attr_accessor :decla_list,
                 :inst_blq1

    def initialize decla = nil, inst_blq1
        @decla_list = decla
        @inst_blq1 = inst_blq1
    end
end

class InstBlq1 < AST # Completada
   attr_accessor :instruction_list,
                 :inst_blq

    def initialize  inst_blq = nil, instruc=nil
        @inst_blq = inst_blq
        @instruction_list = instruc
    end
end 

class ListDecl < AST # Completada
  attr_accessor :declaration_list,
                :decl

  def initialize decl,declaList = nil 
    @declaration_list= declaList
    @decl = decl
  end
end 

#class Comentarios < AST
# attr_accessor:instruction_list

#    def initialize instruc
#        @instrucciones_list = instruc
#    en
#end

class Decl < AST # Completada
 attr_accessor :tipo,
               :decl1 

    def initialize decl1, t
        @decl1 = decl1
        @tipo = t
    end
end

class Decl1 < AST # Completada
 attr_accessor :list_id,
               :asig 

    def initialize li,a=nil
        @list_id = li
        @asig = a
    end
end 


class ListId < AST # Completada
 attr_accessor :var,
               :list_id

    def initialize v,li = nil
        @var =v
        @list_id = li
    end
end 


class Asig < AST 
 attr_accessor :types,
               :id_expr

    def initialize type1, type2, var, expr
        @types = [type1, type2]
        @id_expr = [var,expr]
    end
end 


class LisTerm < AST
 attr_accessor :term,
               :list_term

    def initialize ter,lisTerm=nil
        @term = ter
        @list_term = lisTerm
    end
end 


class BinOp < AST
    attr_accessor :left, 
                  :right,
                  :op

    def initialize op,lh, rh
    	@op = op
        @left = lh
        @right = rh
    end
end 


class UnOp < AST
 attr_accessor :right

    def initialize rh
        @right = rh
    end
end 


class ParenEx < AST
 attr_accessor :expr

    def initialize e
        @expr = e
    end
end 


class ListInst < AST # Completada
 attr_accessor :inst,
               :list_inst

    def initialize i,listInst=nil
        @list_inst = listInst
        @inst =i
        
    end
end 


class Inst < AST # Completada
    attr_accessor :type,
                  :argumentos

    def initialize type,argumentos1,argumentos2=nil
        @type = type
        @argumentos=[argumentos1,argumentos2]
    end
end


class Rreturn < AST # Completada
    attr_accessor :expr
    def initialize expr
        @expr=expr
    end

end  


class InstMovi1 < AST # Completada
    attr_accessor :inst_movi2,
                  :expr

    def initialize expr=nil,inst =nil
    	@expr =expr
        @inst_movi2 = inst
    end
end


class InstMovi2 < AST # Completada
    attr_accessor :expr,
                  :inst_movi2

    def initialize expr, inst_movi2=nil
        @expr = expr
        @inst_movi2 = inst_movi2
    end
end


class Conditional < AST

    attr_accessor :list_inst,
                  :exp,
                  :cond1

    def initialize expr,listInst,cond1
        @exp =expr
        @list_inst =listInst
        @cond1 = cond1
    end
end


class Cond1 < AST

    attr_accessor :list_inst

    def initialize listInst=nil
        @list_inst =listInst
    end
end


class Loop < AST
    attr_accessor :type,
                  :var,
                  :loopInst,
                  :exp,
                  :num1,
                  :num2
    def initialize type, loopInst, v=nil,expr=nil,num1=nil,num2=nil
        @type = type
        @loopInst =loopInst
        @var=v
        @exp =expr
        @num1 = num1
        @num2 = num2
       
    end
end 
class LoopInst < AST
	 attr_accessor :type,
                   :listInst,
                   :inst_blq
                  
    def initialize type, listInst=nil,inst_blq=nil
        @type = type
        @listInst = listInst
        @inst_blq = inst_blq
      
       
    end
end
class ListArg < AST
    attr_accessor :arg,
                  :list_Arg

    def initialize a,listArg=nil
        @arg=a
        @list_Arg =listArg
    end
end 

class Arg < AST
    attr_accessor :tipo,
                  :var

    def initialize v,t=nil
        @var =v
        @tipo =t
    end
end 


class CallFunc < AST
 attr_accessor :listArg,
               :var

    def initialize v,listArg=nil
        @var =v
        @listArg =listArg
    end
end 

class ListDeclFunc < AST # Completada
  attr_accessor :function_list,
                :declFunc

  def initialize declF,function_list= nil 
      @declFunc =declF
      @function_list =function_list
  end
end 


class DeclFunc < AST # Completada
    attr_accessor :nombre,
                  :list_Arg,
                  :firma,
                  :list_inst

    def initialize name, listArg=nil,firm=nil,listInst 
        @nombre =name
        @list_Arg =listArg
        @firma = firm
        @list_inst =listInst
    end
end


class Firm < AST # Completada
    attr_accessor :type

    def initialize type = nil
        @type = type
    end
end


class Term < AST
     attr_accessor :term,
                   :nameTerm

     def initialize term,name=nil
         @term = term
         @nameTerm = name
     end
end