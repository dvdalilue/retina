require_relative 'retina_ast'
require_relative 'retina_symTable'

$symTable = nil		# Tabla de simbolos.
$tableStack = []	# Pila de tablas.

################################################
# Manejo de la estructura general del programa #
################################################

# Manejador del programa principal.
def program_Handler(ast)
	#puts "Estoy en program_Handler con ast de tipo: #{ast.class}"
	 #s_Handler(ast.s)
	 return s_Handler(ast.s)
end

# Manejador de alcances.
def s_Handler(s)
	# Asignación de una nueva tabla.
	symTableAux = SymbolTable.new($symTable)
	$symTable = symTableAux
	s.symTab = $symTable
	#Manejo de la estructura.
	funcError = 0
	if (s.funciones != nil)
		funcError = lFunc_Handler(s.funciones)
	end

	bloqInstrError = bloqInstr_Handler(s.bloqIns)
	# Se empila la tabla del scope en la pila de tablas.
	$tableStack << $symTable
	$symTable = $symTable.father
	# Si ya se analizo todo el programa, se imprimen cada una
	# de las tablas (si no hubo errores).
	if ($symTable == nil)
			if (funcError > 0) or (bloqInstrError > 0)
				puts "Symbol table will not be shown."
				abort
			end
			puts "Symbol Table:"
			$tableStack.reverse!
			$tableStack.each do |st|
				st.print_Table
			end
		
	end
	return funcError + bloqInstrError
end
##########################################
#Manejador para el bloque de instrucciones#
##########################################
#Manejador para bloque de Instrucciones
def bloqInstr_Handler(bloque)
	#Manejo de la estructura.
	declError = 0
	if (bloque.decla_list != nil)
		declError = lDecl_Handler(bloque.decla_list)
	end

	bloqError = bloqInstr2_Handler(bloque.inst_blq1)
	return declError + bloqError
end

# Auxiliar para el bloque de instrucciones
def bloqInstr2_Handler(bloque)
	#Manejo de la estructura.
	instError = 0
	if (bloque.instruction_list != nil)
		instError = linst_Handler(bloque.instruction_list)
	end

    bloqError = 0
	if (bloque.inst_blq!= nil)
		bloqError = bloqInstr_Handler(bloque.inst_blq)
	end

	return instError + bloqError
end	
#######################################
# Manejador de Lista de instrucciones #
#######################################
# Manejador de lista de instrucciones #
def linst_Handler(list_inst,type=nil)
	
#puts "Estoy en linst_Handler con list_inst de tipo: #{list_inst.class}"
    if (type!=nil)
    	instError=inst_Handler(list_inst.inst,type)
    else	
    	instError=inst_Handler(list_inst.inst)
    end
	linstError=0
	if (list_inst.list_inst !=nil)
		linstError=linst_Handler(list_inst.list_inst)
    end
	return  instError + linstError
end

#Manejador para una instruccion
def inst_Handler(instr,type=nil)
	case instr.type	
	when :Asig
			return asig_Handler(instr.argumentos[0])
	when :Read
		return read_Handler(instr)
	when :Write
		return write_Handler(instr)
	when :Writeln
		return writeln_Handler(instr)
	when :CallFunc
		return callFunc_Handler(instr.argumentos[0])
	when :Conditional
		return conditional_Handler(instr.argumentos[0])
	when :Loop
		return Loop_Handler(instr.argumentos[0])
	when :Return
		return return_Handler(instr.argumentos[0],type)
	end
end

####################################################
# Manejadores de las instrucciones del programa #
####################################################
# Manejador para asignaciones
def asig_Handler(type=nil, asig)
	idVar = asig.id_expr[0].nameTerm.idAndValue[1] 
	if ($symTable.lookup(idVar) == nil)
		if (type!= nil)
			valor =asig.id_expr[1].nameTerm.idAndValue[1]
			if !($symTable.contains(idVar))
				$symTable.insert(idVar, [type,valor])
			end	
		else	
			puts "ASSIGN ERROR: variable '#{idVar}' has not been declared."
			return 1
		end		
	end
	typeVar = $symTable.lookup(idVar)[0]
	typeExpr = expr_Handler(asig.id_expr[1])


	if (typeVar != typeExpr)
		puts "ASSIGN ERROR: #{typeExpr} expression assigned to #{typeVar} "\
			"variable '#{idVar}'."
		return 1
	end
	return 0
end

# Manejador de la instruccion read.
def read_Handler(read)
    
	idVar = read.argumentos[0].nameTerm.idAndValue[1]
	#puts "estoy en READ con idVar : #{idVar}"
	if ($symTable.lookup(idVar) == nil)
		puts "READ ERROR: variable '#{idVar}' has not been declared."
		return 1
	end
	typeVar = $symTable.lookup(idVar)[0]
	if (typeVar != :Number) and (typeVar != :Bool)
		puts "READ ERROR: variable '#{idVar}' must be an number or a boolean."
		return 1
	end
	return 0
end

# Manejador de la instruccion write.
def write_Handler(write)

	typeExpr = expr_Handler(write.argumentos[0])
	if (typeExpr !=:String)
		puts "WRITE ERROR: the expression given must be a string."
		return 1
	end
	return 0
end

def writeln_Handler(writeln)
	expr = writeln.argumentos[0]
	typeExpr = expr_Handler(expr)
	if (typeExpr != :String)
		puts "WRITE ERROR: the expression given must be a string."
		return 1
	end
	return 0
end

# Manejador de instMov1
def callFunc_Handler(callFunc)
	fuction = callFunc.var.nameTerm.idAndValue[1]
  #  puts fuction
    case fuction
		when 'home'
			if (callFunc.listArg != nil)
            	puts "ERROR: funcion ;home', no recibe parametros"  
            	return 1 
			end	
			return 0
		when 'openeye'
			if (callFunc.listArg != nil)
            	puts "ERROR: funcion 'openeye', no recibe parametros" 
            	return 1  
			end	
			return 0
		when 'closeeye'
			if (callFunc.listArg != nil)
            	puts "ERROR: funcion 'closeeye', no recibe parametros" 
            	return 1  
			end	
			return 0
		when 'forward'
			#puts "Estoy en forward"
			if (callFunc.listArg.list_Arg != nil)
				puts "Exceso de argumentos para la funcion forward."
				return 1
			else
				type = expr_Handler(callFunc.listArg.arg.var)
				if (type == :Number)
					#puts "Termine bien"
					return 0
				else
					puts "El tipo del argumento de la funcion forward debe ser Number, " \
					     "usted introdujo #{type}."
					return 1
				end
			end
		when 'backward'
			#puts "Estoy en backward"
			if (callFunc.listArg.list_Arg != nil)
				puts "Exceso de argumentos para la funcion backward."
				return 1
			else
				type = expr_Handler(callFunc.listArg.arg.var)
				if (type == :Number)
					return 0
				else
					puts "El tipo del argumento de la funcion backward debe ser Number, " \
					     "usted introdujo #{type}."
					return 1
				end
			end
		when 'rotater'
			#puts "Estoy en rotater"
			if (callFunc.listArg.list_Arg != nil)
				puts "Exceso de argumentos para la funcion rotater."
				return 1
			else
				type = expr_Handler(callFunc.listArg.arg.var)
				if (type == :Number)
					return 0
				else
					puts "El tipo del argumento de la funcion rotater debe ser Number, " \
					     "usted introdujo #{type}."
					return 1
				end
			end
		when 'rotatel'
			#puts "Estoy en rotatel"
			if (callFunc.listArg.list_Arg != nil)
				puts "Exceso de argumentos para la funcion rotatel."
				return 1
			else
				type = expr_Handler(callFunc.listArg.arg.var)
				if (type == :Number)
					return 0
				else
					puts "El tipo del argumento de la funcion rotatel debe ser Number, " \
					     "usted introdujo #{type}."
					return 1
				end
			end
		when 'setposition'
			#puts "Estoy en setposition"
			if (callFunc.listArg.list_Arg  == nil)
				puts "Faltan argumentos para la funcion setposition. Se esperan 2 argumentos."
				return 1
			elsif (callFunc.listArg.list_Arg.list_Arg != nil)
				puts "Exceso de argumentos para la funcion setposition. Se esperan 2 argumentos."
				return 1
			else
				type1 = expr_Handler(callFunc.listArg.arg.var)
				type2 = expr_Handler(callFunc.listArg.list_Arg.arg.var)
				if (type1 == :Number && type2 == :Number)
					return 0
				else
					puts "El tipo de los argumentos de la funcion setposition debe ser Number, " \
					     "usted introdujo para el argumento 1: #{type1} y para el argumento 2: " \
					     "#{type2}."
					return 1
				end
			end
		when 'arc'
		#puts "Estoy en arc"
			if (callFunc.listArg.list_Arg  == nil)
				puts "Faltan argumentos para la funcion arc. Se esperan 2 argumentos."
				return 1
			elsif (callFunc.listArg.list_Arg.list_Arg != nil)
				puts "Exceso de argumentos para la funcion arc. Se esperan 2 argumentos."
				return 1
			else
				type1 = expr_Handler(callFunc.listArg.arg.var)
				type2 = expr_Handler(callFunc.listArg.list_Arg.arg.var)
				if (type1 == :Number && type2 == :Number)
					return 0
				else
					puts "El tipo de los argumentos de la funcion arc debe ser Number, " \
					     "usted introdujo para el argumento 1: #{type1} y para el argumento 2: " \
					     "#{type2}."
					return 1
				end
			end
		else 
			#Verificar que exista el identificador en la tabla de simbolos sino no existe
			#si existe verificamos que los parametros sean del tipo correcto	
    end

end


# Manejador de la instruccion CONDITIONAL STATEMENT.
def conditional_Handler(cond)
	typeExpr = expr_Handler(cond.exp)
	result = 0
	if (typeExpr != :Bool)
		puts "CONDITIONAL STATEMENT ERROR: expression must be boolean."
		result = 1
	end
  
	instError= linst_Handler(cond.list_inst)

	
	cond1Error=0
	if (cond.cond1 != nil)
		cond1Error= cond1_Handler(cond.cond1)
	end
	
	return result + instError + cond1Error
end

def cond1_Handler(cond1)
    condError=0
    if (cond1.list_inst != nil)
		condError= linst_Handler(cond1.list_inst)
	end

  	return condError
end 

# Manejador de la instruccion DET LOOP.
def Loop_Handler(lLoop)
    case lLoop.type
	when :While
		result = 0
		expr = lLoop.exp
		if (expr_Handler(expr) != :Bool)
			puts " ERROR: expression must be boolean."
			result += 1
		end

		case lLoop.loopInst.type
		when :ListInst
			instr = lLoop.loopInst.listInst
			result += linst_Handler(instr)
		when :InstBlq
			result = bloqInstr_Handler(lLoop.loopInst.inst_blq)
		when :InstBlq2
			result1= bloqInstr_Handler(lLoop.loopInst.inst_blq)
			result2 = linst_Handler(lLoop.loopInst.listInst)
            result = result1 + result2
        end
		return result
	when :For
			result = 0
			iterVar = lLoop.var.nameTerm.idAndValue[1]
			# Busca la variable, si la encuentra, la actualiza, si no, la inserta.
			if ($symTable.lookup(iterVar) == nil)
				$symTable.insert(iterVar, [:Number, 0])
			else
				$symTable.update(iterVar, [:Number, 0])
			end
			num1= lLoop.num1.term
			num2= lLoop.num2.term
            if (num1 == :Ints) & (num2 == :Ints)
            	case lLoop.loopInst.type
				when :ListInst
					instr = lLoop.loopInst.listInst
					result += linst_Handler(instr)
				when :InstBlq
					result = bloqInstr_Handler(lLoop.loopInst.inst_blq)
				when :InstBlq2
					result1= bloqInstr_Handler(lLoop.loopInst.inst_blq)
					result2 = linst_Handler(lLoop.loopInst.listInst)
		            result = result1 + result2
		        end
            else
            	puts "La cotas del ciclo FOR deben ser numeros enteros, usted ingreso : Inferior #{lLoop.num1.term} Superior #{lLoop.num2.term}"
           		result += 1
            end

			return result
		

	when :Repeat
		result = 0
		num1= lLoop.num1.term
		if (num1 == :Ints)
				case lLoop.loopInst.type
				when :ListInst
					instr = lLoop.loopInst.listInst
					result += linst_Handler(instr)
				when :InstBlq
					result = bloqInstr_Handler(lLoop.loopInst.inst_blq)
				when :InstBlq2
					result1= bloqInstr_Handler(lLoop.loopInst.inst_blq)
					result2 = linst_Handler(lLoop.loopInst.listInst)
		            result = result1 + result2
		        end
        else
			puts "El tipo del numero de repeticiones debe ser enteros, usted ingreso: #{lLoop.num1.term}"
           	result += 1
        end
    	return result
    end	
end

# Manejador de rReturn
def return_Handler(rReturn,type)
	rReturnType = expr_Handler(rReturn)
    #puts "rReturnType #{rReturnType}"
    if (rReturnType !=:Number)
    	puts "El tipo para return: #{rReturnType} no coincide con el tipo de retorno de la funcion #{type}"
    end	
    return 1
    #else	
		return 0
	#end	
end

#Manejador de lista de declaraciones
def lDecl_Handler(ldecl)
	#Manejo de la estructura.
    listDeclError = 0
	if (ldecl.declaration_list != nil)
		listDeclError = lDecl_Handler(ldecl.declaration_list)
	end

    declError =  decl_Handler(ldecl.decl)

	return listDeclError + declError
end

#Manejador de declaraciones
def decl_Handler(decl)
	error = 0
	asigError = 0
	#puts decl.tipo.class
	case decl.tipo
	when :Number
		if (decl.decl1.list_id.instance_of?(Asig))
			asigError = asig_Handler(:Number, decl.decl1.list_id)
		else
			error = listId_Handler(:Number, decl.decl1.list_id)
	    end
	when :Bool
		if (decl.decl1.list_id.instance_of?(Asig))
			asigError = asig_Handler(:Bool, decl.decl1.list_id)
		else
			error = listId_Handler(:Bool, decl.decl1.list_id)
	    end
	end
	
	return error + asigError 
end
##################################################
# Manejador de las expresiones del programa #
##################################################
def expr_Handler(expr)
	# Procesar como binaria
	if expr.instance_of?(BinOp)
		return binExp_Handler(expr)
	# Procesar como unaria
	elsif expr.instance_of?(UnOp)
		return unaExp_Handler(expr)
	# Procesar como parentizada
	elsif expr.instance_of?(ParenEx)
		return parExp_Handler(expr)
	# Procesar como un caso base, un termino.
	elsif expr.instance_of?(CallFunc)
		return callFuncT_Handler(expr)
	elsif expr.instance_of?(Term)
		type = expr.term
        #puts "TYPO DE LA EXPR #{type}"
		case type
		when :Identifier			
			idVar = expr.nameTerm.idAndValue[1] 
			
			typeVar = $symTable.lookup(idVar)[0]
			return typeVar
		when :True
			return :Bool
		when :False
			return :Bool
		when :Ints
			return :Number	
		when :Floats
			return :Number
		when :Strings
			return :String

		end
	else
		puts "ERROR: hubo un errror expression_Handler."		
	end
end

def callFuncT_Handler(expr)
	if (callFunc(expr)==0)
		if !($symTable.contains(expr.var.nameTerm.idAndValue[1]))
		    return $symTable.lookup(idVar)[0]	
		end
	end
end
# Manejador de expresiones binarias:
# Devuelve el tipo de las expresiones binarias
# => si hay un error de tipo, devuelve nil.
def binExp_Handler(expr)
	
	typeExpr1 = expr_Handler(expr.left)
	typeExpr2 = expr_Handler(expr.right)
	if (typeExpr1 != typeExpr2)
		return nil
	end
	case expr.op
	when /^(or|and)/
		if typeExpr1 == :Bool
			return :Bool
		else
			return nil
		end

	when /^(==|\/=)/
		return :Bool

	when /^[\+\-\*\/%]/
		if (typeExpr1 == :Number) and (typeExpr2 == :Number)
			return :Number
		else
			return nil
		end
	when /^(mod|div)/
		if (typeExpr1 == :Number) and (typeExpr2 == :Number)
			return :Number
		else
			return nil
		end

	when /^(<|>|<=|>=)/
		if (typeExpr1 == :Number) and (typeExpr2 == :Number)
			return :Bool
		else
			return nil
		end
	end
end

# Manejador de expresiones parentizadas.
def parExp_Handler(expr)
	return expr_Handler(expr.expr)
end

# Manejador de expresiones unarias.
def unaExp_Handler(expr)
	typeExpr = expr_Handler(expr.right)
	case expr.op
	when /not/
		if typeExpr == :Bool
			return :Bool
		else
			return nil
		end
	when /-/
		if typeExpr == :Number
			return :Number
		else
			return nil
		end
	end
end

#Manejador para lista de Id
def listId_Handler(type, listI)
    if !($symTable.contains(listI.var.nameTerm.idAndValue[1]))
    	# puts "esto es una prueba"
    
        case type
			when :Number
				$symTable.insert(listI.var.nameTerm.idAndValue[1], [type, 0])
			when :Bool
				$symTable.insert(listI.var.nameTerm.idAndValue[1], [type, false])
        end

		if (listI.list_id != nil)                  
			return listId_Handler(type, listI.list_id)  
		end
		return 0
	else
		puts "ERROR: variable '#{listI.var.nameTerm.idAndValue[1]}' was declared before" \
				" at the same scope."
		if (listI.list_id != nil)                           # Cambie .listI por .list_id
			return listId_Handler(type,listI.list_id) + 1  # Cambie .listI por .list_id
		end
		return 1
	end
end

#####################################
# Manejador de funciones del usuario#
####################################
#Manejador de lista de declaraciones de funciones
def lFunc_Handler(lfun)
	
	#Manejo de la estructura.
    listFuncError = 0
	if (lfun.function_list  != nil)
		listDeclError = lFunc_Handler(lfun.function_list)
	end

    funcError =  func_Handler(lfun.declFunc)

	return listFuncError + funcError
end

# Manejador de funciones #
def func_Handler(funciones)
	#Verificamos que no esxita el identificador en la tabla de simbolos
	if !($symTable.contains(funciones.nombre))
		#TIPO DE LA FUNCION#
		firmError =0
		if (funciones.firma != nil)
			type = funciones.firma.type
		else 
			type = :void 	
		end
		 if (type != :Number) and (type != :Bool)
		    puts "En la declaracion de la funcion #{funciones.nombre}, tipo de retorno Desconocido"
		    firmError =1
		 end
        if (funciones.list_Arg!=nil)
        	argError = listArg_Handler(funciones.list_Arg)
        end	
		#puts "+++++++++++++++++++ #{funciones.firma.type}"
		instrError = linst_Handler(funciones.list_inst,funciones.firma.type)

		if ((instrError + firmError + argError)==0)
		 	$symTable.insert(funciones.nombre, [:Funtion,type,funciones.list_Arg,funciones.list_inst])
		end
		return 0

	else 
		puts "ERROR: funcion '#{funciones.nombre}' was declared before" 
        return 1
    end
end

def listArg_Handler(list_Arg)

	argError =  arg_Handler(list_Arg.arg)

	listArgError = 0
	if (list_Arg.list_Arg != nil)
		listArgError = listArg_Handler(list_Arg.list_Arg)
	end

	return listArgError + argError
end

def arg_Handler(arg)
	type = arg.tipo
	if (type == :Number) or  (type == :Bool)
		name= arg.var.nameTerm.idAndValue[1]
		case type
			when :Number
				$symTable.insert(name, [type, 0])
			when :Bool
				$symTable.insert(name, [type, false])
        end
		return 0
	else
		puts "ERROR: unknown type: #{type}."
        return 1
	end

end

