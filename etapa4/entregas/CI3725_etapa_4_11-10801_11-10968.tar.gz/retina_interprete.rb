
require_relative 'retina_hanTable'
require_relative 'retina_tortuga'

$returnValue
$imagen = Tortuga.new

#Interpretador de programas
def program_Interpreter(ast)
	s_Interpreter(ast.s)
end
# Interpretador de alcances.
def s_Interpreter(s)
	$symTable = s.symTab
	#if (s.funciones != nil)
	#	func_Interpreter(s.funciones)
	#end
	bloqInstr_Interpreter(s.bloqIns)
	$symTable = $symTable.father
end

# Interpretador del bloque de instrucciones
def bloqInstr_Interpreter(bloque)
	#puts " Estoy en bloque_Interpreter con type  #{bloque.class}"
	if (bloque.decla_list !=nil)
		ldecl_Interpreter(bloque.decla_list)
	end
	#Manejo de la estructura.
	bloqInstr2_Interpreter(bloque.inst_blq1)
end

#  Interpretador Auxiliar  del bloque de instrucciones
def bloqInstr2_Interpreter(bloque)
	#puts " Estoy en bloque2_Interpreter con type  #{bloque.class}"

	if (bloque.instruction_list != nil)
		instError = lInstr_Interpreter(bloque.instruction_list)
	end

	if (bloque.inst_blq!= nil)
		bloqError = bloqInstr_Interpreter(bloque.inst_blq)
	end

end	

# Interpretador de lista de instrucciones
def lInstr_Interpreter(lInst)
    
    #puts " Estoy en lInstr_Interpreter con type  #{lInst.class}"
    if (lInst.list_inst !=nil)
		lInstr_Interpreter(lInst.list_inst)
    end
    instr_Interpreter(lInst.inst)
end
# Interpretador de instrucciones
def instr_Interpreter(instr)
	#puts "Estoy en inst_Handler con instr de tipo: #{instr.class}"
	#puts " Estoy en instr_Interpreter con type  #{instr.type}"
	#puts instr.type
	case instr.type
	when :Asig
		 asig_Interpreter(instr.argumentos[0])
	when :Read
		read_Interpreter(instr)
	when :Write
		write_Interpreter(instr)
	when :Writeln
		 writeln_Interpreter(instr)
	when :CallFunc
		 CallFunc_Interpreter(instr.argumentos[0])
	when :Conditional
		conditional_Interpreter(instr.argumentos[0])
	when :Loop
	     Loop_Interpreter(instr.argumentos[0])
	when :Return
	    return_Interpreter(instr.argumentos[0],type)
	end    
end


####################################################
# Interpretes de las instrucciones del programa #
####################################################

# Interpretador de la instriccion Asig
def asig_Interpreter(asig)
	#puts "Estoy en asig_Handler con asig de tipo: #{asig.class}"
	#puts " Estoy en asig_Interpreter con type  #{asig.class}"
	idVar = asig.id_expr[0].nameTerm.idAndValue[1] 
	#puts "lo que hay en idVar #{idVar}"
	typeVar = $symTable.lookup(idVar)[0]
   # puts "lo que hay en expre #{asig.id_expr[1]}"
	exprVar = expr_Interpreter(asig.id_expr[1])
	$symTable.update(idVar, [typeVar, exprVar])

end

# Interpretador de la instruccion read.
def read_Interpreter(read)
    
	idVar = read.argumentos[0].nameTerm.idAndValue[1]
	typeVar = $symTable.lookup(idVar)[0]
	valid = false
	# Se espera a que se lea una entrada valida.
	while !valid
		auxVar = STDIN.gets()
		auxVar.slice! "\n"
		# Verificación de tipo
		case auxVar
			when /^\d+/
				if (typeVar == :Number)
				auxVar = auxVar.to_i
				valid = true
				#puts "lo que lei #{auxVar}"
				end
			when /^true/
				if (typeVar == :Bool)
				auxVar = true
				valid = true
				end
			when /^false/
				if (typeVar == :Bool)
				auxVar = false
				valid = true
				end
		end
	end
	$symTable.update(idVar, [typeVar, auxVar])
end

# Interpretador de la instruccion write.
def write_Interpreter(write)
	#puts "estoy en write con: #{write.argumentos[0]}"
    expr = write.argumentos[0]
	print expr_Interpreter(expr)
end
# Interpretador de la instruccion writeln.
def writeln_Interpreter(writeln)
	expr = write.argumentos[0]
	puts expr_Interpreter(expr)
end

#Interpretador de instMov
def CallFunc_Interpreter(instr)

   nameFunc =instr.var.nameTerm.idAndValue[1]
   #puts "nombre de la funcion #{nameFunc}"
   if (instMovFunction(nameFunc)) then
   		#Verificamos los argumentos
   		#puts "lo que hay en instr.listArg #{instr.listArg}"
   		if (instr.listArg!=nil)
   			arg1 = instr.listArg.arg.var
   			#puts "los que hay en arg1 #{arg1}"
   			#Verificamos instMoV2
   			if (instr.listArg.list_Arg !=nil)
				arg2 = instr.listArg.list_Arg.arg.var
			#	puts "los que hay en arg2 #{arg2}"
			end
		end
		arg1 = expr_Interpreter(arg1) unless arg1.nil?
		arg2 = expr_Interpreter(arg2) unless arg2.nil?
		#puts "antes de la llamada #{nameFunc}"
		$imagen.callInstMovFunc(nameFunc, arg1, arg2)
		return;
	else 
		if ($symTable.contains(instr.var.nameTerm.idAndValue[1]))
			func_Interpreter(instr)
		else 
			puts "Funcion no definida"
		end	

	end	

end

# Chequear que sea funcion de movimiento
def instMovFunction(identifier)
	return ["home","openeye","closeeye","forward","backward","rotater","rotatel","setposition","arc"].include? identifier
end

#Interpretador de condicional
def conditional_Interpreter(cond)
	#puts " Estoy en conditional_Interpreter con type  #{cond.class}"
	expr = cond.exp
    instr = cond.list_inst
	if (cond.cond1 != nil)
		instr2 = cond.cond1 
	    if (expr_Interpreter(expr))
	    	lInstr_Interpreter(instr)
	    else
	    	lInstr_Interpreter(instr2)
	    end
    else
    	if (expr_Interpreter(expr))
	    	lInstr_Interpreter(instr)
	    end
	end
end

# Interpretador de la instruccion loop.
def Loop_Interpreter(lLoop)
	#puts "Estoy en Loop_Interpreter con lLoop de tipo: #{lLoop.class}"
	#puts "Estoy en Loop_Interpreter con lLoop de tipo: #{lLoop.type}"
	#puts "lo que hay en el symTable #{$symTable.symTable}"
    expr = lLoop.exp
    case lLoop.type
	when :While
		while (expr_Interpreter(expr))
			case lLoop.loopInst.type
			when :ListInst
				lInstr_Interpreter(lLoop.loopInst.listInst)
			when :InstBlq
				 bloqInstr_Interpreter(lLoop.loopInst.inst_blq)
			when :InstBlq2
				 bloqInstr_Interpreter(lLoop.loopInst.inst_blq)
				 lInstr_Interpreter(lLoop.loopInst.listInst)
	        end
		end	
	when :For

			iterVar = lLoop.var.nameTerm.idAndValue[1]
			#Si no existe la variable la agrego
			if ($symTable.lookup(iterVar) == nil)
				$symTable.insert(iterVar, [:Number, 0])
			end
			type = $symTable.lookup(iterVar)[0]
			num1 = lLoop.num1
			num2 = lLoop.num2
			iniVal = expr_Interpreter(num1)
			finVal = expr_Interpreter(num2)
			$symTable.update(iterVar, [type, iniVal])
			while (iniVal <= finVal)
					case lLoop.loopInst.type
					when :ListInst
						lInstr_Interpreter(lLoop.loopInst.listInst)
					when :InstBlq
						 bloqInstr_Interpreter(lLoop.loopInst.inst_blq)
					when :InstBlq2
						 bloqInstr_Interpreter(lLoop.loopInst.inst_blq)
						 lInstr_Interpreter(lLoop.loopInst.listInst)
			        end
				iniVal += 1
				$symTable.update(iterVar, [type, iniVal])
			end

	when :Repeat
		#puts "estoy en el Repeat"
		
		result = 0
		num= lLoop.num1.nameTerm.idAndValue[1].to_i
		#puts "lo que hay en num #{num}"

		for i in 0..num-1 
			case lLoop.loopInst.type
				when :ListInst
					lInstr_Interpreter(lLoop.loopInst.listInst)
				when :InstBlq
					bloqInstr_Interpreter(lLoop.loopInst.inst_blq)
				when :InstBlq2
					bloqInstr_Interpreter(lLoop.loopInst.inst_blq)
					lInstr_Interpreter(lLoop.loopInst.listInst)
			    end
			i=i+1	
		end
    end	
end
def return_Interpreter(rReturn,type)
	#expr_Interpreter(rReturn.nameTerm.idAndValue[1])

end	

def ldecl_Interpreter(ldecl)
	if (ldecl.declaration_list != nil)
		ldecl_Interpreter(ldecl.declaration_list)
	end
   decl_Interpreter(ldecl.decl)

end	
def decl_Interpreter(decl)
	
	if (decl.decl1.list_id.instance_of?(Asig))
		asig_Interpreter(decl.decl1.list_id)
	end
end	


##################################################
# Interpretador de las expresiones del programa #
##################################################

# Interpretador de expresiones
def expr_Interpreter(expr)
	#puts "Estoy en expr_Interpreter con expr de tipo: #{expr.class}"
	#puts "lo que hay en el symTable #{$symTable.symTable}"
	# Procesar como binaria
	if expr.instance_of?(BinOp)
		return binExp_Interpreter(expr)
	# Procesar como unaria
	elsif expr.instance_of?(UnOp)
		return unaExp_Interpreter(expr)
	# Procesar como parentizada
	elsif expr.instance_of?(ParenEx)
		return parExp_Interpreter(expr)
	# Procesar como un caso base, un termino.

	elsif expr.instance_of?(Term)
		type = expr.term
        #puts "TYPO DE LA EXPR #{type}"

		case type
		when :Identifier			
			idVar = expr.nameTerm.idAndValue[1] 
			val = $symTable.lookup(idVar)[1]
			#puts "lo que tiene la tabla #{val.class}"
            if (val == nil)
               puts "ERROR: uninitialized variable."
				puts
				abort
			end
			return val

			return typeVar
		when :True
			return true
		when :False
			return false
		when :Ints
			idVar = expr.nameTerm.idAndValue[1]
			return Integer(idVar) 	
		when :Floats
			idVar = expr.nameTerm.idAndValue[1]
			return Float(idVar) 
		when :Strings
			idVar = expr.nameTerm.idAndValue[1]
			return String(idVar) 
		end
	else
		puts "ERROR: hubo un errror expression_Handler."		
	end
end


# Interpretador de expresiones binarias:
def binExp_Interpreter(expr)
	#puts "Estoy en binExp_Handler con expr de tipo: #{expr.class}"
	valExpr1 = expr_Interpreter(expr.left)
	valExpr2 = expr_Interpreter(expr.right)
	#puts "lo que tiene typeExpr1  #{valExpr1.class}"
	#puts "lo que tiene typeExpr2  #{valExpr2.class}" 
	if (valExpr1 == nil) or (valExpr2 == nil)
		return nil
	end
	case expr.op
	# Expresiones binarias booleanas logicas y genericas #
	when /^(or)/
		return (valExpr1 or valExpr2)
    when /^(and)/
		return (valExpr1 and valExpr2)
	when /^(==)/
		return (valExpr1 == valExpr2)
	when /^\/=/
		return (valExpr1 != valExpr2)
	# Expresiones binarias aritmeticas #
	when /^\+/
		aux = valExpr1 + valExpr2
		puts "estoy en la suma con '#{aux}'"
		overflow?(valExpr1 + valExpr2)
		return (valExpr1 + valExpr2)
	when /^\-/
		overflow?(valExpr1 - valExpr2)
		return (valExpr1 - valExpr2)
	when /^\*/
		overflow?(valExpr1 * valExpr2)
		return (valExpr1 * valExpr2)
	when /^\//
		if (valExpr2 == 0)
			puts "ZeroDivisionError: integer division or modulo by zero."
			puts
			abort
		else
			valAux= Float(valExpr1)
			return (valAux / valExpr2)
		end
	when /^%/
		if (valExpr2 == 0)
			puts "ZeroDivisionError: integer division or modulo by zero."
			puts
			abort
		else
			valAux= Float(valExpr1)
			return (valAux % valExpr2)
		end
	when /^(div)/
		if (valExpr2 == 0)
			puts "ZeroDivisionError: integer division or modulo by zero."
			puts
			abort
		else
			return (valExpr1 / valExpr2)
		end
	when /^mod/
		if (valExpr2 == 0)
			puts "ZeroDivisionError: integer division or modulo by zero."
			puts
			abort
		else
			return (valExpr1 % valExpr2)
		end
    # Expresiones binarias booleanas de comparacion
	when /^<=/
		return (valExpr1 <= valExpr2)
	when /^>=/
		return (valExpr1 >= valExpr2)
	when /^</
		return (valExpr1 < valExpr2)
	when /^>/
		return (valExpr1 > valExpr2)
	end
end

# Manejador de expresiones parentizadas.
def parExp_Interpreter(expr)
	return expr_Interpreter(expr.expr)
end

# Manejador de expresiones unarias.
def unaExp_Interpreter(expr)
	valExpr = expr_Interpreter(expr.right)
	case expr.op
	when /not/
		return !(valExpr)
	when /-/
		overflow?(-valExpr)
		return -(valExpr)
	end
end

def overflow?(int)
	if (int > 2147483647) or (int < -2147483647)
		puts "ERROR: integer overflow"
		puts
		abort
	end
end
def func_Interpreter (inst)
	if ($symTable.contains(inst.var.nameTerm.idAndValue[1]))
		instr= $symTable.lookup(idVar)[3]
		lInstr_Interpreter(instr)
	end 


end