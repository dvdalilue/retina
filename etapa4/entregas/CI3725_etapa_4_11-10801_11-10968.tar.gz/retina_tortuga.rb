



class Tortuga
	attr_accessor :alto,
    			  :ancho,
    			  :imagen,
    			  :pos_x,
    			  :pos_y,
    			  :grados,
                  :marca    

    def initialize alto = 1001, ancho = 1001,pos_x=0, pos_y =0,grados =90,marca=true
    	@alto = alto.to_i  
    	@ancho = ancho.to_i
    	@imagen = Array.new(@alto) { Array.new(@ancho) { 0 } }
    	@pos_x = pos_x.to_i
    	@pos_y = pos_y.to_i
    	@grados = grados
        @marca = marca
		@imagen[fromYToRow(@pos_y)][fromXToColumn(@pos_x)] = 1
    end

	# Llamo a la funcion de movimiento adecuada
	def callInstMovFunc(identifier, argument1 = nil, argument2 = nil)
		case identifier
			when "home"
				home()
			when "openeye"
				openeye()
			when "closeeye"
				closeeye()
			when "forward"
				pasos = argument1
				forward(pasos)
			when "backward"
				pasos = argument1
				backward(pasos)
			when "rotatel"
				grados = argument1
				rotatel(grados)
			when "rotater"
				grados = argument1
				rotater(grados)
			when "setposition"
				x = argument1
				y = argument2
				setposition(x,y)
			when "arc"
				grados = argument1
				radio = argument2
				arc(grados,radio)
		end
	end

	# Ubico el cursor en el medio.
	def home()
		@pos_y = 0
		@pos_x = 0
	end

	# Permite marcar.
	def openeye()
		@marca = true
	end

	# Desaciva el cursor, es decir, ya no marcamos.
	def closeeye()
		@marca = false
	end

	# Mueve el cursor hacia adelante tantos pasos diga "pasos",
	def forward(pasos)
		# Hallamos las coordenadas finales
		radianes = @grados * Math::PI / 180
		nueva_pos_x = (@pos_x + pasos*Math.cos(radianes)).to_i
		nueva_pos_y = (@pos_y + pasos*Math.sin(radianes)).to_i
		if(@marca) then
			marcar_puntos(@pos_x, @pos_y, nueva_pos_x, nueva_pos_y)
		end

		@pos_x = nueva_pos_x
		@pos_y = nueva_pos_y
	end

	# Mueve el cursor hacia atras tantos pasos diga "pasos"
	def backward(pasos)
		# Hallamos las coordenadas finales
		radianes = @grados * Math::PI / 180
		nueva_pos_x = (@pos_x - pasos*Math.cos(radianes)).to_i
		nueva_pos_y = (@pos_y - pasos*Math.sin(radianes)).to_i
		if(@marca) then
			marcar_puntos(@pos_x, @pos_y, nueva_pos_x, nueva_pos_y)
		end

		@pos_x = nueva_pos_x
		@pos_y = nueva_pos_y
	end

	# Rota el cursor en sentido antihorario.
	def rotatel(grado_rot)
		@grados = (@grados + grado_rot) % 360;
	end

	# Rota el cursor en sentido horario.
	def rotater(grado_rot)
		@grados = (@grados - grado_rot) % 360;
	end

	# Coloco el cursor en las coorenadas x,y
	def setposition(x,y)
		@pos_x = x.to_i
		@pos_y = y.to_i
	end

	# Ejercicio interesante que aun no implementamos. :)
	def arc(degree,radius)
	end

	# Guarda una imagen con extension .pbm
	def almacenar()
		# Capturo el nombre del archivo con el programa de entrada.
		input = ARGV[0]
		# Lo convierto en .pbm
		input = File.basename(input,".rtn")
		input << ".pbm"

		newImage = File.open(input, "w")
		# Incluyo dimensiones al nuevo archivo.
		newImage.puts("P1")
		newImage.print(@ancho)
		newImage.print(' ')
		newImage.puts(@alto)

		# Guardo la matriz
		@imagen.each do |fila|
			fila.each do |pixel|
				newImage.print pixel, ' '
			end
			newImage.puts
		end
		newImage.close
	end

	# Traza una linea desde (x0,y0) hasta (x1,y1)
	def marcar_puntos(x0, y0, x1, y1)
		puntos = obtener_linea(x0,x1,y0,y1)
		puntos.each do |punto|
			x = punto[:x]
			y = punto[:y]

			fila = fromYToRow(y)
			columna = fromXToColumn(x)
			# Enciendo un pixel.
			if(point_in_matrix(fila,columna)) then
				@imagen[fila][columna] = 1
			end
		end
	end

	# Get points on line from (x0,y0) to (x1,y1)
	def obtener_linea(x0,x1,y0,y1)
		puntos = []
		pendiente = ((y1-y0).abs) > ((x1-x0).abs)
		if pendiente then
			x0,y0 = y0,x0
			x1,y1 = y1,x1
		end
		if x0 > x1
			x0,x1 = x1,x0
			y0,y1 = y1,y0
		end
		variacion_x = x1-x0
		variacion_y = (y1-y0).abs
		error = (variacion_x / 2).to_i
		y = y0
		paso_y = nil
		if y0 < y1 then
			paso_y = 1
		else
			paso_y = -1
		end
		for x in x0..x1
			if pendiente then
				puntos << {:x => y, :y => x}
			else
				puntos << {:x => x, :y => y}
			end
			error -= variacion_y
			if error < 0 then
				y += paso_y
				error += variacion_x
			end
		end
		return puntos
	end

	# Vemos que el punto pertenezca a la matriz.
	def point_in_matrix(fila, columna)
		return (0<=fila and fila<@alto and 0<=columna and columna<@ancho)
	end

	# Convierte entrada cartesiana x en una columna.
	def fromXToColumn(x)
		return (((@ancho-1)/2) + x).to_i
	end

	# Convierte entrada cartesiana y en una fila.
	def fromYToRow(y)
		return (((@ancho-1)/2) - y).to_i
	end
end