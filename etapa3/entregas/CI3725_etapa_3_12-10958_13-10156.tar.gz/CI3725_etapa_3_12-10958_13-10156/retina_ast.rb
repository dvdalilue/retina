require_relative "retina_lexer"
class Contexto < RuntimeError; end
class Faltasimbolo < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: variable #{@variable} no declarada. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Faltareturn < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: la funcion #{@variable} deberia tener return. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Clase_number < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: la variable '#{@variable}'' es de tipo number y se le asigna una expresion de tipo Bool. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Clase_bool < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: la variable '#{@variable}' es de tipo boolean y se le asigna una expresion de tipo Number. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Asignacion_funcion < Contexto
    def initialize(a,b,c,d,e)
        @variable=a
        @tipo=b
        @funcion=c
        @tipo_f=d
        @token=e
    end
    def to_s
        if @tipo_f==nil
            @tipo_f='nulo'
        end
        "ERROR: la variable '#{@variable}' es de tipo #{@tipo}  y se le asigna la funcion '#{@funcion}' de retorno #{@tipo_f}. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Cantidad_parametros < Contexto
    def initialize(a,b,c,d)
        @variable=a
        @numero_f=b
        @numero=c
        @token=d
    end
    def to_s
        "ERROR: La funcion '#{@variable}' tiene #{@numero_f} parametros y se colocan #{@numero}. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Tipo_erroneo < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: El tipo de los argumentos del llamado de la funcion '#{@variable}' no corresponden a la definicion. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Mal_retorno < Contexto
    def initialize(a,b)
        @variable=a
        @linea=b
    end
    def to_s
        "ERROR: La funcion '#{@variable}' no debe tener instruccion de retorno Linea:#{@linea.linea}, columna:#{@linea.columna}"
    end
end
class Retorno_clase < Contexto
    def initialize(a,b,c,d)
        @variable=a
        @tipo_f=b
        @tipo=c
        @token=d

    end
    def to_s
        "ERROR: La funcion '#{@variable.id}' debe tener un retorno de tipo #{@tipo_f} y no de tipo #{@tipo}.Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 
class Error_declaracion < Contexto
    def initialize(a)
        @variable=a
    end
    def to_s
        "ERROR: El identificador '#{@variable.id}' ya esta declarado en el mismo alcance.Linea:#{@variable.linea}, columna:#{@variable.columna}"
    end
end 
class Expresion_booleana < Contexto
    def initialize(a)
        @variable=a
    end
    def to_s
        "ERROR: Se requiere de una expresion de tipo booleana.Linea:#{@variable.linea}, columna:#{@variable.columna}"
    end
end 
class Expresion_number < Contexto
    def initialize(a)
        @variable=a
    end
    def to_s
        "ERROR: Se requiere de una expresion de tipo number.Linea:#{@variable.linea}, columna:#{@variable.columna}"
    end
end 
class No_retorno < Contexto
    def initialize(a)
        @variable=a
    end
    def to_s
        "ERROR: En el bloque program no debe haber retorno.Linea:#{@variable.linea}, columna:#{@variable.columna-7}"
    end
end 
class Expresion_invalida < Contexto
    def initialize(a)
        @variable=a
    end
    def to_s
        "ERROR: Expresion invalida. Linea:#{@variable.linea}, columna:#{@variable.columna}"
    end
end 
class Identificador_invalido < Contexto
    def initialize(a)
        @variable=a
    end
    def to_s
        "ERROR: El identificador que se desea utilizar corresponde al identificador de una funcion. Linea:#{@variable.linea}, columna:#{@variable.columna}"
    end
end 

class Mala_impresion < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: La funcion '#{@variable}' no posee una variable de retorno que se pueda imprimir. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 

class No_funcion < Contexto
    def initialize(a,b)
        @variable=a
        @token=b
    end
    def to_s
        "ERROR: La variable '#{@variable}' no es una funcion. Linea:#{@token.linea}, columna:#{@token.columna}"
    end
end 

def funciones_predefinidas(dic)
    dic_home={}
    dic_home['tipo']=nil
    dic_home['args']=nil
    dic_home['number']=0
    dic_home['token']=Identificador.new(Identificadores.new('home',0,0))
    dic.add('home',dic_home)

    dic_openeye={}
    dic_openeye['tipo']=nil
    dic_openeye['args']=nil
    dic_openeye['number']=0
    dic_openeye['token']=Identificador.new(Identificadores.new('openeye',0,0))
    dic.add('openeye',dic_openeye)

    dic_closeeye={}
    dic_closeeye['tipo']=nil
    dic_closeeye['args']=nil
    dic_closeeye['number']=0
    dic_closeeye['token']=Identificador.new(Identificadores.new('closeeye',0,0))
    dic.add('closeeye',dic_closeeye)

    dic_forward={}
    aux_forward={}
    aux_forward['x']='number'
    dic_forward['tipo']=nil
    dic_forward['args']=aux_forward
    dic_forward['number']=1
    dic_forward['token']=Identificador.new(Identificadores.new('forward',0,0))
    dic.add('forward',dic_forward)

    dic_backward={}
    aux_backward={}
    aux_backward['x']='number'
    dic_backward['tipo']=nil
    dic_backward['args']=aux_backward
    dic_backward['number']=1
    dic_backward['token']=Identificador.new(Identificadores.new('backward',0,0))
    dic.add('backward',dic_backward)

    dic_rotatel={}
    aux_rotatel={}
    aux_rotatel['x']='number'
    dic_rotatel['tipo']=nil
    dic_rotatel['args']=aux_rotatel
    dic_rotatel['number']=1
    dic_rotatel['token']=Identificador.new(Identificadores.new('rotatel',0,0))
    dic.add('rotatel',dic_rotatel)

    dic_rotater={}
    aux_rotater={}
    aux_rotater['x']='number'
    dic_rotater['tipo']=nil
    dic_rotater['args']=aux_rotater
    dic_rotater['number']=1
    dic_rotater['token']=Identificador.new(Identificadores.new('rotater',0,0))
    dic.add('rotater',dic_rotater)

    dic_setposition={}
    aux_setposition={}
    aux_setposition['x']='number'
    aux_setposition['y']='number'
    dic_setposition['tipo']=nil
    dic_setposition['args']=aux_setposition
    dic_setposition['number']=2
    dic_setposition['token']=Identificador.new(Identificadores.new('setposition',0,0))
    dic.add('setposition',dic_setposition)

    dic_arc={}
    aux_arc={}
    aux_arc['x']='number'
    aux_arc['y']='number'
    dic_arc['tipo']=nil
    dic_arc['args']=aux_arc
    dic_arc['number']=2
    dic_arc['token']=Identificador.new(Identificadores.new('arc',0,0))
    dic.add('arc',dic_arc)
end

class Tabla_simbolos
    attr_accessor :padre, :dic, :funcion_actual, :retorno
    def initialize (dic)
        @padre=dic
        @dic={}
        if dic!=nil
            @funcion_actual=dic.funcion_actual
            @retorno=dic.retorno
        else
            @funcion_actual=nil
            @retorno=false
        end
    end 
    def add(a,b)
        @dic[a]=b
    end 
    def isIn(a, b)
        if @dic.has_key? a
            return true
            puts a
        elsif @padre!= nil
            return @padre.isIn(a,b)
        else 
            raise Faltasimbolo.new(a,b)
            return false #Raise error
        end
    end
    def consulta(a, b)
        if isIn(a,b)
            if @dic.has_key? a
                return @dic[a]
            else
                return @padre.consulta(a,b)
            end
        else 
            return false
        end
    end
    def isFun(a)
        #puts @dic.has_key? a
        #puts a
        #puts @dic[a].class
        if @dic.has_key? a.id
            if @dic[a.id].class==Hash
                raise Identificador_invalido.new(a)
            end
        elsif @padre!=nil
            @padre.isFun(a)
        end
    end        

    def actualizarDic(dic)
        @dic=dic
    end
    def actualizarFA(a)
        @funcion_actual=a
    end
    def actualizarRetorno(a)
        if @padre!=nil
            @padre.actualizarRetorno(a)
        end
        @retorno=a
    end
end
class RetinaP
    attr_accessor :func, :prog
    #prog Programa
    #func Lista_declaracion_funcion
    def initialize (a,b)
        @func=a
        @prog=b
    end
    def analisis
        tabla_simbolos=Tabla_simbolos.new(nil)
        funciones_predefinidas(tabla_simbolos)
        if @func != nil
            @func.getInf(tabla_simbolos)
            @func.analisis(tabla_simbolos)
            #puts tabla_simbolos.dic
        end
        tabla_simbolos.actualizarFA(nil)
        @prog.analisis(tabla_simbolos)
    end
    def print_ast indent=""
        #puts "#{indent}#{self.class}:"
        if @func != nil
            @func.print_ast(indent)
        end
        @prog.print_ast(indent)
    end
end
class Lista_declaracion_funcion 
    #Declaracion_funcion
    #Requiere verificar que no se repiten los identificadores de las funciones
    attr_accessor :l
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else 
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
    def getInf dic
        @l.each do |f|
            dic.isFun(f.ident.digit)
            dic.add(f.ident.digit.id, f.getInf())
        end
    end
    def analisis dic
        tabla={}
        @l.each do |f|
            isInTablaSimbolos(f.ident.digit,tabla)
            tabla[f.ident.digit.id]=true
        end  
        @l.each do |f|
            f.analisis(dic)
        end
    end
    def print_ast (indent="")
        @l.each do |a|
            a.print_ast(indent+"") if a.respond_to? :print_ast
        end 
    end

end
class Declaracion_funcion
    #ident, Identificador, 
    #Param, Parametros_para_declaracion, hacer un un diccionario que contenga estos datos pues
    #son los que van a verificar las instrucciones
    #tipo, Tipo
    #inst, Lista_instruccion, verificar listado de instruccion
    attr_accessor :ident, :param, :tipo, :inst
    def initialize(a,b,c,d) 
        @ident=a
        @param=b
        @tipo=c
        @inst=d
    end
    def getInf
        dic={}
        dic['token']=@ident
        if @tipo!=nil
            dic['tipo']=@tipo.digit.id 
        else 
            dic['tipo']=nil
        end
        if @param!=nil
            dic['args']=@param.getParametros()
            dic['number']=@param.getNumber()
        else 
            dic['args']=nil
            dic['number']=0
        end
        dic['return']=false

        return dic
    end
    def analisis dic
        if @param!=nil
            @param.analisis(dic)
        end
        #Tengo qe hacer una rutina especial para cumplr este objetivo
        tabla_simbolos=Tabla_simbolos.new(dic)
        if @param!=nil
            tabla_simbolos.actualizarDic(@param.getParametros())
        end
        tabla_simbolos.actualizarFA(@ident.digit.id)
        analisis_lista_instrucciones(@inst, tabla_simbolos)
        if (dic.dic[@ident.digit.id]['tipo']!=nil && dic.dic[@ident.digit.id]['return']==false) 
            raise Faltareturn.new(@ident.digit.id,@ident.digit)
        end
    end
    def print_ast (indent="")
        puts "#{indent}Alcance funcion _#{@ident.digit.id}:"
        if @param!=nil
            puts "#{indent}   Variables:"
            @param.print_ast(indent+"     ")
            #@param.l.each do |a|
            #    a.print_ast(indent+"     ") if a.respond_to? :print_ast
            #end
        else
            puts "#{indent}   Variables: None" 
        end
        puts "#{indent}   Sub_alcances:"
        @inst.l.each do |a|
            a.print_ast(indent+"     ") if a.respond_to? :print_ast
        end 
    end
end
class Parametros_para_declaracion
    #Lista de objetos Declaracion
    #Requiere verificar que no se repitan los identificadores
    attr_accessor :l
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
    #Raise error si alguno se repite
    def getParametros
        dic={}
        @l.each do |f|
            dic[f.iden.digit.id]=f.tipo.digit.id
        end
        return dic
    end
    def getNumber
        i=0
        @l.each do |f|
            i=i+1
        end
        return i
    end
    def analisis dic
        tabla={}
        @l.each do |f|
            dic.isFun(f.iden.digit)
            isInTablaSimbolos(f.iden.digit,tabla)
            tabla[f.iden.digit.id]=true
        end  
    end
    def print_ast (indent="")
        @l.each do |a|
            puts "#{indent}#{a.iden.digit.id}:  #{a.tipo.digit.id}"
        end

    end
end
class Declaracion
    #Como son parametros para declarar una funcion, no requiere mayor verificacion, ni siquiera deben estar 
    #en la tabla de simbolos
    #Tipo
    #Identificador
    attr_accessor :tipo, :iden

    def initialize (a,b)
        @iden=b
        @tipo=a
    end
end

class Programa
    attr_accessor :inst
    #inst Lista_instruccion
    def initialize d 
        @inst = d
    end
    def analisis dic
        analisis_lista_instrucciones(@inst,dic)
    end
    def print_ast (indent="")
        i=1
        puts "#{indent}Alcance _program:\n#{indent}   Variables: None\n#{indent}   Sub_alcances:"
        #puts "#{indent}#{self.class}:"
        @inst.l.each do |a|
            a.print_ast(indent+"     ") if a.respond_to? :print_ast
        end 
        #puts i
    end
end
class Lista_instruccion
    attr_accessor :l
    #Muchas clases, ej Bloque, Asignacion, Return, etc
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else 
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
end
class Bloque
    #decla, Lista_declaracion, verificar que no se repitan los identificadores
    #inst, Lista_instrucciones
    attr_accessor :decla, :inst 

    def initialize (a,b)
        @decla=a
        @inst=b
    end
    def analisis dic
        tabla_simbolos=Tabla_simbolos.new(dic)
        if @decla != nil
            @decla.l.each do |f|
                if f.ident != nil
                    f.ident.l.each do |g|
                       tabla_simbolos.isFun(g.digit) 
                       tabla_simbolos.add(g.digit.id,f.tipo.digit.id)
                   end
               else 
                    tabla_simbolos.isFun(f.asig.iden.digit)
                    tabla_simbolos.add(f.asig.iden.digit.id,f.tipo.digit.id)
                    f.asig.analisis(tabla_simbolos)
               end
            end
            @decla.analisis(tabla_simbolos)
       end
       #puts tabla_simbolos.dic
        if inst!=nil
            analisis_lista_instrucciones(@inst, tabla_simbolos)
        end
   end
    def print_ast (indent="")
        puts "#{indent}Alcance _bloque:\n#{indent}   Variables:"
        if @decla !=nil
            @decla.l.each do |f|
                if f.ident !=nil 
                    f.ident.l.each do |g|
                        puts "#{indent}     #{g.digit.id}: #{f.tipo.digit.id}"
                    end
                else 
                    puts "#{indent}     #{f.asig.iden.digit.id}: #{f.tipo.digit.id}"
                end
            end
        end
        puts "#{indent}   Sub_alcances:"
        if inst!=nil
            @inst.l.each do |a|
                a.print_ast(indent+"     ") if a.respond_to? :print_ast
            end
        end
    end
end
class Lista_declaracion
    #Verificar que no se repitan los identificadores, done
    #Objetos Lista_declaracion1
    attr_accessor :l
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
    def analisis dic
        tabla={}
        @l.each do |f|
            if f.ident != nil
                f.ident.l.each do |g|
                    #puts tabla.class==Hash
                    #dic.isFun(g.digit.id)
                    isInTablaSimbolos(g.digit, tabla)
                    tabla[g.digit.id]=true
                end 
            else 
                #f.asig.analisis(dic)
                #dic.isFun(f.asig.iden.digit.id)
                isInTablaSimbolos(f.asig.iden.digit,tabla)
                tabla[f.asig.iden.digit.id]=true
            end
        end
    end
end
class Lista_declaracion1
    #tipo, Tipo
    #ident Lista_identificador
    #asig, Asignacion
    attr_accessor :tipo, :ident, :asig
    def initialize (a,b)
        @tipo=a
        if b.class==Lista_identificador
            @ident=b
            @asig=nil
        else
            @ident=nil
            @asig=b
        end
    end
end
class Lista_identificador
    #objetos del tipo Identificador
    #Requiere verificar que no se repitan los identificadores
    attr_accessor :l
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
end
class Asignacion 
    #expr, Expresion cualquiera
    #iden, Identificador, el identificador debe estar en el dic
    attr_accessor :expr, :iden

    def initialize (a,b)
        @iden=a
        @expr=b
    end
    def analisis dic
        dic.isFun(@iden.digit)
        dic.isIn(@iden.digit.id,@iden.digit) 
        #isNotInTablaSimbolos(@iden.digit.id, dic)
        if @expr.class!=Llamado_funcion
            if dic.consulta(@iden.digit.id, @iden.digit)=="number"
                isExpr(@expr,dic)
                if !isNumber(@expr,dic)
                    raise Clase_number.new(@iden.digit.id,@iden.digit)
                end
            elsif dic.consulta(@iden.digit.id, @iden.digit)=="boolean"
                isExpr(@expr,dic)
                if !isBool(@expr,dic)
                    raise Clase_bool.new(@iden.digit.id,@iden.digit)
                end
            end
        else
            @expr.analisis(dic)
            if dic.consulta(@expr.iden.digit.id,@expr.iden.digit)['tipo']!=dic.consulta(@iden.digit.id,@iden.digit)
                raise Asignacion_funcion.new(@iden.digit.id,dic.consulta(@iden.digit.id, @iden.digit),@expr.iden.digit.id,dic.consulta(@expr.iden.digit.id,@expr.iden.digit)['tipo'],@iden.digit)
            end
        end
    end
                
        #Debo analizar:
        #Identificador en el diccionario, done
        #Tipo de la expresion correspondiente al tipo asociado al identificador, done 
          #puts isNumber(@expr,dic)
            #puts isBool(@expr,dic)
end
class I_while
    #expr,  cualquiera
    #inst, Lista_instruccion
    attr_accessor :expr, :inst

    def initialize (a,b)
        @expr=a
        @inst=b
    end

    def analisis dic
        isExpr(@expr,dic)
        if !isBool(@expr,dic)
            raise Expresion_booleana.new(tokenExpr(@expr))
        end
        analisis_lista_instrucciones(@inst,dic)
        #Debo analizar:
        #expresion sea un booleano
        #lista de instrucciones
    end
    def print_ast (indent="")
        @inst.l.each do |a|
            a.print_ast(indent+" ") if a.respond_to? :print_ast
        end 
    end
end
class I_for
    #expr, expresion cualquiera
    #inst, Lista_instruccion
    #ident, Identificador
    attr_accessor :expr1, :ident, :expr2, :expr3, :inst

    def initialize(a,b,c,d,e)
        @ident=a
        @expr1=b
        @expr2=c
        @expr3=d
        @inst=e
    end

    def analisis dic
        dic.isFun(@ident.digit)
        tabla_simbolos=Tabla_simbolos.new(dic)
        tabla_simbolos.add(@ident.digit.id,"number")
        #puts tabla_simbolos.dic
        #puts tabla_simbolos.padre.dic
        #puts @expr3
        isExpr(@expr1,tabla_simbolos)
        isExpr(@expr2,tabla_simbolos)
        if @expr3 != nil
            isExpr(@expr3,tabla_simbolos)
            if !isNumber(@expr1,tabla_simbolos)
                raise Expresion_number.new(tokenExpr(@expr1))
            elsif !isNumber(@expr2,tabla_simbolos)
                raise Expresion_number.new(tokenExpr(@expr2))
            elsif !isNumber(@expr3,tabla_simbolos)
                raise Expresion_number.new(tokenExpr(@expr3))
            end
        else 
            if !isNumber(@expr1,tabla_simbolos)
                raise Expresion_number.new(tokenExpr(@expr1))
            elsif !isNumber(@expr2,tabla_simbolos)
                raise Expresion_number.new(tokenExpr(@expr2))    
            end
        end
        analisis_lista_instrucciones(@inst,tabla_simbolos)
        #Debo analizar:
        #Todas las expr sean numéricas, done
        #Lista de instrucciones, done
    end
    def print_ast (indent="")
        puts "#{indent}Alcance _for"
        puts "#{indent}   Variables:"
        puts "#{indent}      #{@ident.digit.id}: number"
        puts "#{indent}   Sub_alcances:"
        @inst.l.each do |a|
            a.print_ast(indent+"     ") if a.respond_to? :print_ast
        end 
    end
end
class I_repeat
    #expr, expresion cualquiera
    #inst, Lista_instruccion
    attr_accessor :expr, :inst

    def initialize (a,b)
        @expr=a
        @inst=b
    end

    def analisis dic
         isExpr(@expr,dic)
         if (!isNumber(@expr,dic))
               raise Expresion_number.new(tokenExpr(@expr))
        end
        analisis_lista_instrucciones(@inst,dic)
        #Debo analizar:
        #expresion sea un numero
        #lista de instrucciones
    end
    def print_ast (indent="")
        @inst.l.each do |a|
            a.print_ast(indent+" ") if a.respond_to? :print_ast
        end 
    end
end
class Condicional
    #expr, expresion cualquiera
    #inst, Lista_instruccion
    attr_accessor :expr, :inst1, :inst2 

    def initialize (a,b,c)
        @expr=a
        @inst1=b
        @inst2=c
    end

    def analisis dic
         isExpr(@expr,dic)
         if !isBool(@expr,dic)
                raise Expresion_booleana.new(tokenExpr(@expr))
        end
        analisis_lista_instrucciones(@inst1,dic)
        if @inst2!=nil
            analisis_lista_instrucciones(@inst2,dic)
        end
        #Debo analizar:
        #expr sea booleano
        #Lista de Instrucciones
    end
    def print_ast (indent="")
        @inst1.l.each do |a|
            a.print_ast(indent+" ") if a.respond_to? :print_ast
        end 
        if @inst2!=nil

            @inst2.l.each do |a|
                a.print_ast(indent+" ") if a.respond_to? :print_ast
            end 
        end
    end
end
class Llamado_funcion 
    #iden, identificador
    #expre, Lista_expresion
    attr_accessor :iden, :expre

    def initialize (a,b)
        @iden=a
        @expre=b
    end

    def analisis dic
        dic.isIn(@iden.digit.id,@iden.digit) #lo comente momentaneamente mientras se resuelven los raise
        a=dic.consulta(@iden.digit.id,@iden.digit)
        if a.class!=Hash
            raise No_funcion.new(@iden.digit.id,@iden.digit)
        end
        #puts a.class
        #puts @iden.digit.id
        i=0
        if @expre!= nil
            @expre.l.each do |f|
                i=i+1
            end
            if a['number']!=i
               raise Cantidad_parametros.new(@iden.digit.id, a['number'],i,@iden.digit)
            else


                a=a['args'].to_a
                i=0

                #puts a['args'].to_a[1][1]
                @expre.l.each do |f|
                    if a[i][1] == "number"
                        if !isNumber(f,dic)
                            raise Tipo_erroneo.new(@iden.digit.id,@iden.digit)
                        end
                    elsif a[i][1]=="boolean"
                        if !isBool(f,dic)
                            raise Tipo_erroneo.new(@iden.digit.id,@iden.digit)
                        end
                    end
                    i=i+1
                end
            end
        else 
            if a['number']!=0
                raise Cantidad_parametros.new(@iden.digit.id, a['number'],0,@iden.digit)
            end
        end

        #Debo analizar:
        #identificador definido como funcion
        #Expresion correspondiente a la cantidad de argumentos, y que cada argumento sea  como se definió en la declaracion
    end
end
class Lista_expresion
    #Contiene una lista de expresiones empleadas unicamente para hacer un llamado a funcion, 
    #requiere verificar que la cantidad corresponda a la cantidad de argumentos definidos por la funcion
    #que sea válida y que su tipo corresponda a los tipos de los argumentos de la funcion que la llama
    #Varias clases, tantas como expresiones
    attr_accessor :l
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else 
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
    def analisis dic
        @l.each do |f|
            isExpr(f,dic)
        end
    end
    #def initialize (a, b)
    #    @l=[]
    #    if (a.class==Lista_expresion)
    #        a.l.each do |f|
    #            @l.push f
    #        end
    #    else 
    #        @l.push a
    #    end
    #    @l.push b
    #end
end
class Salida
    #imp, Imprimible
    attr_accessor :imp

    def initialize d 
        @imp = d
    end

    def analisis dic
        @imp.analisis(dic)
        #Debo analizar:
        #Integridad de los imprimibles
    end
end
class Lista_imprimible
    #Expresion, string o llamado a funcion
    #Verificar correctitud de las expresiones, correctitud de la llamada a funcion
    attr_accessor :l
    def initialize (a, b)
        @l=[]
        if a==nil
            @l.push b
        else 
            a.l.each do |f|
                @l.push f
            end
            @l.push b
        end 
    end
    def analisis dic 
        @l.each do |f|
            if f.class==Llamado_funcion
                a=dic.consulta(f.iden.digit.id,f.iden.digit)
                if a['tipo']==nil
                    raise Mala_impresion.new(f.iden.digit.id,f.iden.digit)
                end
                f.analisis(dic)
            elsif f.class==String
            else 
                isExpr(f,dic)
            end 
        end              

                    
    end
end 
class String
    #str, creo que es un token str
    attr_accessor :str

    def initialize d 
        @str = d
    end
end
class Entrada
    #ident, Identificador
    attr_accessor :ident

    def initialize d 
        @ident = d
    end

    def analisis dic
        dic.isIn(@ident.digit.id,@ident.digit)
        #Debo verificar:
        #Creo que nada
    end
end
class Return
    #expre, expresion cualquiera
    attr_accessor :expr
    def initialize (a)
        @expr=a
    end

    def analisis dic
        if dic.funcion_actual()==nil
            raise No_retorno.new(tokenExpr(@expr))
        else
            a=dic.consulta(dic.funcion_actual(),nil)
            a['return']=true
            if a['tipo']==nil
                raise Mal_retorno.new(a['token'].digit.id,tokenExpr(@expr))#En caso de que no importe, solo hay que verificar aca que la
                #expresion sea correcta
            end
            if a['tipo']=='number'
                if !isNumber(@expr,dic)
                    raise Retorno_clase.new(a['token'].digit,a['tipo'],'boolean',tokenExpr(@expr))
                end
            elsif a['tipo']=='boolean'
                if !isBool(@expr,dic)
                    raise Retorno_clase.new(a['token'].digit,a['tipo'],'number',tokenExpr(@expr))
                end
            end
        end              
        #Debo verificar integridad de la expresion, que corresponda al tipo declarado por la funcion
    end
end
class Tipo
    #Internamente no verifica nada, externa mente si
    attr_accessor :digit
    def initialize d 
        @digit = d
    end
end

def analisis_lista_instrucciones(a, dic)
    a.l.each do |f|
        f.analisis(dic)
    end
end
def isNumber(expr,dic)
    if (expr.class==Or || expr.class==And || expr.class==Bminus || expr.class==Mayor || expr.class==Menor || expr.class==Mayorigual || expr.class==Menorigual || expr.class==Bool)
        return false
    elsif expr.class==Identificador
        dic.isIn(expr.digit.id, expr.digit)
        if dic.consulta(expr.digit.id,expr.digit)=="number"
            return true
        else
            return false
        end
    elsif expr.class==Number2
        return true            
    else
        return expr.isNumberC(dic)
    end
end
def isBool(expr,dic)
    if (expr.class==Or || expr.class==And || expr.class==Bminus || expr.class==Mayor || expr.class==Menor || expr.class==Mayorigual || expr.class==Menorigual || expr.class==Equivalencia || expr.class==Distinto)
        return expr.isBoolC(dic)
    elsif expr.class==Identificador
        dic.isIn(expr.digit.id,expr.digit)
        if dic.consulta(expr.digit.id,expr.digit)=="boolean"
            return true
        else
            return false
        end
    elsif expr.class==Bool
        return true            
    else
        return false
    end
end
def isInTablaSimbolos(id, dic)
    a=dic.has_key? id.id
    if a
        raise Error_declaracion.new(id)
    end
end

def isExpr(expr, dic)
    if ( !isNumber(expr,dic) && !isBool(expr,dic))
        raise Expresion_invalida.new(tokenExpr(expr))
    end
end

def tokenExpr(expr)
    return expr.tokenExprC()
    #if (expr.class!=Bool && expr.class!=Number2 && expr.class!=Identificador)
    #    return expr.tokenExprC()
    #else 
    #    return expr.digit
    #end
end
        
class AST
    def print_ast indent=""
        puts "#{indent}#{self.class}:"

        attrs.each do |a|
            a.print_ast indent + "  " if a.respond_to? :print_ast
        end
    end

    def attrs
        instance_variables.map do |a|
            instance_variable_get a
        end
    end
end
class Number2 < AST
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Numero: #{@digit.id}"
    end
    def tokenExprC
        return @digit
    end
end
class Bool < AST
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Booleano: #{@digit.id}"
    end
    def tokenExprC
        return @digit
    end
end
class ArithmeticUnOP < AST
    attr_accessor :operand

    def initialize operand
        @operand = operand
    end
    def tokenExprC
        return @operand.tokenExprC()
    end
end
class ArithmeticBinOP < AST
    attr_accessor :left, :right

    def initialize lh, rh
        @left = lh
        @right = rh
    end
    def tokenExprC
        return @left.tokenExprC()
    end
end
class Identificador
    attr_accessor :digit

    def initialize d 
        @digit = d
    end

    def print_ast indent=""
        puts "#{indent}Identificador:\n#{indent}  nombre: #{@digit.id}"
    end
    def tokenExprC
        return @digit
    end
end
class Suma < ArithmeticBinOP
    def isNumberC dic
        a=isNumber(@left,dic)
        b=isNumber(@right,dic)
        if a==true && b==true
            return true
        else
            return false
        end
    end
    def isBoolC dic
        return false
    end 
end
class Resta < Suma;end
class Multiplicacion < Suma;end
class Minus < ArithmeticUnOP
    def isNumberC dic
        if isNumber(@operand,dic)
            return true
        else
            return false
        end
    end
    def isBoolC dic
        return false
    end
end 
class Division < Suma;end
class Porcentaje < Suma;end
class Modulo < Suma;end 
class Div < Suma;end
class Mayor < ArithmeticBinOP
    def isBoolC dic
        a=isNumber(@left,dic)
        b=isNumber(@right,dic)
        if a==true && b==true
            return true
        else
            return false
        end
    end
    def isNumberC dic
        return false
    end 
end
class Menor < Mayor;end
class Mayorigual < Mayor;end 
class Menorigual < Mayor;end
class Distinto < ArithmeticBinOP
    def isNumberC dic
        return false
    end
    def isBoolC dic
        a=isBool(@left,dic)
        b=isBool(@right,dic)
        c=isNumber(@left,dic)
        d=isNumber(@right,dic)
        if (a && b) || (c && d)
            return true
        else
            return false
        end
    end
end
class Equivalencia < Distinto;end
class And < ArithmeticBinOP
    def isBoolC dic
        a=isBool(@left,dic)
        b=isBool(@right,dic)
        if a==true && b==true
            return true
        else
            return false
        end
    end
    def isNumberC dic
        return false
    end
end
class Or < And;end
#class Not < ArithmeticBinOP;end
class Bminus< ArithmeticUnOP
    def isBoolC dic
        if isBool(@operand,dic)
            return true
        else
            return false
        end
    end
    def isNumberC dic
        return false
    end
end