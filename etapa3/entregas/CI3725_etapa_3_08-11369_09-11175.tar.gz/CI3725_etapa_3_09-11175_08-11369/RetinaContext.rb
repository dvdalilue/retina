=begin
  Proyecto 3 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Table de simbolos
class RetinaSymTable
    attr_reader :variables, :tipoAlcance, :alcanceObject, :parent, :root, :subAlcances
    attr_accessor :nombreAlcance, :reserved


    def initialize(alcanceObject, parent = nil)

        # Nombre, tipo y referencia al nodo del alcance
        @nombreAlcance = ''
        @alcanceObject = alcanceObject
        @tipoAlcance = alcanceObject.tipoNodo.downcase
        @reserved = false

        # Nodos padre y root
        @parent = parent
        @root = parent ? parent.root : self;

        # Variables y subalcances
        @variables = Hash.new
        @subAlcances = Hash.new
    end


    # Agrega una variable a la tabla de simbolos
    def agregarVariable(variable)

        found, scopeFound = self.lookup(variable)
        if found
            tipoError = @tipoAlcance == 'funcion' ? 'parametroYaDefinido' : 'variableYaDefinida'
            raise RetinaContextException.new(tipoError, variable, {nombreVariable: variable.getNombre})
        end

        @variables[variable.getNombre] = variable
    end


    # Actualiza los datos de una variable en la tabla de simbolos
    def actualizarVariable(variableNueva)

        variableVieja, scopeVariableVieja = self.lookup(variableNueva)
        if !variableVieja
            raise RetinaContextException.new('variableNoDeclarada', variableNueva, {nombreVariable: variableNueva.getNombre})
        end

        # Actualiza la variable existente
        @variables[variableVieja.getNombre] = variableNueva
    end


    # Busca una variable en la tabla de simbolos
    # Si se indica, busca en los alcances de los padres
    def lookup(variable, global = nil)

        found = @variables[variable.getNombre]
        scopeFound = self

        if found.nil? && global && @parent
            found, scopeFound = @parent.lookup(variable, global)
        end

        [found, scopeFound]
    end


    # Agregar un nuevo sub-alcance a la tabla de simbolos
    def agregarSubAlcance(symTable)

        # Determina el nombre del alcance de acuerdo al tipo de nodo
        nombreAlcance = symTable.tipoAlcance
        case nombreAlcance
        when 'funcion'
            nombreAlcance += "-#{symTable.alcanceObject.getNombre()}"

        when 'bloque'
            numNuevoAlcance = self.countSubAlcancesPorTipo(nombreAlcance) + 1
            nombreAlcance += "-#{numNuevoAlcance}"

        when 'iteracion for'
            nombreAlcance = 'for'
            numNuevoAlcance = self.countSubAlcancesPorTipo(nombreAlcance) + 1
            nombreAlcance += "-#{numNuevoAlcance}"
        end

        symTable.nombreAlcance = nombreAlcance
        @subAlcances[nombreAlcance] = symTable
    end


    # Busca un sub-alcance de tipo funcion en la tabla de simbolos global
    def lookupFuncion(funcion)

        nombreFuncion = "funcion-"+ funcion.getNombre()
        found = @root.subAlcances[nombreFuncion]
    end


    # Permite contar los sub-alcances de un tipo especifico
    def countSubAlcancesPorTipo(tipoAlcance)

        count = 0
        @subAlcances.keys.each do |subAlcance|
            if subAlcance.include?(tipoAlcance)
                count += 1
            end
        end

        count
    end


    # Obtiene el primer superalcance conseguido para un cierto tipo especificado
    def getSuperAlcancePorTipo(tipo)

        i = 0
        alcance = self
        while alcance && alcance.tipoAlcance != tipo
            # puts "BBBB #{i} #{tipo} - #{alcance.nombreAlcance}"
            i = i +1
            alcance = alcance.parent
        end
        if alcance
            # puts "AAAA #{i} #{tipo} - #{alcance.nombreAlcance} #{alcance.tipoAlcance}"
        end

        alcance = alcance && alcance.tipoAlcance == tipo ? alcance : nil
        alcance
    end


    # Representacion en string de la tabla de simbolos
    def to_str(identacion = 0)

        str = ''
        if @parent.nil?
            # Caso nodo root

            num = 0
            @subAlcances.each do |nombre, subAlcance|
                num = num + 1
                if !subAlcance.nil? && !subAlcance.reserved
                    str += subAlcance.to_str(identacion)

                    # No se agrega salto de linea al ultimo sub-alcance
                    if num < @subAlcances.length
                        str += "\n"
                    end
                end
            end

        else
            # Caso resto del arbol

            if @reserved
                return
            end


            str += indent("Alcance #{@nombreAlcance}:", identacion)

            identacion += INDENT_DEFAULT
            indentacionNext = identacion + INDENT_DEFAULT

            variablesNum = @variables.length > 0 ? "" : "None"
            str += indent("Variables: "+ variablesNum, identacion)
            @variables.each do |nombre, variable|
                str += indent("#{variable.getNombre} : #{variable.tipoExpresion}", indentacionNext)
            end

            num = 0
            subAlcancesNum = @subAlcances.length > 0 ? "" : "None"
            str += indent("Sub-alcances: "+ subAlcancesNum, identacion)
            @subAlcances.each do |nombre, subAlcance|
                num = num + 1
                if !subAlcance.nil?
                    str += subAlcance.to_str(indentacionNext)

                    # No se agrega salto de linea al ultimo sub-alcance
                    if num < @subAlcances.length
                        str += "\n"
                    end
                end
            end
        end

        str
    end
end



# Excepcion del analizador de contexto
class RetinaContextException < RuntimeError

    def initialize(tipoError, elementoPosicion, datosMsj, lineaColumna = nil)
        @tipoError = tipoError
        @elementoPosicion = elementoPosicion
        @datosMsj = datosMsj
        @lineaColumna = lineaColumna.nil? ? @elementoPosicion.getLineaColumna : lineaColumna
    end

    def to_s

        # Obtiene los numeros de linea y columna
        linea, columna = @lineaColumna


        # Determina el mensaje segun el tipo de error
        str = "\nError: "
        case @tipoError
        when 'variableYaDefinida'
            str += "la variable '%<nombreVariable>s' ya se encuentra definida"

        when 'parametroYaDefinido'
            str += "el parámetro '%<nombreVariable>s' ya se encuentra definido"

        when 'variableNoDeclarada'
            str += "la variable '%<nombreVariable>s' no ha sido declarada"

        when 'variableNoInicializada'
            str += "la variable '%<nombreVariable>s' no ha sido inicializada"

        when 'funcionNoDeclarada'
            str += "la función '%<nombreFuncion>s' no ha sido declarada"

        when 'expresionTipoInvalido'
            if @elementoPosicion.class.name == 'ArbolLiteralDeCadenaDeCaracteres'
                str += "la expresión %<expresion>s es una cadena de caracteres pero se esperaba una "
                str += "expresión de tipo '%<tipoEsperado>s'"
            else
                str += "la expresión '%<expresion>s' es de tipo '%<tipoEncontrado>s', pero se esperaba '%<tipoEsperado>s'"
            end

        when 'llamadaFuncionTipoInvalido'
            str += "la funcion '%<nombreFuncion>s' retorna una expresion de tipo '%<tipoEncontrado>s', "
            str += "pero se esperaba una expresión de tipo '%<tipoEsperado>s'"

        when 'llamadaFuncionTipoNulo'
            str += "la funcion '%<nombreFuncion>s' no retorna expresion alguna, pero se esperaba una "
            str += "expresión de tipo '%<tipoEsperado>s'"

        when 'llamadaFuncionNumArgsInvalido'
            parametrosLabel = @datosMsj[:numParametros] == 1 ? "parámetro" : "parámetros"
            argumentosLabel = @datosMsj[:numArgumentos] == 1 ? "argumento" : "argumentos"
            envioLabel = @datosMsj[:numArgumentos] == 1 ? "fue enviado" : "fueron enviados"
            str += "la función '%<nombreFuncion>s' tiene en su firma '%<numParametros>s' #{parametrosLabel}, pero #{envioLabel} "
            str += "'%<numArgumentos>s' #{argumentosLabel}"

        when 'llamadaFuncionTipoParametroInvalido'
            str += "el argumento #%<numeroArg>s pasado a la función '%<nombreFuncion>s' es de tipo '%<tipoEncontrado>s', "
            str += "pero se esperaba '%<tipoEsperado>s'"

        when 'llamadaFuncionExpresionLibre'
            str += "la funcion '%<nombreFuncion>s', que devuelve una expresion de tipo '%<tipoRetorno>s', no puede "
            str += "ser una expresion libre"

        when 'returnFueraDeFuncion'
            str += "la instrucción 'return' se encuentra declarada fuera de una función"

        when 'funcionReturnTipoInvalida'
            str += "la instrucción 'return' tiene una expresión de tipo '%<tipoEncontrado>s', pero la función '%<nombreFuncion>s' "
            str += "tiene definido tipo de retorno '%<tipoEsperado>s'"

        when 'funcionRequiereReturn'
            str += "la función '%<nombreFuncion>s' tiene definido un tipo de retorno '%<tipo>s', pero no se definió una "
            str += "instrucción 'return'"

        when 'funcionNoTieneTipoRetorno'
            str += "se encontro una instrucción 'return', pero la función '%<nombreFuncion>s' no tiene definido un tipo de retorno"

        end

        # Formatea el mensaje segun los datos adecuados
        str = str % @datosMsj

        # Incluye linea y columna
        if !linea.nil? and !columna.nil?
            str += " [lin: #{linea}, col: #{columna}]"
        end

        str
    end
end
