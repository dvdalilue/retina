=begin
  Proyecto 3 - Traductores e Interpretadores

  Elaborado por:

  -Vanessa Perez. 09-11175
  -Iranid Perez. 08-11369

=end


# Identacion default
INDENT_DEFAULT = 2


# Identa un string la cantidad de espacios indicado
def indent(str, pad = INDENT_DEFAULT)
    str.to_s.rjust(str.to_s.length + pad, ' ') + "\n"
end


# Construye la excepcion de tipo invalido segun los tipos de nodos y expresiones indicadas
def raiseErrorExpresionTipoInvalido(expresionBase, expresionChequeo, elementoPosicion)

    # Construcciones para poder hacer las comparaciones de tipos
    nodoBoolean = ArbolExpresionBooleana.new(TkBoolean.new(0, 0, BOOLEAN))
    nodoNumber = ArbolLiteralNumerico.new(TkNumber.new(0, 0, NUMBER))
    case expresionBase
        when BOOLEAN
            expresionBase = nodoBoolean
        when NUMBER
            expresionBase = nodoNumber
    end

    case expresionChequeo
        when BOOLEAN
            expresionChequeo = nodoBoolean
        when NUMBER
            expresionChequeo = nodoNumber
    end


    if expresionChequeo.class.name == 'ArbolFuncionLlamada'
        # Caso llamada funcion

        if expresionChequeo.getTipo().nil?
            raise RetinaContextException.new('llamadaFuncionTipoNulo', elementoPosicion,
                {nombreFuncion: expresionChequeo.getNombre(), tipoEncontrado: expresionChequeo.getTipo(),
                    tipoEsperado: expresionBase.getTipo()})
        else
            raise RetinaContextException.new('llamadaFuncionTipoInvalido', elementoPosicion,
                {nombreFuncion: expresionChequeo.getNombre(), tipoEncontrado: expresionChequeo.getTipo(),
                    tipoEsperado: expresionBase.getTipo()})
        end

    else
        # Caso default: cualquier otra expresion
        raise RetinaContextException.new('expresionTipoInvalido', elementoPosicion,
            {expresion: expresionChequeo.toCode(), tipoEncontrado: expresionChequeo.getTipo(), tipoEsperado: expresionBase.getTipo()})
    end

end



# Nodos del arbol sintactico abstracto
class RetinaASTNode
    attr_reader :tipoNodo


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable = nil)

        # No continua si esta marcado para no chequearse
        if @noCheck
            return
        end

        # Si se indica, genera un nuevo scope local
        if @localScope
            @symTable = RetinaSymTable.new(self, parentSymTable)

            # Agrega el programa como subalcance de su padre
            parentSymTable.agregarSubAlcance(@symTable)

            parentSymTable = @symTable
        end

        # Chequeo de cada atributo definido
        getAttributes().each do |attributeName, attribute|

            if attribute.nil?
                next
            end

            attribute.check(parentSymTable)
        end
    end


    # Obtiene el nombre del nodo
    def getNombre
        ''
    end


    # Obtiene la linea y columna asociados al nodo
    def getLineaColumna

        lineaColumna = [0, 0]
        if @tokenInicio
            lineaColumna = [@tokenInicio.linea, @tokenInicio.columna]
        end

        lineaColumna
    end


    # Representacion en string del nodo
    def printAST(identacion = 0)

        # Primera parte del arbol: nombre
        str = @tipoNodo +":"
        if !@linea.nil?
            str += " (linea: #{@linea})"
        end
        str = indent(str, identacion)

        identacion += INDENT_DEFAULT
        indentacionNext = identacion + INDENT_DEFAULT

        # Segunda parte del arbol: atributos
        getAttributes().each do |attributeName, attribute|

            if attribute.nil?
                next
            end

            # Separa en espacios
            attributeName = attributeName.gsub(/(?=[A-Z])/, ' ').strip.downcase
            str += indent("#{attributeName}:", identacion)
            str += attribute.printAST(indentacionNext)
        end

        str
    end


    # Obtiene los atributos de la instancia del nodo
    # Excluye algunos que son de utilidad para metadata
    def getAttributes
        excludeList = ['tipoNodo', 'tokenInicio', 'operador', 'parentesis', 'tipoExpresion', 'tipoOperandoEsperado',
            'symTable', 'globalScope', 'localScope', 'noCheck', 'tieneInstruccionReturn', 'tipoLlamadaFuncion']

        list = []
        instance_variables.map do |attribute|
            # Saca el "@" del nombre del atributo
            attributeName = attribute.to_s[1..-1]

            if !excludeList.include?(attributeName)
                list.push([attributeName, instance_variable_get(attribute)])
            end
        end

        list
    end
end



# Root del Arbol sintactico abstracto
class RetinaAST < RetinaASTNode
    attr_reader :symTable

    def initialize(funciones, program)
        @tipoNodo = "RetinaAST"
        @globalScope = true

        @funciones = funciones
        @program = program
    end


    # Realiza los chequeos estaticos y de contexto
    def check

        # Tabla de simbolos del scope global
        @symTable = RetinaSymTable.new(self)

        # Agrega funciones de movimiento al scope global
        self.agregarFuncionesMovimiento()


        # Chequeo funciones
        if @funciones
            @funciones.check(@symTable)
        end

        # Chequeo programa
        @program.check(@symTable)
    end


    # Agrega funciones de movimiento al scope global
    # Utiliza las herramientas provistas por el lexer y parser
    # para poder normalizar los chequeos estaticos
    def agregarFuncionesMovimiento

        # Definicion de funciones de movimiento
        tokenInicio = TkFunc.new(0, 0, 'func')
        parametros1 = ArbolFuncionParams.new(ArbolTipo.new(TkNumber.new(0, 0, NUMBER)), TkIdentificador.new(0, 0, 'num1'))
        parametros2 = ArbolFuncionParams.new(ArbolTipo.new(TkNumber.new(0, 0, NUMBER)), TkIdentificador.new(0, 0, 'num1'),
                        ArbolFuncionParams.new(ArbolTipo.new(TkNumber.new(0, 0, NUMBER)), TkIdentificador.new(0, 0, 'num2')))

        home = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'home'), nil, nil, nil)
        openeye = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'openeye'), nil, nil, nil)
        closeeye = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'closeeye'), nil, nil, nil)
        forward = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'forward'), parametros1, nil, nil)
        backward = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'backward'), parametros1, nil, nil)
        rotatel = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'rotatel'), parametros1, nil, nil)
        rotater = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'rotater'), parametros1, nil, nil)
        setposition = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'setposition'), parametros2, nil, nil)
        arc = ArbolFuncion.new(tokenInicio, TkIdentificador.new(0, 0, 'arc'), parametros2, nil, nil)

        # Verifica cada funcion y la agrega a la tabla de simbolos global
        listaFunciones = [home, openeye, closeeye, forward, backward, rotatel, rotater, setposition, arc]
        listaFunciones.each do |funcion|
            funcion.check(@symTable, true)
        end

    end
end


# Arbol de las reglas FUNCIONES
class ArbolFuncionList < RetinaASTNode

    def initialize(funcion, funcionList = nil)
        @funcion = funcion
        @funcionList = funcionList
    end


    def printAST(identacion)

        str = @funcion.printAST(identacion)

        if @funcionList
            str += @funcionList.printAST(identacion)
        end

        str
    end

end



# Arbol de las reglas FUNCION
class ArbolFuncion < RetinaASTNode
    attr_reader :parametros, :tipoRetorno
    attr_accessor :tieneInstruccionReturn

    def initialize(tokenInicio, identificador, parametros, tipoRetorno, instrucciones)
        @tipoNodo = "FUNCION"
        @localScope = true
        @tokenInicio = tokenInicio
        @tieneInstruccionReturn = nil

        @identificador = ArbolIdentificador.new(identificador)
        @parametros = parametros
        @tipoRetorno = tipoRetorno
        @instrucciones = instrucciones
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable, reserved = nil)

        # Chequea que no exista una funcion con el mismo nombre
        if parentSymTable.lookupFuncion(self)
            raise RetinaContextException.new('funcionYaDefinida', self, {nombreFuncion: @identificador.getNombre})
        end

        # Nuevo scope, nueva tabla de simbolos
        @symTable = RetinaSymTable.new(self, parentSymTable)

        # Si es una funcion reservada, no debe ser posible imprimirla en el arbol
        if reserved
            @symTable.reserved = true
        end

        # Agrega la funcion como subalcance de root
        parentSymTable.agregarSubAlcance(@symTable)

        # Verifica los parametros
        if @parametros
            @parametros.check(@symTable)
        end

        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(@symTable)
        end

        # Si existe tipo de retorno, verifica que exista
        # al menos una instruccion return
        if @tipoRetorno && !@tieneInstruccionReturn
            raise RetinaContextException.new('funcionRequiereReturn', self,
                {nombreFuncion: self.getNombre(), tipo: @tipoRetorno.getNombre()})
        end
    end


    # Obtiene el nombre de la funcion
    def getNombre
        @identificador.getNombre
    end


    # Obtiene el numero de parametros de la funcion
    def getNumeroParametros

        numParams = 0
        if @parametros

            param = @parametros
            while param
                param = param.funcionParams
                numParams = numParams + 1
            end
        end

        numParams
    end


    # Permite indicar que la funcion tiene una instruccion
    # return definida en su alcance
    def setTieneInstruccionReturn
        @tieneInstruccionReturn = true
    end
end


# Arbol de las reglas FUNCION_PARAMS
class ArbolFuncionParams < RetinaASTNode
    attr_reader :funcionParams

    def initialize(tipo, identificador, funcionParams = nil)
        @tipoNodo = "PARAMETRO"

        @tipo = tipo
        @identificador = ArbolIdentificador.new(identificador)
        @funcionParams = funcionParams
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable)

        # Agrega el parametro como variable
        @identificador.tipoExpresion = @tipo.nombre
        parentSymTable.agregarVariable(@identificador)

        if @funcionParams
            @funcionParams.check(parentSymTable)
        end
    end


    # Obtiene el tipo del parametro
    def getTipo
        @tipo.getNombre
    end


    def printAST(identacion)

        str = indent("#{@tipoNodo}:", identacion)
        identacionParametro = identacion + INDENT_DEFAULT
        indentacionNext = identacionParametro + INDENT_DEFAULT

        str += indent("tipo:", identacionParametro)
        str += @tipo.printAST(indentacionNext)

        str += indent("nombre:", identacionParametro)
        str += @identificador.printAST(indentacionNext)

        if @funcionParams
            str += @funcionParams.printAST(identacion)
        end

        str
    end

end


# Arbol de las reglas FUNCION_RETURN
class ArbolFuncionReturn < RetinaASTNode
    attr_accessor :expresion

    def initialize(tokenInicio, expresion)
        @tipoNodo = "RETORNO FUNCION"
        @expresion = expresion
        @tokenInicio = tokenInicio
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable)

        # Identifica la funcion a la cual pertenece el return
        funcionAlcance = parentSymTable.getSuperAlcancePorTipo('funcion')
        if funcionAlcance.nil?
            raise RetinaContextException.new('returnFueraDeFuncion', self, {})
        end
        funcion = funcionAlcance.alcanceObject


        # Verifica la funcion tenga tipo de retorno
        if funcion.tipoRetorno.nil?
            raise RetinaContextException.new('funcionNoTieneTipoRetorno', self, {nombreFuncion: funcion.getNombre()})
        end


        # Verifica la expresion sea correcta y sea del tipo de retorno de la funcion
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != funcion.tipoRetorno.nombre
            raise RetinaContextException.new('funcionReturnTipoInvalida', @expresion, {tipoEncontrado: @expresion.getTipo(),
                nombreFuncion: funcion.getNombre(), tipoEsperado: funcion.tipoRetorno.nombre})
        end

        # Actualiza la funcion, indicando que existe una instruccion return en su interior
        funcion.setTieneInstruccionReturn()
    end
end


# Arbol de las reglas PROGRAM
class ArbolProgram < RetinaASTNode

    def initialize(instrucciones)
        @tipoNodo = "PROGRAM"
        @localScope = true

        @instrucciones = instrucciones
    end

    def printAST(identacion)
        indentacionNext = identacion + INDENT_DEFAULT

        str = indent("instrucciones:", identacion)
        if @instrucciones
            str += @instrucciones.printAST(indentacionNext)
        else
            str += indent("None", indentacionNext)
        end

        str
    end
end


# Arbol de las reglas BLOQUE
class ArbolBloque < RetinaASTNode

    def initialize(declaraciones, instrucciones)
        @tipoNodo = "BLOQUE"
        @localScope = true

        @declaraciones = declaraciones
        @instrucciones = instrucciones
    end
end


# Arbol de las reglas DECLARACIONES
class ArbolBloqueDeclaraciones < RetinaASTNode

    def initialize(declaracion, declaracionList = nil)
        @declaracion = declaracion
        @declaracionList = declaracionList
    end


    def printAST(identacion)
        str = @declaracion.printAST(identacion)

        if @declaracionList
            str += @declaracionList.printAST(identacion)
        end

        str
    end
end


# Arbol de las reglas DECLARACION
class ArbolDeclaracion < RetinaASTNode

    def initialize(tipo, identificadores, expresionInicializacion = nil)
        @tipoNodo = "DECLARACION"
        @tipo = tipo

        if identificadores.class.name == "TkIdentificador"
            @identificador = ArbolIdentificador.new(identificadores)
        else
            @identificadores = identificadores
        end

        @inicializacion = expresionInicializacion
    end


    def check(parentSymTable)

        if @identificador
            # Caso un solo identificador

            # Verifica primero la inicializacion
            @inicializacion.check(parentSymTable)

            # Agrega la variable
            @identificador.tipoExpresion = @tipo.nombre
            parentSymTable.agregarVariable(@identificador)

            # Verifica que ambos lados tengan el mismo tipo
            if @identificador.getTipo() != @inicializacion.getTipo()
                raiseErrorExpresionTipoInvalido(@identificador, @inicializacion, @inicializacion)
            end

        else
            # Caso varios identificadores en una misma linea
            @identificadores.tipo = @tipo
            @identificadores.check(parentSymTable)
        end
    end

end


# Arbol de las reglas DECLARACION_IDENTIFICADORES
class ArbolDeclaracionIdentificadores < RetinaASTNode
    attr_accessor :tipo

    def initialize(identificador, listaIdentificadores = nil)
        @tipo = nil
        @identificador = ArbolIdentificador.new(identificador)
        @listaIdentificadores = listaIdentificadores
    end


    def check(parentSymTable)

        # Agrega la variable del bloque
        @identificador.tipoExpresion = @tipo.nombre
        parentSymTable.agregarVariable(@identificador)

        if @listaIdentificadores
            @listaIdentificadores.tipo = @tipo
            @listaIdentificadores.check(parentSymTable)
        end
    end

    def printAST(identacion)
        str = @identificador.printAST(identacion)

        if @listaIdentificadores
            str += @listaIdentificadores.printAST(identacion)
        end

        str
    end

end



# Arbol de las reglas INSTRUCCIONES
class ArbolInstrucciones < RetinaASTNode

    def initialize(instruccion, instruccionList = nil)
        @instruccion = instruccion
        @instruccionList = instruccionList
    end


    def check(parentSymTable)

        if @instruccion

            if @instruccion.class.name == 'ArbolFuncionLlamada'
                # Caso especial llamada a funcion
                @instruccion.check(parentSymTable, self)
            else
                # Caso default: cualquier otra instruccion
                @instruccion.check(parentSymTable)
            end
        end

        if @instruccionList
            @instruccionList.check(parentSymTable)
        end
    end


    def printAST(identacion)

        str = ''
        if @instruccion
            str += @instruccion.printAST(identacion)
        end

        if @instruccionList
            str += @instruccionList.printAST(identacion)
        end

        str
    end

end




# Arbol de las reglas ASIGNACION
class ArbolAsignacion < RetinaASTNode

    def initialize(identificador, expresion)
        @tipoNodo = "ASIGNACION"

        @ladoIzquierdo = ArbolIdentificador.new(identificador)
        @ladoDerecho = expresion
    end


    # Realiza los chequeos estaticos y de contexto
    def check(parentSymTable)

        # Verifica la variable este declarada y la expresion sea valida
        @ladoIzquierdo.check(parentSymTable)
        @ladoDerecho.check(parentSymTable)

        # Verifica que la variable y la expresion tengan el mismo tipo
        if @ladoIzquierdo.getTipo() != @ladoDerecho.getTipo()
            raiseErrorExpresionTipoInvalido(@ladoIzquierdo, @ladoDerecho, @ladoDerecho)
        end
    end

end


# Arbol de las reglas ENTRADA
class ArbolEntrada < RetinaASTNode

    def initialize(identificador)
        @tipoNodo = "ENTRADA"
        @identificador = ArbolIdentificador.new(identificador)
    end

end


# Arbol de las reglas SALIDA
class ArbolSalida < RetinaASTNode

    def initialize(expresiones, salto = nil)
        @tipoNodo = 'SALIDA'
        if salto
            @tipoNodo = 'SALIDA CON SALTO'
        end
        @expresiones = expresiones
    end


    def check(parentSymTable)

        if @expresiones.class.name == 'ArbolFuncionLlamada'
            # Caso especial llamada a funcion
            @expresiones.check(parentSymTable, self)
        else
            # Caso default: cualquier otra instruccion
            @expresiones.check(parentSymTable)
        end
    end
end



# Arbol de las reglas SALIDA_EXPR
class ArbolSalidaExpresiones < RetinaASTNode

    def initialize(expresion, expresiones = nil)
        @expresion = expresion
        @expresiones = expresiones
    end


    def check(parentSymTable)

        if @expresion.class.name == 'ArbolFuncionLlamada'
            # Caso especial llamada a funcion
            @expresion.check(parentSymTable, self)
        else
            # Caso default: cualquier otra instruccion
            @expresion.check(parentSymTable)
        end

        # Chequea el resto de expresiones
        if @expresiones
            @expresiones.check(parentSymTable)
        end
    end


    def printAST(identacion)

        str = @expresion.printAST(identacion)

        if @expresiones
            str += @expresiones.printAST(identacion)
        end

        str
    end

end


# Arbol de las reglas CONDICIONALES
class ArbolIf < RetinaASTNode

    def initialize(expresion, instruccionesThen, instruccionesElse = nil)
        @tipoNodo = "CONDICIONAL"
        @expresion = expresion
        @instruccionesThen = instruccionesThen
        @instruccionesElse = instruccionesElse
    end


    def check(parentSymTable)

        # Verifica la expresion sea valida y sea de tipo booleano
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != BOOLEAN
            raiseErrorExpresionTipoInvalido(BOOLEAN, @expresion, @expresion)
        end

        # Verifica las instrucciones
        if @instruccionesThen
            @instruccionesThen.check(parentSymTable)
        end
        if @instruccionesElse
            @instruccionesElse.check(parentSymTable)
        end
    end

end



# Arbol de las reglas ITERACION_WHILE
class ArbolWhile < RetinaASTNode

    def initialize(expresion, instrucciones)
        @tipoNodo = "ITERACION WHILE"
        @expresion = expresion
        @instrucciones = instrucciones
    end


    def check(parentSymTable)

        # Verifica la expresion sea valida y sea de tipo booleano
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != BOOLEAN
            raiseErrorExpresionTipoInvalido(BOOLEAN, @expresion, @expresion)
        end

        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(parentSymTable)
        end
    end

end


# Arbol de las reglas ITERACION_FOR
class ArbolFor < RetinaASTNode

    def initialize(identificador, from, to, by, instrucciones)
        @tipoNodo = "ITERACION FOR"
        @localScope = true

        @identificador = ArbolIdentificador.new(identificador)
        @expresionFrom = from
        @expresionTo = to
        @expresionBy = by
        @instrucciones = instrucciones
    end


    def check(parentSymTable)

        # Nuevo scope, nueva tabla de simbolos
        @symTable = RetinaSymTable.new(self, parentSymTable)

        # Agrega la funcion como subalcance del padre
        parentSymTable.agregarSubAlcance(@symTable)


        # Agrega la variable de inicializacion del for
        @identificador.tipoExpresion = NUMBER
        @symTable.agregarVariable(@identificador)


        # Verifica la expresion 'from' sea valida y de tipo number
        @expresionFrom.check(parentSymTable)
        if @expresionFrom.getTipo() != NUMBER
            raiseErrorExpresionTipoInvalido(NUMBER, @expresionFrom, @expresionFrom)
        end

        # Verifica la expresion 'to' sea valida y de tipo number
        @expresionTo.check(parentSymTable)
        if @expresionTo.getTipo() != NUMBER
            raiseErrorExpresionTipoInvalido(NUMBER, @expresionTo, @expresionTo)
        end

        # Verifica la expresion 'by' sea valida y de tipo number
        if @expresionBy
            @expresionBy.check(parentSymTable)
            if @expresionBy.getTipo() != NUMBER
                raiseErrorExpresionTipoInvalido(NUMBER, @expresionBy, @expresionBy)
            end
        end


        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(@symTable)
        end
    end
end



# Arbol de las reglas ITERACION_REPEAT
class ArbolRepeat < RetinaASTNode

    def initialize(expresion, instrucciones)
        @tipoNodo = "REPEAT"
        @expresion = expresion
        @instrucciones = instrucciones
    end


    def check(parentSymTable)

        # Verifica la expresion sea valida y sea de tipo booleano
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != NUMBER
            raiseErrorExpresionTipoInvalido(NUMBER, @expresion, @expresion)
        end

        # Verifica las instrucciones
        if @instrucciones
            @instrucciones.check(parentSymTable)
        end
    end

end



# Arbol de las reglas FUNCION
class ArbolFuncionLlamada < RetinaASTNode
    attr_accessor :parentesis

    def initialize(identificador, argumentos = nil)
        @tipoNodo = "LLAMADA FUNCION"
        @parentesis = false
        @tipoLlamadaFuncion = nil

        @identificador = ArbolIdentificador.new(identificador)
        @argumentos = argumentos
    end


    def check(parentSymTable, parentCheck = nil)

        # Chequea que exista la funcion
        funcionAlcance = parentSymTable.lookupFuncion(@identificador)
        if funcionAlcance.nil?
            raise RetinaContextException.new('funcionNoDeclarada', @identificador, {nombreFuncion: @identificador.getNombre})
        end
        funcion = funcionAlcance.alcanceObject

        # Verifica que el numero de argumentos concuerde con el numero
        # de parametros de la funcion llamada
        numArgumentos = self.getNumeroArgumentos()
        numParametros = funcion.getNumeroParametros()
        if numArgumentos != numParametros
            raise RetinaContextException.new('llamadaFuncionNumArgsInvalido', @identificador,
                    {nombreFuncion: @identificador.getNombre, numParametros: numParametros, numArgumentos: numArgumentos})
        end

        # Verifica los argumentos
        if @argumentos
            @argumentos.check(parentSymTable, funcion.getNombre, funcion.parametros, 1)
        end

        # Si la funcion retorna un tipo, la llamada es una expresion de dicho tipo
        if funcion.tipoRetorno
            @tipoLlamadaFuncion = funcion.tipoRetorno.getNombre
        end

        # Si la llamada es una instruccion, se comportaria como expresion libre
        # si devuelve un tipo, por lo que debe mostrarse error
        if parentCheck.class.name == 'ArbolInstrucciones' && @tipoLlamadaFuncion
            raise RetinaContextException.new('llamadaFuncionExpresionLibre', @identificador,
                    {nombreFuncion: @identificador.getNombre, tipoRetorno: @tipoLlamadaFuncion})
        end

        # Si la llamada se hace en un write o writeln y la funcion no devuelve
        # expresion alguna, debe mostrarse error
        if ['ArbolSalida', 'ArbolSalidaExpresiones'].include?(parentCheck.class.name) && @tipoLlamadaFuncion.nil?
            raise RetinaContextException.new('llamadaFuncionTipoNulo', @identificador,
                {nombreFuncion: @identificador.getNombre, tipoEsperado: "#{NUMBER}' o '#{BOOLEAN}"})
        end
    end


    # Obtiene el nombre de la funcion llamada
    def getNombre
        @identificador.getNombre
    end


    # Obtiene el tipo de expresion que representa la llamada
    def getTipo
        @tipoLlamadaFuncion
    end


    # Obtiene la linea y columna del comienzo de la llamada
    def getLineaColumna
        @identificador.getLineaColumna
    end


    # Obtiene el numero de argumentos de la llamada a la funcion
    def getNumeroArgumentos

        numArgs = 0
        if @argumentos

            argumento = @argumentos
            while argumento
                argumento = argumento.funcionArgs
                numArgs = numArgs + 1
            end
        end

        numArgs
    end


    # Obtiene la representacion en codigo
    def toCode
        str = "#{self.getNombre}("
        if @argumentos
            str += @argumentos.toCode
        end
        str += ')'
    end

end


# Arbol de las reglas FUNCION_LLAMADA_ARGS
class ArbolFuncionLlamadaArgs < RetinaASTNode
    attr_reader :funcionArgs

    def initialize(expresion, funcionArgs = nil)
        @expresion = expresion
        @funcionArgs = funcionArgs
    end


    def check(parentSymTable, funcionNombre, funcionParametro, numArg)

        # Verifica la expresion del argumento sea valido y sea del tipo esperado
        # de acuerdo al orden de los parametros de la funcion
        @expresion.check(parentSymTable)
        if @expresion.getTipo() != funcionParametro.getTipo()
            raise RetinaContextException.new('llamadaFuncionTipoParametroInvalido', @expresion,
                {numeroArg: numArg, nombreFuncion: funcionNombre, tipoEncontrado: @expresion.getTipo(),
                    tipoEsperado: funcionParametro.getTipo()})
        end

        # Verifica el resto de argumentos
        if @funcionArgs && funcionParametro
            @funcionArgs.check(parentSymTable, funcionNombre, funcionParametro.funcionParams, numArg + 1)
        end
    end


    # Obtiene la representacion en codigo
    def toCode
        str = "#{@expresion.toCode}"
        if @funcionArgs
            str += ", #{@funcionArgs.toCode}"
        end
        str
    end


    def printAST(identacion)

        if @expresion.nil?
            return ''
        end

        str = indent("ARGUMENTO:", identacion)
        str += @expresion.printAST(identacion + INDENT_DEFAULT)

        if @funcionArgs
            str += @funcionArgs.printAST(identacion)
        end

        str
    end

end


# Arbol de las reglas TIPO
class ArbolTipo < RetinaASTNode
    attr_reader :nombre

    def initialize(nombre)
        @noCheck = true

        @nombre = nombre.valor
    end


    def getNombre
        @nombre
    end


    def printAST(identacion)
        str = indent("TIPO:", identacion)
        str += indent("nombre: "+ @nombre, identacion + INDENT_DEFAULT)
    end

end


# Arbol de las reglas EXPR con operadores unarios
class ArbolOperadorUnario < RetinaASTNode
    attr_reader :expresion, :tipoOperandoEsperado
    attr_accessor :parentesis

    def initialize(operador, expresion)
        @operador = operador
        @expresion = expresion

        @tipoOperandoEsperado = nil
        @tipoExpresion = nil
        @parentesis = false

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @tipoNodo = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    def check(parentSymTable)

        # Chequea que la expresion sea valida
        @expresion.check(parentSymTable)

        # Determina que la expresion sea del tipo esperado
        if @expresion.getTipo() != @tipoOperandoEsperado
            raiseErrorExpresionTipoInvalido(@tipoOperandoEsperado, @expresion, @expresion)
        end
    end


    # Obtiene el tipo de la expresion
    def getTipo
        @tipoExpresion
    end


    # Obtiene la linea y columna del comienzo de la expresion
    def getLineaColumna
        [@operador.linea, @operador.columna]
    end


    # Representacion en codigo de la expresion
    def toCode
        str = "#{@operador.valor} #{@expresion.toCode()}"
        if @parentesis
            str = "(#{str})"
        end
        str
    end

end


# Arboles de expresiones con operadores unarios
class ArbolNot < ArbolOperadorUnario

    def initialize(operador, expresion)
        super
        @tipoOperandoEsperado = BOOLEAN
        @tipoExpresion = BOOLEAN
    end

end


class ArbolMenosUnario < ArbolOperadorUnario

    def initialize(operador, expresion)
        super
        @tipoOperandoEsperado = NUMBER
        @tipoExpresion = NUMBER
    end

end



# Arbol de las reglas EXPR con operadores binarios
class ArbolOperadorBinario < RetinaASTNode
    attr_reader :expresion, :tipoOperandoEsperado
    attr_accessor :parentesis

    def initialize(expresionIzquierda, operador, expresionDerecha)
        @operador = operador
        @ladoIzquierdo = expresionIzquierda
        @ladoDerecho = expresionDerecha

        @tipoOperandoEsperado = nil
        @tipoExpresion = nil
        @parentesis = false

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @tipoNodo = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    def check(parentSymTable)

        # Chequea que las dos expresiones sean validas
        @ladoIzquierdo.check(parentSymTable)
        @ladoDerecho.check(parentSymTable)

        # Chequeo de tipos
        if ['ArbolIgual', 'ArbolDesigual'].include?(self.class.name)
            # Operadores igual y desigual pueden ser BOOLEAN y NUMBER

            # Determina que las expresiones sean del mismo tipo
            if @ladoIzquierdo.getTipo() != @ladoDerecho.getTipo()
                raiseErrorExpresionTipoInvalido(@ladoIzquierdo, @ladoDerecho, @ladoDerecho)
            end

        else

            # Determina que las expresiones sean del tipo esperado
            if @ladoIzquierdo.getTipo() != @tipoOperandoEsperado
                raiseErrorExpresionTipoInvalido(@tipoOperandoEsperado, @ladoIzquierdo, @ladoIzquierdo)
            end

            if @ladoDerecho.getTipo() != @tipoOperandoEsperado
                raiseErrorExpresionTipoInvalido(@tipoOperandoEsperado, @ladoDerecho, @ladoDerecho)
            end
        end

    end

    # Obtiene el tipo de la expresion
    def getTipo
        @tipoExpresion
    end


    # Obtiene la linea y columna del comienzo de la expresion
    def getLineaColumna
        @ladoIzquierdo.getLineaColumna()
    end


    # Representacion en codigo de la expresion
    def toCode
        str = "#{@ladoIzquierdo.toCode()} #{@operador.valor} #{@ladoDerecho.toCode()}"
        if @parentesis
            str = "(#{str})"
        end
        str
    end

end

# Arboles de expresiones con operadores binarios
class ArbolOperadorBinarioComparacion < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoOperandoEsperado = NUMBER
        @tipoExpresion = BOOLEAN
    end
end

class ArbolOperadorBinarioLogico < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoOperandoEsperado = BOOLEAN
        @tipoExpresion = BOOLEAN
    end
end

class ArbolOperadorBinarioAritmetico < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoOperandoEsperado = NUMBER
        @tipoExpresion = NUMBER
    end
end


class ArbolIgual < ArbolOperadorBinario;

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoExpresion = BOOLEAN
    end
end

class ArbolDesigual < ArbolOperadorBinario

    def initialize(expresionIzquierda, operador, expresionDerecha)
        super
        @tipoExpresion = BOOLEAN
    end
end

class ArbolMayorOIgualQue < ArbolOperadorBinarioComparacion;end
class ArbolMenorOIgualQue < ArbolOperadorBinarioComparacion;end
class ArbolMayorQue < ArbolOperadorBinarioComparacion;end
class ArbolMenorQue < ArbolOperadorBinarioComparacion;end
class ArbolAnd < ArbolOperadorBinarioLogico;end
class ArbolOr < ArbolOperadorBinarioLogico;end
class ArbolProducto < ArbolOperadorBinarioAritmetico;end
class ArbolDivisionExacta < ArbolOperadorBinarioAritmetico;end
class ArbolRestoExacto < ArbolOperadorBinarioAritmetico;end
class ArbolDivisionEntera < ArbolOperadorBinarioAritmetico;end
class ArbolRestoEntero < ArbolOperadorBinarioAritmetico;end
class ArbolSuma < ArbolOperadorBinarioAritmetico;end
class ArbolResta < ArbolOperadorBinarioAritmetico;end



# Arbol de las reglas EXPR (sin operador)
class ArbolExpresion < RetinaASTNode
    attr_reader :expresion
    attr_accessor :tipoExpresion, :parentesis

    def initialize(expresion)
        @expresion = expresion

        @tipoExpresion = nil
        @parentesis = false
        @label = 'valor'
        @noCheck = true

        # Obtiene el nombre de la expresion a partir del nombre de la clase, separa en espacios
        @nombreExpresion = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    # Obtiene el nombre de la expresion
    def getNombre
        @expresion.valor
    end


    # Obtiene el tipo de la expresion
    def getTipo
        @tipoExpresion
    end


    # Obtiene la linea y columna del comienzo de la expresion
    def getLineaColumna
        [@expresion.linea, @expresion.columna]
    end


    # Representacion en codigo de la expresion
    def toCode
        str = "#{@expresion.valor}"
        if @parentesis
            str = "(#{str})"
        end
        str
    end


    # Representacion en string del nodo
    def printAST(identacion)
        str = indent(@nombreExpresion + ":", identacion)
        str += indent(@label +": "+ @expresion.valor, identacion + INDENT_DEFAULT)
    end

end


# Arboles de expresiones sin operadores
class ArbolExpresionBooleana < ArbolExpresion

    def initialize(expresion)
        super
        @tipoExpresion = BOOLEAN
    end
end

class ArbolLiteralNumerico < ArbolExpresion

    def initialize(expresion)
        super
        @tipoExpresion = NUMBER
    end
end

class ArbolLiteralDeCadenaDeCaracteres < ArbolExpresion; end


# Arbol de identificadores
class ArbolIdentificador < ArbolExpresion

    def initialize(expresion)
        super
        @label = 'nombre'
    end

    def check(parentSymTable)

        # Determina si la variable esta declarada
        identificador, alcanceIdentificador = parentSymTable.lookup(self, true)
        if identificador.nil?
            raise RetinaContextException.new('variableNoDeclarada', self, {nombreVariable: self.getNombre})
        end

        @tipoExpresion = identificador.tipoExpresion
    end

end
