#JOnathan Bandes
    # Regexp que hace match con cualquier palabra reservada
        
$tokenizador = [
    "TkParAbre"          ,
    "TkParCierra"        ,
    "TkComa"             ,
    "TkDesigual"         ,
    "TkDivisionExacta"   , 
    "TkDivisionEntera"   ,
    "RestoExacto"        ,  
    "RestoEntero"        ,  
    "TkFlecha"           ,
    "TkIgual"            ,
    "TkAsignacion"       ,
    "TkMayorIgual"       ,
    "TkMayorQue"         ,
    "TkMenorIgual"       ,
    "TkMenorQue"         ,
    "TkAsterisco"        ,
    "TkNumber"           ,
    "TkIdentificador"    ,
    "TkPuntoYComa"       ,
    "TkResta"            ,
    "TkString"           ,
    "TkMas"              ,
    "TkBegin"            ,
    "TkIf"               ,      
    "TkElse"             ,
    "TkWhile"            ,
    "TkEnd"              ,
    "TkNot"              ,
    "TkAnd"              ,
    "TkOr"               ,
    "TkDiv"              ,
    "TkMod"              ,
    "TkDo"               ,
    "TkWith"             ,
    "TkWrite"            ,
    "TkWriteln"         ,
    "TkRead"             ,
    "TkThen"             ,
    "TkFor"              ,
    "TkFrom"             ,
    "TkTo"               ,
    "TkProgram"          ,
    "TkTimes"            ,
    "TkRepeat"           ,
    "TkReturn"           ,
    "TkTrue"             ,
    "TkFunc"             ,
    "TkBy"               ,
    "TkFalse"            ,
    "TkBool"             ,
]
    #    ReservedW = /\A(?x)(if|else|while|end|not|and|or|div|mod|do|with|writeln|write|then|for|from|
     #   to|program|repeat|times|begin|return|true|false|func)/

    # Regexp que hace match con cualquier tipo de dato

   # TypeData = /\A(boolean|number)/
       
    # Me permite acceder a estos atributos en el main   
    #attr_accessor :tokensList
    #attr_accessor :hasErrors
class BigToken
    attr_reader :type, :line, :column, :value 
    ##
    #  Iteramos sobre el programa a analizar.
    #  En cada iteracion se hace match del inicio
    #  del programa con las diferentes Regexp y se procesa
    #  según sea el caso.

    def initialize(line, column, value)
        @line = line
        @column = column
        @value = value
    end

    def self.expreg
        @expreg
    end

    def self.type
        @type
    end

    def to_s
        selfClass = Object::const_get(self.calss.name)
        "linea #{@line}, columna #{@column}: #{selfClass.tipy} '#{@value}'"
    end
end

#Token abre parentesis
class TkParAbre < BigToken
    @regex = /\A\(/
    @tipo = "signo"
end
   
#Token cierra parentesis
class TkParCierra < BigToken
    @regex = /\A\)/
    @tipo = "signo"
end
   
#Token coma
class TkComa < BigToken
    @regex = /\A,/
    @tipo = "signo"
end

#Token division exacta
class TkDivisionExacta < BigToken
    @regex = /\A\/(?!=)/
    @tipo = "operador aritmetico"
end

#Token division entera
class TkDivisionEntera < BigToken
    @regex = /\A\bdiv\b/
    @tipo = "operador aritmetico"
end

#Token resto entero
class TkRestoEntero < BigToken
    @regex = /\A\bmod\b/
    @tipo = "operador aritmetico"
end

#Token resto exacto
class TkRestoExacto < BigToken
    @regex = /\A%/
    @tipo = "operador aritmetico"
end

#Token desigual (/=)
class TkDesigual < BigToken
    @regex =  /\A\/=/
    @tipo = "signo"
end

#Token tipo de valor de retorno
class TkFlecha < BigToken
    @regex =  /\A\-\>/
    @tipo = "signo"
end
    
#Token igual (==)
class TkIgual < BigToken
    @regex =  /\A==/
    @tipo = "signo"
end
#Token mayor o igual (>=)
class TkMayorIgual < BigToken
    @regex = /\A\>\=/
    @tipo = "signo"
end

#Token mayor que (>)
class TkMayorQue < BigToken
    @regex = /\A\>(?!=)/
    @tipo = "signo"
end

#Token menor o igual (=<)
class TkMenorIgual < BigToken
    @regex = /\A\<\=/
    @tipo = "signo"
end

#Token menor que (<)
class TkMenorQue < BigToken
    @regex = /\A\<(?!=)/
    @tipo = "signo"
end

    #Token producto
class TkAsterisco < BigToken
    @regex = /\A\*/
    @tipo = "operador aritmetico"
end
    
#Token literal numerico
class TkNumber < BigToken
    @regex = /\A\d+(?:\.\d+)?/
    @tipo = "literal numerico"
end
    
#Token punto y coma
class TkPuntoYComa < BigToken
    @regex = /\A;/
    @tipo = "signo"
end


#Token identificador
class TkIdentificador < BigToken
    @regex = /\A[a-z][a-zA-Z_0-9]*/
    @tipo = "identificador"
end

    
#Token menos
class TkResta < BigToken
    @regex = /\A\-(?!\>)/
    @tipo = "operador aritmetico"
end

#Token literal de cadena de caracteres
class TkString < BigToken
    @regex = /\A"(?:[^\"\\\n]|\\\\|\\"|\\n)*"/
    @tipo = "literal de cadena de caracteres"

    def to_s
        "linea #{@line}, columna #{@column}: #{TkLiteralCadenaCaracteres.type} #{@value}"
    end
end

    #Token mas
class TkMas < BigToken
    @regex = /\A\+/
    @tipo = "operador aritmetico"
end

    
#Token asignacion (=)
class TkAsignacion < BigToken
    @regex = /\A=(?!=)/
    @tipo = "signo"
end

#Token begin
class TkEnd < BigToken
    @regex = /\A\bend\b/
    @tipo = "palabra reservada"
end

#Token begin
#Token times
class TkBegin < BigToken
    @regex = /\A\bbegin\b/
    @tipo = "palabra reservada"
end
    
#Token if
class TkIf < BigToken
    @regex = /\A\bif\b/
    @tipo = "palabra reservada"
end


#Token else
class TkElse < BigToken
    @regex = /\A\belse\b/
    @tipo = "palabra reservada"
end

#Token while
class TkWhile < BigToken
    @regex = /\A\bwhile\b/
    @tipo = "palabra reservada"
end

#Token not
class TkNot < BigToken
    @regex = /\A\bnot\b/
    @tipo = "operador logico"
end

#Token and
class TkAnd < BigToken
    @regex = /\A\band\b/
    @tipo = "operador logico"
end


#Token or
class TkOr < BigToken
    @regex = /\A\bor\b/
    @tipo = "operador logico"
end

#Token do
class TkDo < BigToken
    @regex = /\A\bdo\b/
    @tipo = "palabra reservada"
end

    #Token with
class TkWith < BigToken
    @regex = /\A\bwith\b/
    @tipo = "palabra reservada"
end

#Token write
class TkWrite < BigToken
    @regex = /\A\bwrite\b/
    @tipo = "palabra reservada"
end


#Token writeln
class TkWriteln < BigToken
    @regex = /\A\bwriteln\b/
    @tipo = "palabra reservada"
end

#Token read
class TkRead < BigToken
    @regex = /\A\bread\b/
    @tipo = "palabra reservada"
end

#Token then
class TkThen < BigToken
    @regex = /\A\bthen\b/
    @tipo = "palabra reservada"
end
   
#Token for
class TkFor < BigToken
    @regex = /\A\bfor\b/
    @tipo = "palabra reservada"
end


#Token from
class TkFrom < BigToken
    @regex = /\A\bfrom\b/
    @tipo = "palabra reservada"
end


#Token to
class TkTo < BigToken
    @regex = /\A\bto\b/
    @tipo = "palabra reservada"
end
    
#Token program
class TkProgram < BigToken
    @regex = /\A\bprogram\b/
    @tipo = "palabra reservada"
end

#Token times
class TkTimes < BigToken
    @regex = /\A\btimes\b/
    @tipo = "palabra reservada"
end

#Token repeat
class TkRepeat < BigToken
    @regex = /\A\brepeat\b/
    @tipo = "palabra reservada"
end
    
    #Token return
class TkReturn < BigToken
    @regex = /\A\breturn\b/
    @tipo = "palabra reservada"
end

#Token true
class TkTrue < BigToken
    @regex = /\A\btrue\b/
    @tipo = "expresion tipo boolean"
end


#Token false
class TkFalse < BigToken
    @regex = /\A\bfalse\b/
    @tipo = "expresion tipo boolean"
end

#Token func
class TkFunc < BigToken
    @regex = /\A\bfunc\b/
    @tipo = "palabra reservada"
end


#Token by
class TkBy < BigToken
    @regex = /\A\bby\b/
    @tipo = "palabra reservada"
end

    #Token boolean
class TkBool < BigToken
    @regex = /\A\bboolean\b/
    @tipo = "tipo de dato"
end
