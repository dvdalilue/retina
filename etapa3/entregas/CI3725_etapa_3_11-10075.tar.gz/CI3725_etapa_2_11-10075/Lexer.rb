require_relative 'Token.rb'

class Lexer

    ## 
    #  Regexp que hace match con cualquiera de los simbolos del lenguaje
    #  Es importante notar que los símbolos compuestos se evalúan antes que
    #  los simbolos de un solo caracter para evitar inconsistencias
    
    Symbols   = /\A(>=|<=|==|->|\/=|,|\.|\+|-|\(|\)|\*|%|<|>|=|;|\/|")/
    
    # Regexp que hace match con cualquier palabra reservada
        
    tokens = {
    '('           'ParAbre'
    ')'           'ParCierra'
    ','           'Coma'
    '/='          'Desigual'
    '/'           'Division'
    '.'           'Punto'
    '->'          'Flecha'
    '=='          'IgualIgual'
    '>='          'MayorIgualQue'
    '>'           'MayorQue'
    '<='          'MenorIgualQue'
    '<'           'MenorQue'
    '%'           'Modulo'
    '*'           'Asterisco'
    'number'      'Number'
    'id'          'Identificador'
    ';'           'PuntoYComa'
    '-'           'Resta'
    'str'         'String'
    '+'           'Mas'
    '='           'Igual'
    'and'         'And'
    'begin'       'Begin'
    'if'          'If'
    'else'        'Else'
    'while'       'While'
    'end'         'End'
    'not'         'Not'
    'and'         'And'
    'or'          'Or'
    'div'         'Div'
    'mod'         'Mod'
    'do'          'Do'
    'with'        'With'
    'write'       'Write'
    'writeln'     'Writeln'
    'read'        'Read'
    'then'        'Then'
    'for'         'For'
    'from'        'From'
    'to'          'To'
    'program'     'Program'
    'times'       'Times'
    'repeat'      'Repeat'
    'return'      'Return'
    'true'        'True'
    'func'        'Func'
    'by'          'By'
    'false'       'False'
    'bool'        'Bool'

        /\A(?x)(if|else|while|end|not|and|or|div|mod|do|with|writeln|write|then|for|from|
        to|program|repeat|times|begin|return|true|false|func)/

    # Regexp que hace match con cualquier tipo de dato

    TypeData = /\A(boolean|number)/
       
    # Me permite acceder a estos atributos en el main   
    attr_accessor :tokensList
    attr_accessor :hasErrors
        
    ##
    #  Iteramos sobre el programa a analizar.
    #  En cada iteracion se hace match del inicio
    #  del programa con las diferentes Regexp y se procesa
    #  según sea el caso.

    def initialize(file)
        program = File.read(file)   # Programa a Analizar
        line = 1                    # Contador para mostrar el numero de linea
        column = 1                  # Contador para mostrar el numero de columna
        self.hasErrors = false      # Booleano para recordar si hubo un error
        self.tokensList = Array.new

        while not program.empty?

            case program
            
            ## Espacios vacios
            #  Se extraen todos los espacios posibles y se aumenta la columna
            when /\A( |\t)+/s 
                sub = program.slice!(/\A\s+/)
                column += sub.length

            ## Tipos de datos
            #  Se usa la regexp TypeData
            when /#{TypeData}(\W|\z)/
                sub = program.slice!(TypeData)
                self.tokensList << TkType.new(sub, line, column)
                column += sub.length

            ## Palabras Reservadas
            #  Se usa la regexp ReservedW. Luego de la palabra no puede venir 
            #  un caracter valido para palabra debido a que dejaria de ser una
            #  palabra reservada.
            when /#{ReservedW}(\W|\z)/ 
                sub = program.slice!(ReservedW)
                self.tokensList << TkReserved.new(sub, line, column)
                column += sub.length

            ## Saltos de línea
            #  Se aumenta el numero de linea y se reinicia el numero de columna a 1
            when /\A\n/
                program.slice!(/\A\n/)
                line += 1
                column = 1

            ## Signos
            #  Se usa la regexp symbols. A diferencia del caso de las palabras
            #  reservadas no nos afecta que venga despues del simbolo
            when Symbols 
                sub = program.slice!(Symbols)
                self.tokensList << TkChar.new(sub, line, column)
                column += sub.length

            ## Numeros
            #  Hace match con cualquier secuencia de numeros. 
            #  Tambien se verifica que no siga un caracter valido de palabra
            when /\A\d+(\W|\z)/
                sub = program.slice!(/\A\d+/)
                self.tokensList << TkNum.new(sub.to_i, line, column) 
                column += sub.length

            ## Identificadores
            #  Deben empezar con una letra y luego puede venir cualquier
            #  combinacion de caracteres de palabra.
            when /\A[a-zA-Z]\w*(\W|\z)/
                sub = program.slice!(/\A[a-zA-Z]\w*/)
                self.tokensList << TkIdent.new(sub, line, column)
                column += sub.length

            ## Comentario
            #  Hace match desde la ocurrencia de # hasta el final de esa linea
            when /\A#.*\n/
                sub = program.slice!(/\A#.*\n/)

            ## Identificadores no validos
            #  Extrae los identificadores que empiezan con un numero o un _
            #  Este caso reporta el error.
            when /\A[\d_]\w/
                sub = program.slice!(/\A[\d_]+/)
                self.hasErrors = true
                puts "linea #{line}, columna #{column}: caracter inesperado '#{sub}'"
                column += sub.length

            ## Errores
            #  Si no cae en ninguna de las reglas anteriores estamos ante un error
            #  Se reporta el error y se consume un caracter para seguir avanzando
            else
                sub = program.slice!(0)
                self.hasErrors = true
                puts "linea #{line}, columna #{column}: caracter inesperado '#{sub}'"
                column += 1
        
            end 
        end 
    end     
end

