require_relative 'Token.rb'

class retina_lexer
    attr_reader :tokens

    def initialize(fileContents)
        @fileContents = fileContents.force_encoding("UTF-8")

        
        @tokens = []


        @unexpectedList = []


        @currentLine = 1
        @currentColumn = 1
    end

    def updateFileContents(from)
        @fileContents = @fileContents[from .. @fileContents.length-1]
    end

    def skipColumns(numCols)
        @currentColumn = @currentColumn + numCols
    end

    def newLine()
        @currentLine = @currentLine + 1
        @currentColumn = 1
    end

    def tokenize()

        while !@fileContents.empty?

            if @fileContents =~ /\A[ \r\t\f]+/
                skipColumns($&.length)
                updateFileContents($&.length)
                next
            end

            if @fileContents =~ /\A\n/
                newLine()
                updateFileContents($&.length)
                next
            end

            if @fileContents =~ /\A#.*\n/
                newLine()
                updateFileContents($&.length)
                next
            end

            tokenMatch = false
            $tokensAvailable.each do |tokenClassName|

                tokenClass = Object::const_get(tokenClassName)
                if @fileContents =~ tokenClass.regex

                    tokenFound = tokenClass.new(@currentLine, @currentColumn, $&)
                    @tokens.push([tokenClassName.to_sym, tokenFound])

                    tokenMatch = true
                    skipColumns($&.length)
                    updateFileContents($&.length)

                    break
                end
            end

            if !tokenMatch
                unexpected = RetinaLexerError.new(@currentLine, @currentColumn, @fileContents[0])
                @unexpectedList.push(unexpected)

                skipColumns(1)
                updateFileContents(1)
            end

        end

        if @unexpectedList.length > 0
            raise RetinaLexerException.new(@unexpectedList)
        end

        tokens
    end

    def printTokens()
        @tokens.each { |tokenSymbol, token| puts token }
    end
end


class RetinaLexerError

    def initialize(linea, columna, valor)
        @linea = linea
        @columna = columna
        @valor = valor
    end

    def to_s
        "linea #{@linea}, columna #{@columna}: caracter inesperado '#{@valor}'\n"
    end
end

class RetinaLexerException < RuntimeError

    def initialize(unexpectedList)
        @unexpectedList = unexpectedList
    end

    def to_s
        str = "\n"
        @unexpectedList.each do |unexpected|
            str += "#{unexpected}"
        end
        str
    end
end

