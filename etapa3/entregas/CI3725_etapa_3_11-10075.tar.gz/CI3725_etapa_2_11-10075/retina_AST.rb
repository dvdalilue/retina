
# Identacion default
INDENT_DEFAULT = 2


# 
def indent(str, pad = INDENT_DEFAULT)
    str.to_s.rjust(str.to_s.length + pad, ' ') + "\n"
end


# AST
class Tree

    def initialize(funciones, bloquePrograma)
        @funciones = funciones
        @bloquesPrograma = bloquePrograma
    end

    def to_s

        identacion = INDENT_DEFAULT
        indentacionNext = identacion + INDENT_DEFAULT

        str = "\nAST:\n"
        if @funciones
            str += indent("funciones:", identacion)
            str += @funciones.to_s(indentacionNext)
        end

        if @bloquesPrograma
            str += indent("programa:", identacion)
            str += @bloquesPrograma.to_s(indentacionNext)
        end

        str
    end
end


# Hijos del AST
class Hijos

    # Representacion en string del arbol
    def to_s(identacion)

        # Primera parte del arbol: nombre
        str = indent(@nombreArbol +":", identacion)
        identacion += INDENT_DEFAULT
        indentacionNext = identacion + INDENT_DEFAULT

        # Segunda parte del arbol: atributos
        getAttributes().each do |attribute, value|

            # Saca el "@" del nombre del atributo
            attribute = attribute.to_s[1..-1]
            if attribute == 'nombreArbol' or value.nil?
                next
            end

            # Separa en espacios
            attribute = attribute.gsub(/(?=[A-Z])/, ' ').strip.downcase
            str += indent("#{attribute}:", identacion)
            str += value.to_s(indentacionNext)
        end

        str
    end

    # Obtiene los atributos de la instancia
    def getAttributes
        list = []
        instance_variables.map do |attribute|
            list.push([attribute, instance_variable_get(attribute)])
        end
        list
    end
end


# Arbol de las reglas Functions
class TrFunctions < Hijos

    def initialize(funcion, funcionList = nil)
        @funcion = funcion
        @funcionList = funcionList
    end


    def to_s(identacion)

        str = @funcion.to_s(identacion)

        if @funcionList
            str += @funcionList.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas 
class TrFunction < Hijos

    def initialize(identificador, parametros, tipoRetorno, instrucciones)
        @nombreArbol = "FUNCION"
        @identificador = ArbolIdentificador.new(identificador)
        @parametros = parametros
        @tipoRetorno = tipoRetorno
        @instrucciones = instrucciones
    end

end


# Arbol de las reglas 
class TrFunctionArgs < Hijos

    def initialize(tipo, identificador, funcionParams = nil)
        @tipo = tipo
        @identificador = ArbolIdentificador.new(identificador)
        @funcionParams = funcionParams
    end


    def to_s(identacion)

        str = indent("PARAMETRO:", identacion)
        identacionParametro = identacion + INDENT_DEFAULT
        indentacionNext = identacionParametro + INDENT_DEFAULT

        str += indent("tipo:", identacionParametro)
        str += @tipo.to_s(indentacionNext)

        str += indent("nombre:", identacionParametro)
        str += @identificador.to_s(indentacionNext)

        if @funcionParams
            str += @funcionParams.to_s(identacion)
        end

        str
    end

end


# Arbol de las reglas 
class TrReturn < Hijos
    attr_accessor :expresion

    def initialize(expresion)
        @nombreArbol = "RETORNO FUNCION"
        @expresion = expresion
    end

end



# Arbol de las reglas 
class TrBlocks < Hijos

    def initialize(bloque, bloqueList = nil)
        @bloque = bloque
        @bloqueList = bloqueList
    end


    def to_s(identacion)

        str = @bloque.to_s(identacion)

        if @bloqueList
            str += @bloqueList.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas 
class TrBlock < Hijos
    attr_accessor :declaraciones, :instrucciones

    def initialize(declaraciones, instrucciones)
        @nombreArbol = "BLOQUE"
        @declaraciones = declaraciones
        @instrucciones = instrucciones
    end

end


# Arbol de las reglas 
class TrDeclarations < Hijos

    def initialize(declaracion, declaracionList = nil)
        @declaracion = declaracion
        @declaracionList = declaracionList
    end


    def to_s(identacion)

        str = @declaracion.to_s(identacion)

        if @declaracionList
            str += @declaracionList.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas 
class TrDeclaration < Hijos

    def initialize(tipo, identificadores, expresionInicializacion = nil)
        @nombreArbol = "DECLARACION"
        @tipo = tipo

        if identificadores.class.name == "TkIdentificador"
            @identificador = ArbolIdentificador.new(identificadores)
        else
            @identificadores = identificadores
        end

        @inicializacion = expresionInicializacion
    end

end


# Arbol de las reglas 
class TrIdDeclarations < Hijos

    def initialize(identificador, listaIdentificadores = nil)
        @identificador = ArbolIdentificador.new(identificador)
        @listaIdentificadores = listaIdentificadores
    end


    def to_s(identacion)

        str = @identificador.to_s(identacion)

        if @listaIdentificadores
            str += @listaIdentificadores.to_s(identacion)
        end

        str
    end

end



# Arbol de las reglas 
class TrInstructions < Hijos

    def initialize(instruccion, instruccionList = nil)
        @instruccion = instruccion
        @instruccionList = instruccionList
    end


    def to_s(identacion)

        str = @instruccion.to_s(identacion)

        if @instruccionList
            str += @instruccionList.to_s(identacion)
        end

        str
    end

end




# Arbol de las reglas 
class TrAssignment < Hijos

    def initialize(identificador, expresion)
        @nombreArbol = "ASIGNACION"
        @ladoIzquierdo = ArbolIdentificador.new(identificador)
        @ladoDerecho = expresion
    end

end


# Arbol de las reglas 
class TrInput < Hijos

    def initialize(identificador)
        @nombreArbol = "ENTRADA"
        @identificador = ArbolIdentificador.new(identificador)
    end

end


# Arbol de las reglas 
class TrOutput < Hijos

    def initialize(expresiones, salto = nil)
        @nombreArbol = 'SALIDA'
        if salto
            @nombreArbol = 'SALIDA CON SALTO'
        end
        @expresiones = expresiones
    end

end



# Arbol de las reglas 
class TrOutExpresion < Hijos

    def initialize(expresion, expresiones = nil)
        @expresion = expresion
        @expresiones = expresiones
    end


    def to_s(identacion)

        str = @expresion.to_s(identacion)

        if @expresiones
            str += @expresiones.to_s(identacion)
        end

        str
    end

end


# Arbol de las reglas 
class TrIf < HijosHijos

    def initialize(expresion, instruccionesThen, instruccionesElse = nil)
        @nombreArbol = "CONDICIONAL"
        @expresion = expresion
        @instruccionesThen = instruccionesThen
        @instruccionesElse = instruccionesElse
    end

end



# Arbol de las reglas 
class TrWhile < HijosHijos

    def initialize(expresion, instrucciones)
        @nombreArbol = "ITERACION WHILE"
        @expresion = expresion
        @instrucciones = instrucciones
    end

end


# Arbol de las reglas 
class TrFor < HijosHijos

    def initialize(identificador, from, to, by, instrucciones)
        @nombreArbol = "ITERACION FOR"
        @identificador = ArbolIdentificador.new(identificador)
        @expresionFrom = from
        @expresionTo = to
        @expresionBy = by
        @instrucciones = instrucciones
    end

end



# Arbol de las reglas 
class TrRepeat < HijosHijos

    def initialize(expresion, instrucciones)
        @nombreArbol = "REPEAT"
        @expresion = expresion
        @instrucciones = instrucciones
    end

end



# Arbol de las reglas 
class TrFunctionCall < HijosHijos

    def initialize(identificador, argumentos = nil)
        @nombreArbol = "LLAMADA FUNCION"
        @identificador = ArbolIdentificador.new(identificador)
        @argumentos = argumentos
    end

end


# Arbol de las reglas 
class TrFunctionArgs < HijosHijos

    def initialize(expresion, funcionArgs = nil)
        @expresion = expresion
        @funcionArgs = funcionArgs
    end


    def to_s(identacion)

        if @expresion.nil?
            return ''
        end

        str = indent("ARGUMENTO:", identacion)
        str += @expresion.to_s(identacion + INDENT_DEFAULT)

        if @funcionArgs
            str += @funcionArgs.to_s(identacion)
        end

        str
    end

end


# Arbol de las reglas 
class TrType < HijosHijos

    def initialize(nombre)
        @nombre = nombre.valor
    end

    def to_s(identacion)
        str = indent("TIPO:", identacion)
        str += indent("nombre: "+ @nombre, identacion + INDENT_DEFAULT)
    end

end


# Arbol de las reglas con operadores unarios
class TreeBinOp < Hijos

    def initialize(operador, expresion)
        #@operador = operador
        @expresion = expresion

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @nombreArbol = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end

end


# 
class TrNot < ArbolOperadorUnario;end
class TrMenosUnario < ArbolOperadorUnario;end



# 
class TreeBinOp < Hijos

    def initialize(leftExpresion, operador, rightExpresion)
        #@operador = operador
        @Izquierda = leftExpresion
        @Derecha = rightExpresion

        # Obtiene el nombre de la operacion a partir del nombre de la clase, separa en espacios
        @nombreArbol = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end

end

# Arboles de expresiones con operadores binarios
class TrIgual < TreeBinOp;end
class TrDesigual < TreeBinOp;end
class TrMayorIgualQue < TreeBinOp;end
class TrMenorIgualQue < TreeBinOp;end
class TrMayorQue < TreeBinOp;end
class TrMenorQue < TreeBinOp;end
class TrAnd < TreeBinOp;end
class TrOr < TreeBinOp;end
class TrAsterisco < TreeBinOp;end
class TrDivisionExacta < TreeBinOp;end
class TrRestoExacto < TreeBinOp;end
class TrDivisionEntera < TreeBinOp;end
class TrRestoEntero < TreeBinOp;end
class TrMas < TreeBinOp;end
class TrResta < TreeBinOp;end



# 
class TreeExpresion < Hijos

    def initialize(expresion)
        @expresion = expresion
        @valorExpresion  = @expresion.valor
        @labelExpresion = 'valor'

        # Obtiene el nombre de la expresion a partir del nombre de la clase, separa en espacios
        @nombreExpresion = self.class.name.gsub('Arbol', '').gsub(/(?=[A-Z])/, ' ').strip.upcase
    end


    def to_s(identacion)
        str = indent(@nombreExpresion + ":", identacion)
        str += indent(@labelExpresion +": "+ @valorExpresion, identacion + INDENT_DEFAULT)
    end

end

# Arboles de expresiones sin operadores
class TkBoolean < TreeExpresion; end
class TkNumero < TreeExpresion;end

# Arbol de identificadores
class TrIdentificador < TreeExpresion

    def initialize(expresion)
        super
        @labelExpresion = 'name'
    end
end
