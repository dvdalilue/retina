#!/usr/bin/env ruby

require './ruleClasses.rb'
require './symbolTable.rb'

$symTable = nil		# Tabla de simbolos.
$tableStack = []	# Pila de tablas.

################################################
# Manejo de la estructura general del programa #
################################################



# Manejador del programa principal.
def program_Handler(ast)
	scope_Handler(ast.scope)
end

# Manejador de alcances.
def scope_Handler(scope)
	
	symTableAux = SymbolTable.new($symTable)
	$symTable = symTableAux
	
	declError = 0
	if (scope.decl != nil)
		declError = decl_Handler(scope.decl)
	end
	instrError = instr_Handler(scope.inst)
	
	$tableStack << $symTable
	$symTable = $symTable.father
	
	if ($symTable == nil)
		if (declError > 0) or (instrError > 0)
			puts "Symbol table will not be shown."
			abort
		end
		puts "Symbol Table:"
		$tableStack.reverse!
		$tableStack.each do |st|
			st.print_Table
		end
	end
	return declError + instrError
end

# Manejador de funciones
def TrFunctions_Handler(funciones_Args)
 	funcionListError = 0
 	if (funciones_Args.funcionList != nil)
 		funcionListError = TrFunction_Handler(funciones_Args.funcionList)
 	end

	funcionError = TrFunction_Handler(funciones_Args.funcion)
	return funcionError + funcionListError
end


# Manejador de la funcion
def TrFunction_Handler(funcion)
	parametrosError    = Parms_Handler(funcion.parametros)
	
	tipoRetornoError   = TrReturn_Handler(funcion.tipoRetorno)
	
	instruccionesError = instr_Handler (funcion.instrucciones)

	return parametrosError + tipoRetornoError + instruccionesError
end


# Manejador de la funcionArgs
def TrFunctionArgs_Handler(funcion_Args)
	funcionParamsError = 0
	if (funcion_Args.funcionParams != nil)
		funcionParamsError = TrFunctionArgs_Handler(funcion_Args.funcionParams)
	end

	typeError = Type_Handler(funcion_Args.funcionParams)

	return funcionParamsError + typeError
end

def TrReturn_Handler (return_Args)
	expresionError = expression_Handler(return_Args.expresion)
	return expresionError
end

def TrBlocks_Handler (blocks_Args)
	blocksListError = 0
	if (blocksListError != nil)
		blocksListError = TrBlocks_Handler(blocks_Args.bloqueList)
	end

	blockError = TrBlocks_Handler (blocks_Args.bloque)
	return blocksListError + blockError
end

def TrBlock_Handler (block_Args)
	decl_Error = decl_Handler(block_Args.declaraciones)
	instr_Error = instr_Handler(block_Args.instrucciones)
	return decl_Error + instr_Error
end


def TrDeclarations_Handler (declList_Args)
	declList_Error = 0
	if (declList_Error != nil)
		declList_Error = TrDeclarations_Handler(declList_Args.declaracionList)
	end

	decl_Error = decl_Handler(block_Args.declaraciones)
	
	return decl_Error + declList_Error

end

def TrDeclaration_Handler (decl_Args)
	expIniError = 0
	if (expIniError != nil)
		expIniError = expresionIni_Handler(decl_Args.expresionInicializacion)
	end

	typeError = Type_Handler(funcion_Args.funcionParams)
	return typeError + expIniError
end

def TrIdDeclarations_Handler (idDecl_Args)
	listIdentError = 0
	if (listIdentError != nil)
		listIdentError = listI_Handler(idDecl_Args.listaIdentificadores)
	end
	return listIdentError
end		

def TrInstructions_Handler (inst_Args)
	listInstrError = 0
	if (listInstrError != nil)
		listInstrError = TrInstructions_Handler(inst_Args.instruccionList)
	end
	instrError = instr_Handler(inst_Args.instruccionList)
	return listInstrError
end		

def TrAssignment_Handler (asig_Args)
	expresionError = expression_Handler(asig_Args.expresion)
	return expresionError
end

#def TrInput_Handler ()

def TrOutput_Handler(out_Args)
	saltoError = 0
	if (saltoError != nil)
		saltoError = salto_Handle(out_Args.salto)
	end
	expresionesError = expressiones_Handler(out_Args.expresiones)
	return saltoError + expresionesError
end

def TrOutexpression_Handler (outexpr_Args)
	expresionesError = 0
	if (expresionesError != nil)
		expresionesError = expressiones_Handler (outexpr_Args.expresiones)
	end
	expresionError = expression_Handler(outexpr_Args.expresion)
	return expresionError + expresionesError
end

def TrIf_Handler (if_Args)
	instElseError = 0
	if (instElseError != nil)
		instElseError = conditional_statment_Handler(if_Args.instruccionesElse)
	end
	instThenError = conditional_statment_Handler(if_Args.instruccionesThen)
	expresionError = expression_Handler(if_Args.expresion)
	return instElseError + instThenError + expresionError
end

def TrWhile_Handler (while_Args)

	instr_Error = instr_Handler(while_Args.instrucciones)
	expresionError = expression_Handler(while_Args.expresion)
	return instr_Error + expresionError
end

def TrFor_Handler (for_Args)
	fromError = from_Handler(for_Args.from)
	toError   = to_Handler(for_Args.to)
	byError   = by_Handler(for_Args.by)
	instr_Error = instr_Handler(for_Args.instrucciones)
	return fromError + toError + byError + instr_Error
end

def TrRepeat_Handler (repeat_Args)
	instr_Error = instr_Handler(repeat_Args.instrucciones)
	expresionError = expression_Handler(repeat_Args.expresion)
	return instr_Error + expresionError
end

def TrFunctionCall_Handler (funcCall_Args)
	argsError = 0
	if (argsError != nil)
		argsError = args_Handler(funccall_Args.argumentos)
	end
	return argsError
end

def TrFunctionArgs_Handler (funcArgs_Args)
	funcionArgsError = 0
	if (funcionArgsError!= nil)
		funcionArgsError = funcArgs_Handler (funcArgs_Args.funcionArgs)
	end
	expresionError = expression_Handler(funcArgs_Args.expresion)
	return funcionArgsError + expresionError
end
	
def TreeUnOp_Handler (unop_Args)
	operadorError = operador_Handler (unop_Args.operador)
	expresionError= expression_Handler(unop_Args.expresion)
	return operadorError + expresionError
end

def TreeBinOp (binop_Args)
	leftExpError  = left_Handler(binop_Args.leftExpresion)
	operadorError = operador_Handler (binop_Args.operador)
	rightExpError = right_Handler(binop_Args.rightExpresion)
end

# Manejador de declaraciones.
def decl_Handler(decl)
	result2 = 0
	case decl.type
	when :AT
		result1 = listI_Handler(:CANVAS, decl.listI)
	when :PERCENT
		result1 = listI_Handler(:NUMBER, decl.listI)
	when :EXCLAMATION_MARK
		result1 = listI_Handler(:BOOLEAN, decl.listI)
	end
	if (decl.decl != nil)
		result2 = decl_Handler(decl.decl)
	end
	return result1 + result2
end

# Manejador de lista de identificadores
def listI_Handler(type, listI)
	if !($symTable.contains(listI.id.term))
		$symTable.insert(listI.id.term, [type, nil])
		if (listI.listI != nil)
			return listI_Handler(type, listI.listI)
		end
		return 0
	else
		puts "ERROR: variable '#{listI.id.term}' was declared before" \
				" at the same scope."
		if (listI.listI != nil)
			return listI_Handler(type, listI.listI) + 1
		end
		return 1
	end
end

# Manejador de instrucciones
def instr_Handler(instr, iterVar=nil)
	case instr.opID[0]
	when :INSTR
		totResult = 0
		instr.branches.each do |i|
			totResult += instr_Handler(i,iterVar)
		end
		return totResult
	when :ASSIGN
		if iterVar != nil
			return assign_Handler(instr.branches[0], iterVar)
		else
			return assign_Handler(instr.branches[0])
		end
	when :READ
		return read_Handler(instr)
	when :WRITE
		return write_Handler(instr)
	when :CONDITIONAL_STATEMENT
		return conditional_statment_Handler(instr.branches[0])
	when :IND_LOOP
		return iLoop_Handler(instr.branches[0])
	when :DET_LOOP
		return dLoop_Handler(instr.branches[0])
	when :SCOPE
		return scope_Handler(instr.branches[0])
	end
end

############################################
# Manejo de las instrucciones del programa #
############################################

# Manejador de la instruccion ASSIGN.
def assign_Handler(assign, iterVar=nil)
	idVar = assign.branches[0].term
	if (idVar == iterVar)
		puts "ASSIGN ERROR: iterator '#{idVar}' cannot be modified."
		return 1
	end
	if ($symTable.lookup(idVar) == nil)
		puts "ASSIGN ERROR: variable '#{idVar}' has not been declared."
		return 1
	end
	typeVar = $symTable.lookup(idVar)[0]
	typeExpr = expression_Handler(assign.branches[1])
	if (typeVar != typeExpr)
		puts "ASSIGN ERROR: #{typeExpr} expression assigned to #{typeVar} "\
			"variable '#{idVar}'."
		return 1
	end
	return 0
end

# Manejador de la instruccion READ.
def read_Handler(read)
	idVar = read.branches[0].term
	if ($symTable.lookup(idVar) == nil)
		puts "READ ERROR: variable '#{idVar}' has not been declared."
		return 1
	end
	typeVar = $symTable.lookup(idVar)[0]
	if (typeVar != :NUMBER) and (typeVar != :BOOLEAN)
		puts "READ ERROR: variable '#{idVar}' must be an int or a boolean."
		return 1
	end
	return 0
end

# Manejador de la instruccion WRITE.
def write_Handler(write)
	expr = write.branches[0]
	typeExpr = expression_Handler(expr)
	if (typeExpr != :CANVAS)
		puts "WRITE ERROR: the expression given must be a canvas."
		return 1
	end
	return 0
end

# Manejador de la instruccion CONDITIONAL STATEMENT.
def conditional_statment_Handler(cs)
	expr = cs.elems[0]
	instr1 = cs.elems[1]
	result = instr_Handler(instr1)
	if (cs.elems[2] != nil)
		instr2 = cs.elems[2]
		result += instr_Handler(instr2)
	end
	if (expression_Handler(expr) != :BOOLEAN)
		puts "CONDITIONAL STATEMENT ERROR: expression must be boolean."
		result += 1
	end
	return result
end

# Manejador de la instruccion IND LOOP.
def iLoop_Handler(iLoop)
	result = 0
	expr = iLoop.elems[0]
	if (expression_Handler(expr) != :BOOLEAN)
		puts "IND LOOP ERROR: expression must be boolean."
		result += 1
	end
	instr = iLoop.elems[1]
	result += instr_Handler(instr)
	return result
end

# Manejador de la instruccion DET LOOP.
def dLoop_Handler(dLoop)
	result = 0
	if (dLoop.types[0] == :VARIABLE)
		iterVar = dLoop.elems[0].term
		# Busca la variable, si la encuentra, la actualiza, si no, la inserta.
		if ($symTable.lookup(iterVar) == nil)
			$symTable.insert(iterVar, [:NUMBER, nil])
		else
			$symTable.update(iterVar, [:NUMBER, nil])
		end
		expr1 = dLoop.elems[1]
		typeExpr1 = expression_Handler(expr1)
		expr2 = dLoop.elems[2]
		typeExpr2 = expression_Handler(expr2)
		if (typeExpr1 != :NUMBER) or (typeExpr2 != :NUMBER)
			puts "DET LOOP ERROR: expressions must be arithmetic."
			result += 1
		end
		instr = dLoop.elems[3]
		result += instr_Handler(instr, iterVar)
		return result
	else
		expr1 = dLoop.elems[0]
		typeExpr1 = expression_Handler(expr1)
		expr2 = dLoop.elems[1]
		typeExpr2 = expression_Handler(expr2)
		if (typeExpr1 != :NUMBER) or (typeExpr2 != :NUMBER)
			puts "DET LOOP ERROR: expressions must be arithmetic."
			result += 1
		end
		instr = dLoop.elems[2]
		result += instr_Handler(instr)
		return result
	end
end

##########################################
# Manejo de las expresiones del programa #
##########################################

# Manejador de expresiones:
# Esta función recibe una expresión y devuelve su tipo.
def expression_Handler(expr)
	# Procesar como binaria
	if expr.instance_of?(BinExp)
		return TreeBinOp_Handler(expr)
	# Procesar como unaria
	elsif expr.instance_of?(UnaExp)
		return TreeUnOp_Handler(expr)
	# Procesar como parentizada
	elsif expr.instance_of?(ParExp)
		return parExp_Handler(expr)
	# Procesar como un caso base, un termino.
	elsif expr.instance_of?(Terms)
		type = expr.nameTerm
		case type
		when :IDENTIFIER			
			idVar = expr.term
			typeVar = $symTable.lookup(idVar)[0]
			return typeVar
		when :CANVAS
			return :CANVAS
		when :TRUE
			return :BOOLEAN
		when :FALSE
			return :BOOLEAN
		when :NUMBER
			return :NUMBER			
		end
	else
		puts "ERROR: hubo un errror expression_Handler."		
	end
end

# Manejador de expresiones binarias:
def TreeBinOp_Handler(expr)
	typeExpr1 = expression_Handler(expr.elems[0])
	typeExpr2 = expression_Handler(expr.elems[1])
	if (typeExpr1 != typeExpr2)
		return nil
	end
	case expr.op
	when /^\/\\/
		if typeExpr1 == :BOOLEAN
			return :BOOLEAN
		else
			return nil
		end
	when /^\\\//
		if typeExpr1 == :BOOLEAN
			return :BOOLEAN
		else
			return nil
		end
	when /^(=|\/=)/
		return :BOOLEAN
	when /^[\+\-\*\/%]/
		if typeExpr1 == :NUMBER
			return :NUMBER
		else
			return nil
		end
	when /^[~&]/
		if typeExpr1 == :CANVAS
			return :CANVAS
		else
			return nil
		end
	when /^(<|>|<=|>=)/
		if (typeExpr1 == :NUMBER) and (typeExpr2 == :NUMBER)
			return :BOOLEAN
		else
			return nil
		end
	end
end

# Manejador de expresiones parentizadas.
def parExp_Handler(expr)
	return expression_Handler(expr.expr)
end

# Manejador de expresiones unarias.
def TreeUnOp_Handler(expr)
	typeExpr = expression_Handler(expr.elem)
	case expr.op
	when /^[$']/
		if typeExpr == :CANVAS
			return :CANVAS
		else
			return nil
		end
	when /\^/
		if typeExpr == :BOOLEAN
			return :BOOLEAN
		else
			return nil
		end
	when /-/
		if typeExpr == :NUMBER
			return :NUMBER
		else
			return nil
		end
	end
end