# Jonathan Bandes; 11-10075

class SymTableError < RuntimeError
end


class RedefinirError < SymTableError
  def initialize(token, token_viejo)
    @token = token
    @token_viejo = token_viejo
  end

  def to_s
    "Error en línea #{@token.linea}, columna #{@token.columna}: la variable '#{@token.texto}' fue previamente declarada en la línea #{@token_viejo.linea}, columna #{@token_viejo.columna}."
  end
end


class UpdateError < SymTableError
  def initialize(token)
    @token = token
  end

  def to_s
    "Error no se puede actualizar el token '#{@token.texto}'"
  end
end


class DeleteError < SymTableError
  def initialize(token)
    @token = token
  end

  def to_s
    "Error no se puede eliminar el token '#{@token.texto}'"
  end
end




class SymTable
  #construcor de la tabla de simbolos
  def initialize(padre = nil)
    @padre = padre
    @tabla = {}
    @nombres = []
  end

  def insert(token, tipo, es_mutable = true, valor = nil)
    raise RedefinirError::new(token, @tabla[token.texto][:token]) if @tabla.has_key?(token.texto)
    @tabla[token.texto] = { :tipo => tipo, :es_mutable => es_mutable, :token => token, :valor => valor }
    @nombres << token.texto
    self
  end

  def delete(nombre)
    raise DeleteError::new token unless @tabla.has_key?(nombre)
    @tabla.delete(nombre)
    @nombres.delete(nombre)
    self
  end

  def update(token, tipo, es_mutable, valor)
    raise UpdateError::new token unless @tabla.has_key?(token.texto)
    @tabla[token.texto] = { :tipo => tipo, :es_mutable => es_mutable, :token => token, :valor => valor }
    self
  end

  def isMember?(nombre)
    @tabla.has_key?(nombre)
  end

  def find(nombre)
    if @tabla.has_key?(nombre) then
      @tabla[nombre]
    elsif @padre.nil? then
      nil
    else
      @padre.find(nombre)
    end
  end
end