#! /usr/bin/ruby
# Universidad Simon Bolivar
# Trimestre Enero-Marzo 2017
# Traductores e Interpretadores [CI3725]
# Rafael Cisneros, 13-11156
# Miguel Canedo, 13-10214
# Proyecto, Tabla de Simbolos

require_relative 'Errores'
require_relative 'Lexer'

# Clase que representa una Tabla de Simbolos en el lenguaje.
class SymTable 
	# Metodo Constructor
	def initialize (padre = nil)
		@padre = padre
		@tabla = {}
	end

	# Metodo que se encarga de insertar un token en la tabla de simbolos o arrojar un error si el token ya existe
	def insert token, tipo, variable = true
		if @tabla.has_key? (token.texto)
			raise RedefinirError.new(token, @tabla[token.texto][:token], variable)
		else
			@tabla[token.texto] = {:token => token, :tipo => tipo}
		end
	end

	# Metodo que se encarga de buscar un token en la tabla de simbolos y en sus tablas padres
	def find nombre
		if @tabla.has_key? (nombre)
			@tabla[nombre]
		elsif @padre == nil
			nil
		else
			@padre.find(nombre)
		end
	end

	# Metodo utilizado para imprimir la tabla de simbolos
	def print_tabla(indentacion)
		s = ""
		if @tabla.empty?
			s += "#{indentacion}none \n"
		else
			@tabla.each do | clave, token, tipo |
				s += "#{indentacion}#{clave}: #{token[:tipo]} \n"
			end
		end
		print s
	end
end


# Creamos la Tabla de Simbolos para las funciones y guardamos las funciones que 
# por default trae el lenguaje Retina
$tablaFunciones = SymTable.new()

$tablaFunciones.insert(TkId.new("home",0,0), [nil])
$tablaFunciones.insert(TkId.new("openeye",0,0), [nil])
$tablaFunciones.insert(TkId.new("closeeye",0,0), [nil])
$tablaFunciones.insert(TkId.new("forward",0,0), ["number", nil])
$tablaFunciones.insert(TkId.new("backward",0,0), ["number", nil])
$tablaFunciones.insert(TkId.new("rotatel",0,0), ["number", nil])
$tablaFunciones.insert(TkId.new("rotater",0,0), ["number", nil])
$tablaFunciones.insert(TkId.new("setposition",0,0), ["number", "number", nil])
$tablaFunciones.insert(TkId.new("arc",0,0), ["number", "number", nil])
