class ErrorTablaSimbolos < RuntimeError; end

class ErrorContexto < ErrorTablaSimbolos
  attr_accessor :token, :mensaje, :nombres
  def initialize(token, mensaje, nombres= nil)
   @mensaje = mensaje
   @token = token
   @nombres = nombres
  end

  def to_s
    puts " Error analizando el contexto "
    case @mensaje

    when "Funcion ya declarada"
      "Error en la funcion " + @nombres[0].to_s + ": " + @mensaje.to_s 

    when "Error en tipo de retorno"
      "Error en la funcion " + @nombres[0].to_s + ": " + @mensaje.to_s

    when "el tipo de retorno no es el mismo que el tipo de funcion"
      "Error en la funcion " + @nombres[0].to_s + ": " + @mensaje.to_s

    when "Identificador de parametro repetido"
      "Error en el parametro " + @nombres[0].to_s + ": " + @mensaje.to_s

    when "La condicion de arriba no es de tipo booleano"
      @mensaje.to_s + ", es de tipo " + @nombres[0].to_s

    when "hay un error de tipos en asignacion"      
      "Error en la asignacion de arriba, el tipo del identificador es " + @nombres[0].to_s + " y el tipo a asignar es " + @nombres[1].to_s 

    when "variable no declarada"
      "Error en la variable " + @nombres[0].to_s + ", " + @mensaje.to_s 

    when "variable previamente declarada" 
      "Error en la variable " + @nombres[0].to_s + ", " + @mensaje.to_s 

    when "Intervalo inferior no es de tipo number"
      @mensaje

    when "Intervalo superior no es de tipo number"
      @mensaje

    when "Tipo de incremento no es de tipo number"
      @mensaje

    when "El tipo de expresion en Repeat no es de tipo number"      
      @mensaje

    when "funcion no declarada"
      "Error en la funcion " + @nombres[0].to_s + ": " + @mensaje.to_s

    when "Numero de parametros insuficientes"
      @mensaje

    when "Se excede el numero de parametros"
      @mensaje

    when "tipo de retorno invalido"
      "Error en la funcion " + @nombres[0].to_s + ": " + @mensaje.to_s + ", #{@nombres[1]}"

    when "Los operandos logicos de la instruccion de arriba no son del tipo booleano"
      @mensaje

    when "el operando logico no es del tipo booleano"
      "Error en " + @nombres[0].to_s + @mensaje
    
    when "Los operandos de comparacion de arriba no son del mismo tipo"
      @mensaje
  
    when "Los operandos aritmeticos de arriba no son del tipo numero"
      @mensaje
    
    when "El operando aritmetico no es del tipo numero"
     "Error en " + @nombres[0].to_s + @mensaje

    end
      
  end
end

class ErrorEliminar < ErrorTablaSimbolos
  def initialize(token)
  @token = token
  end

  def to_s
  "Error, no se puede eliminar el token '#{@token.text}'"
  end
end

