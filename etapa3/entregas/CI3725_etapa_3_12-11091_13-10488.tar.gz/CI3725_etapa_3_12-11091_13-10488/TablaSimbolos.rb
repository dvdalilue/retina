class TablaSimbolos
	attr_accessor :id, :nombre, :hijos

  	def initialize(id = nil, nombre = nil, padre = nil)
		@id = id
		@nombre = nombre
		@tabla = {}
		@padre = padre
		@hijos = Array.new
  	end

	def insertar(token, tipo)
		@tabla[token] = { :token => token, :tipo => tipo}
	end


  	def eliminar(clave)
		raise ErrorEliminar::new token unless @tabla.has_key?(clave)
		@tabla.eliminar(clave)
  	end


  	def actualizar(clave, valor)
		if !(esMiembro?(clave))
	  		if (@padre != nil)
				return @padre.actualizar(clave, valor)
	  		else
				puts "ERROR: variable '#{clave}' no ha sido declarada."
				return false
		  	end
		else
	  		@tabla[clave] = valor
	  		return true
		end   
  	end

  	def buscar(clave)
		if @tabla.has_key?(clave) then
			return @tabla[clave]
		elsif @padre.nil? then
	  		return nil
		end
		@padre.buscar(clave)
  	end

  	def esMiembro?(clave)
		if @padre.nil? then
	  		return @tabla.has_key?(clave)
		else
	  		return (@tabla.has_key?(clave) or @padre.esMiembro?(clave))
		end
  	end

	def set_padre(padre)
		@padre = padre
	end

  	def agregarHijo(tablaSimHijo)
  		@hijos << tablaSimHijo
  	end 

  	def printTablas()
  		puts "Tablas de Simbolos"
  		ind = 0
  		@hijos.each do |hijo|
  			puts "\n"
  			hijo.printTabla(ind)
  		end
  	end

  	def printTabla(profundidad = 0)
  		indentacion(profundidad)
  		puts "Alcance" + @id.to_s + " " + @nombre.to_s
  		indentacion(profundidad + 1)
  		if (@tabla.empty?)
  			puts "No hay variables"
  		else 
  			puts "Variables: "
  		end

  		@tabla.each do |id, tipo|
  			indentacion(profundidad + 2)
  			puts id.to_s + " : " + tipo.to_s
  		end

  		indentacion(profundidad + 1)
  		if (@hijos.empty?)
  			puts "No hay sub_alcances"
  		else
  			puts "Sub_alcances: "
  		end

  		@hijos.each do |hijo|
  			hijo.printTabla(profundidad + 2)
  		end
  	end

  	def indentacion(ind)
  		for i in 1..ind
  			print "\t"
  		end
  	end
  
end

class TablaFunciones < TablaSimbolos
  
  def initialize(nombre = nil)
	super(nombre)
	@funciones = Hash.new
  end


  def getParametros(funcion)
  	return @funciones[funcion]
  end

  def insertar(funcion, tipo, parametros)
  	super(funcion, tipo)

  	@funciones[funcion] = parametros
  end

end

