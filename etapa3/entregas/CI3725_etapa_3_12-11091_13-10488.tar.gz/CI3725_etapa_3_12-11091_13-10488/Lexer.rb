# AUTORES:
# Alessandra Marero 12-11091
# Julio Fuenmayor 13-10488


#Diccionario que contiene los tokens y sus regex correspondientes
$tokens = { 
/^program/								=>		:PROGRAM,
	/^\bbegin\b/						=>		:BEGIN,
	/^\bend\b/							=>		:END,
	/^\bwith\b/							=>			:WITH,
	/^\bdo\b/							=>		:DO,
	/^\brepeat\b/						=>		:REPEAT,
	/^\btimes\b/						=>		:TIMES,
	/^\bread\b/							=>		:READ,
	/^\bwriteln\b/						=>		:WRITELN,
	/^\bwrite\b/						=>		:WRITE,
	/^\bif\b/							=>		:IF,
	/^\bthen\b/							=>		:THEN,
	/^\belse\b/							=>		:ELSE,
	/^\bwhile\b/						=>		:WHILE,
	/^\bfor\b/							=>		:FOR,
	/^\bfrom\b/							=>		:FROM,
	/^\bto\b/							=>		:TO,
	/^\bby\b/							=>		:BY,
	/^\bfunc\b/							=>		:FUNC,
	/^\breturn\b/						=>		:RETURN,
	/^->/								=>		:FLECHA,
	/^\bnumber\b/						=>		:NUMBER,
	/^\bboolean\b/						=>		:BOOLEANO,
	/^\btrue\b/							=>		:TRUE,
	/^\bfalse\b/						=>		:FALSE,
	/^\band\b/							=>		:AND,
	/^\bor\b/							=>		:OR,
	/^\bnot\b/							=>		:NOT,
	/^==/								=>		:EQ,
	/^\/=/								=>		:DIF, #REPETIDO
	/^>=/								=>		:GETHAN,
	/^<=/								=>		:LETHAN,
	/^>/								=>		:GTHAN,
	/^</								=>		:LTHAN,
	/^\(/								=>		:PAR1,
	/^\)/								=>		:PAR2,
	/^=/								=>		:IGUAL,
	/^\+/								=>		:SUMA,
	/^\-/								=>		:RESTA,
	/^\*/								=>		:MULT,
	/^\//								=>		:SLASH,	
	/^%/								=>		:MOD,
	/^\bdiv\b/							=>		:DIV,
	/^\bmod\b/								=>		:MOD2,
	/^([1-9][0-9]*|0)(\.[0-9]+)?/		=>		:DIGITO,
	/\A"(?:[^\"\\\n]|\\\\|\\"|\\n)*"/	=>		:STRING,
	/^[a-z][a-zA-Z0-9_]*/				=>		:ID,
	/,/									=>		:COMA,
	/^;/								=>		:SEMICOLON
}

$desconocidos = [] #Estructura donde se almacenan los tokens no reconocidos
$conocidos = []		#Estructura donde e almacenan los token reconocidos

#Clase que se utiliza para guardar informacion de los tokens reconocidos
class Token 
	attr_accessor :linea
	attr_accessor :columna
	attr_accessor :tipo
	attr_accessor :match
	
	def initialize(linea,columna, tipo, match)
		@linea = linea
		@columna = columna
		@tipo = tipo
		@match = match
	end 

	def get_token()
		return [tipo, match]

	end
end

#Clase que contiene un metodo para reconocer los tokens dentro del archivo de entrada
class Lexer
	attr_reader :input
	attr_reader :conocidos
	attr_reader :desconocidos
	attr_accessor :numero_linea

	def initialize(input)
		@input = input
		@pos = 1
		$numero_linea = 0
	end

	def match_token

		while !@input.empty?
			return if @input.empty?

			@input =~ /\A[^\S\n]*/ #Ignora los saltos de linea y los espacios en blanco al principio
			@pos = @pos + $&.length if $& != nil
			@input = $'

	
			$tokens.each do |regex, token|
				#Encuentra un token valido
				if @input =~ regex
					
					lexema = Token.new(@numero_linea, @pos, token, $&)
					$conocidos << lexema

					#Recorta la entrada y actualiza el num de columna
					@input = @input[$&.length..@input.length-1]
					@pos = @pos + $&.length

					return $conocidos[-1]
				end		
			end

			if @input =~ /^(#.*)/
				@pos = @pos + $&.length if $& != nil
				@input = $'
			end
			

			@input =~ /(\W|\p{Any})/
			#puts "linea #{@numero_linea}, columna #{@pos}: Caracter desconocido '#{$&}' " unless $&.empty? || $& == " " || $& == "\n"
			if $& != "" && $& != " " && $& != "\n"  
				lexema2 = Token.new(@numero_linea, @pos, "Caracter desconocido: ", $&)
				$desconocidos << lexema2
			end
			@input = @input[$&.length..@input.length-1]
			@pos = @pos + $&.length
			
			


					
		end
	end

	def next_token()
    	token=$conocidos.shift
    	#token == nil ? [false,false] : token.get_token
    	if token == nil
    		return [false,false]
    	else
    		return token.get_token()
    	end

  end

end
