# AUTORES:
# Alessandra Marero 12-11091
# Julio Fuenmayor 13-10488

##########################
# Clase principal de AST #
##########################
class AST
    def indent(ind)
        for i in 1..ind
            print "\t"
        end
	end

	def print_ast (indent="")
		puts "#{indent}#{self.class}:"

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end

class Retina < AST
    attr_accessor :funciones, :bloqueprogram

    def initialize(funciones = nil, bloqueprogram = nil)
        
        @funciones = funciones
        @bloqueprogram = bloqueprogram
    end

    def print_ast(indent="")
    	puts "#{indent}Retina"
    	puts @funciones.print_ast(indent + " ") if not @funciones.nil?
    	puts
    	puts @bloqueprogram.print_ast(indent + " ")
    end
end


###############
# OPERACIONES #
###############
class NodoUnario < AST
	attr_accessor :operando

	def initialize(operando)
		@operando = operando
	end
end


class NodoBinario
	attr_accessor :izquierda, :derecha

	def initialize(lh = nil, rh = nil)
		@izquierda = lh
		@derecha = rh
	end

	def print_ast (indent="")
		puts "#{indent}#{self.class}: " if self.class != "NodoBinario"

		attrs.each do |a|
			a.print_ast (indent + "  ") if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end


class NodoTernario < AST 
	attr_accessor :left, :middle, :right

	def initialize left, middle, right
		@left = left
		@middle = middle
		@right = right
	end
end


##################
# TIPOS DE DATOS #
##################
class TipoDato 
	attr_accessor :tipo 

	def initialize(tipo)
		@tipo = tipo 
	end

	def print_ast (indent="")
		puts "#{indent}Tipo de dato: #{@tipo}"
	end
end


class Booleano < TipoDato
	attr_accessor :valor
	def initialize(valor)
		@valor = valor
	end
	def print_ast(indent="")
		puts "#{indent}|#{self.class}: #{@valor}"
	end
end


class String_ < TipoDato
	attr_accessor :valor
	def initialize(d)
		@valor = d
	end
	def print_ast(indent="")
		puts "#{indent}|#{self.class}: #{@valor}"
	end
end

class Numero < TipoDato
	attr_accessor :valor
	def initialize(valor)
		@valor = valor
	end
end

class PalReservada < TipoDato
	attr_accessor :digito
	def initialize(d)
		@digito = d
	end
  	def print_ast indent=""
      	puts "#{indent}|Palabra Reservada: #{@digito}"
    end
end

class Digito < AST
	attr_accessor :digito
	def initialize(d)
		@digito = d
	end
	def print_ast(indent="")
		puts "#{indent}|#{self.class}: #{@digito}"
	end
end

class Identificador < String_
    attr_accessor :nombre

    def initialize(nombre)
        @nombre = nombre
    end

    def print_ast(indent="")
    	puts "#{indent}|#{self.class}: #{@nombre}"
    end
end
#################
# Comparaciones #
#################
class Comparacion < NodoBinario
	attr_accessor :izquierda, :derecha, :op
	def initialize(izq, der, op)
		@izquierda = izq
		@derecha = der 
		@op = op
	end

  	def print_ast indent=""

		puts "#{indent}|#{op}: "

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
  	end
end

#################
# Op. Aritmeticas #
#################
class AritmeticaBinaria < NodoBinario
	attr_accessor :izquierda, :derecha, :op
	def initialize(izq, der, op)
		@izquierda = izq
		@derecha = der 
		@op = op
	end

  	def print_ast indent=""

		puts "#{indent}|#{op}: "

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
  	end
end
class AritmeticaUnaria < NodoUnario 
	attr_accessor :operando, :op

    def initialize(operando, op)
        @operando = operando
        @op = op
    end
  	def print_ast indent=""

		puts "#{indent}|#{op}: "

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
  	end
end

#################
# Op. Logicas   #
#################
class LogicoUnario < NodoUnario
	attr_accessor :operando

    def initialize(operando)
        @operando = operando
    end
  	def print_ast indent=""

		puts "#{indent}|#{op}: "

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
  	end
end

class LogicoBinario < NodoBinario
	attr_accessor :izquierda, :derecha, :op
	def initialize(izq, der, op)
		@izquierda = izq
		@derecha = der 
		@op = op
	end

  	def print_ast indent=""

		puts "#{indent}|#{op}: "

		attrs.each do |a|
			a.print_ast indent + "  " if a.respond_to? :print_ast
		end
  	end

end

#####################################################################
# Declaraciones, Asignaciones, Identificadores, Entradas y Salidas  #
#####################################################################
class Identificadores 
    attr_accessor :id, :proxID
    def initialize(id = nil, proxId = nil)
        @proxId = proxId
        @id = id
    end

    def print_ast(indent= "")
        @id.print_ast(indent) unless @id.nil?
        @proxId.print_ast(indent) unless @proxId.nil?
    end
end	

class Declaracion 
	attr_accessor :tipo, :asignacion, :identificador

	def initialize(tipo = nil, asignacion = nil, identificador = nil)
		@tipo = tipo
		@asignacion = asignacion
		@identificador = identificador
	end

	def print_ast (indent="")
		@tipo.print_ast(indent + " ")
		@asignacion.print_ast(indent + " ") if not @asignacion.nil?
		@identificador.print_ast(indent + " ") unless @identificador.nil?
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end

class Declaraciones 

    attr_accessor :decl, :proxDecl

    def initialize(decl = nil, proxDecl = nil)
        @proxDecl = proxDecl
        @decl = decl
    end

    def print_ast(indent= "")
        @decl.print_ast(indent) unless @decl.nil?
        @proxDecl.print_ast(indent) unless @proxDecl.nil?
    end
end

class Asignacion 

	attr_accessor :id, :valor

    def initialize(id, valor)
        @id = id
        @valor = valor
    end

    def print_ast(indent= "")
        puts "#{indent}Asignacion: "
        puts "#{indent}|Identificador: #{@id}"
        puts "#{indent}|Valor: "
        @valor.print_ast(indent + "  ")
    end

end


class Entrada < NodoUnario
  def print_ast indent=""
	  puts "#{indent}|Entrada "

	  attrs.each do |a|
		  a.print_ast indent + "  " if a.respond_to? :print_ast
	  end
  end
end

class Salida 
	attr_accessor :argSalida, :ultimoElem, :saltoLinea
    def initialize(argSalida, ultimoElem, saltoLinea = false)
        @argSalida = argSalida
        @ultimoElem = ultimoElem
        @saltoLinea = saltoLinea
	end
  def print_ast indent=""
	  puts "#{indent}|Salida "

	  attrs.each do |a|
		  a.print_ast indent + "  " if a.respond_to? :print_ast
	  end
  end
end

class Args_salida < NodoBinario; end


class Return < NodoUnario; end

#############
# Funciones #
#############


class Argumentos < NodoBinario
  def print_ast indent=""
      #puts "#{indent} Argumento: "

      attrs.each do |a|
          a.print_ast (indent + "") if a.respond_to? :print_ast
      end
  end
end

class Parametros
	attr_accessor :param, :parametros

	def initialize(param = nil, parametros = nil)
		@param = param
		@parametros = parametros
	end

	def print_ast (indent="   ")
		puts "#{indent}Parametros: "
		attrs.each do |a|
		          a.print_ast (indent + " ") if a.respond_to? :print_ast
		end
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end

class Param
	attr_accessor :tipo, :identificador

	def initialize(tipo = nil, identificador = nil)
		@tipo = tipo
		@identificador = identificador
	end

	def print_ast (indent="   ")
		puts @tipo.print_ast(indent)
		puts "#{indent}Identificador: #{@identificador} "
	end

	def attrs
		instance_variables.map do |a|
			instance_variable_get a
		end
	end
end


class Retornar < NodoUnario
  def print_ast (indent="")
      puts "#{indent}Return"

      attrs.each do |a|
          a.print_ast indent + " " if a.respond_to? :print_ast
      end
  end
end

class FuncionRet < AST
  attr_accessor :nombre, :parametros, :tipo, :bloqueinstr
  def initialize n, p, d, i
      @nombre = n
      @parametros = p
      @tipo = d
      @bloqueinstr = i

  end

  	def print_ast (indent="")
		puts "#{indent}Nombre: #{@nombre}"
		puts "#{indent}Parametros: " 
		@parametros.print_ast(indent + " ") unless @parametros.nil?
		@tipo.print_ast(indent) unless @tipo.nil?
		@bloqueinstr.print_ast(indent) unless @bloqueinstr.nil?
	end
end



class LlamadaFunc 
	attr_accessor :nombre, :attrs

	def initialize nombre, attrs
		@nombre = nombre
		@attrs = attrs
	end

	def print_ast(indent="")
		puts "#{indent}Llamada a funcion: "
		puts "#{indent}|Nombre: #{@nombre}"
		puts "#{indent}|Argumentos: " unless @attrs.nil?
		@attrs.print_ast(indent + " ") unless @attrs.nil?
	end


end



class DeclaracionFunciones 

	attr_accessor :funcion, :proxFunc

	def initialize(funcion = nil, proxFunc = nil)
		@funcion = funcion
		@proxFunc = proxFunc
	end

	def print_ast (indent="")
		puts "#{indent}#{self.class}: " if self.class != "NodoBinario"
		@funcion.print_ast(indent + " ") unless @funcion.nil?
		@proxFunc.print_ast(indent + " ") unless @proxFunc.nil?
		
	end

end
##########################
# Estructuras Especiales #
##########################
class Bloque

    attr_accessor :declaraciones, :instrucciones

    def initialize(declaraciones, instrucciones)
        @declaraciones = declaraciones
        @instrucciones = instrucciones
	end

	def print_ast(indent="")
		puts "#{indent}Bloque WITH-DO: "
		puts "#{indent}|Bloque Declaraciones: " 
		@declaraciones.print_ast(indent + "  ") unless @declaraciones.nil?
		puts "#{indent}|Bloque Instrucciones: " 
		@instrucciones.print_ast(indent + "  ") unless @instrucciones.nil?
	end


end

class CicloRepeat < NodoBinario
	attr_accessor :instruccion, :expresion

		def initialize(expresion, instruccion)
			@expresion = expresion
			@instruccion = instruccion
		end

		def print_ast(indent="")
			puts "#{indent}#{self.class}: "
			puts "#{indent}|Instrucciones: " 
			@instruccion.print_ast(indent + "  ") unless @instruccion.nil?
		end
end

class CicloWhile < NodoBinario
	attr_accessor :condicion, :instruccion

		def initialize(condicion, instruccion)
			@condicion = condicion
			@instruccion = instruccion
		end

		def print_ast(indent="")
			puts "#{indent}#{self.class}: "
			puts "#{indent}|Instrucciones: " 
			@instruccion.print_ast(indent + "  ") unless @instruccion.nil?
		end
end

class CicloFor < NodoBinario
	attr_accessor :contador, :intervaloInferior, :intervaloSuperior, :incremento, :instruccion

		def initialize(contador, intervaloInferior, intervaloSuperior, incremento, instruccion)
		@contador  = contador
		@intervaloInferior = intervaloInferior
		@intervaloSuperior = intervaloSuperior
		@incremento = incremento
		@instruccion = instruccion
	end
end

class Condicional < NodoTernario; end


class Instrucciones
	attr_accessor  :instruccion, :proxInstr
    def initialize(instruccion, proxInstr)
        @proxInstr = proxInstr
        @instruccion = instruccion
	end	

	def print_ast(indent="")
	puts "#{indent}Instrucciones: "
	@instruccion.print_ast(indent + " ")
	@proxInstr.print_ast(indent + " ") unless @proxInstr.nil?
	end

	def attrs
        instance_variables.map do |a|
            instance_variable_get a
        end
    end
end


class Programa < NodoUnario
  def print_ast indent=""
      puts "#{indent}Program:"

      attrs.each do |a|
          a.print_ast (indent + " ") if a.respond_to? :print_ast
      end
  end
end


