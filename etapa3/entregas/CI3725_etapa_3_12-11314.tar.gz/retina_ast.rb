# Clases que asisten en la produccion del arbol sintactico 
# abstracto en "retina"
#
# Observaciones: * Falta permitir llamadas a funcion como parte de una expresion
# 				 * Falta verificar que el tipo de los parametros de una funcion coincida con el de los argumentos
# 				   al momento de declararla.
# 				 * Falta verificar que exista un return cuando la funcion tiene un tipo de retorno especificado 
#
# calculator_ast.rb fue utilizado como base.
#
# Autor: 	Jonathan Reyes 	(12-11314)
#

class ContextError < RuntimeError
	def initialize(line=nil, given=nil, expected=nil)
		@line = line
		@expected = expected
		@given = given
	end

	def to_s
		"\n[Syntax ERROR] Linea #{@line}: se esperaba '#{@expected}', pero se recibio '#{@given}'."
	end
end

class UndeclaredFunctionError < ContextError
	def initialize(line, func_name)
		@line = line
		@func_name = func_name
	end

	def to_s
		"\n[Syntax ERROR] Linea #{@line}: funcion '#{@func_name}' no ha sido declarada."
	end
end

class AST
	def print_ast(indent="")
        puts("#{indent}#{self.class}:")

        attrs.each do |a|
            a.print_ast indent + "·   " if a.respond_to? :print_ast
        end
    end

    def attrs
        instance_variables.map do |a|
            instance_variable_get(a)
        end
    end

    def build_table(func_table, var_table=nil)
    	attrs.each do |a|
    		a.build_table(func_table, var_table) if a.respond_to? :build_table
    	end
    end

    def check()
    	attrs.each do |a|
    		a.check if a.respond_to? :check
    	end
    end
end

#####################################################
################ Base Token Classes #################
#####################################################

class CharString < AST
	attr_accessor :charArray, :line

	def initialize(s)
		@charArray = s
		@line = s.line
	end

	def print_ast(indent="")
		puts("#{indent}String: #{@charArray.item}")
	end

	def type()
		"string"
	end
end

######################################################

class Item < AST
	attr_accessor :item, :isBoolean, :isNumber, :line
	
	def initialize(item)
		@item = item
		@line = item.line

		@isBoolean = false
		@isNumber = false
	end

	def isBoolean()
		return @isBoolean
	end

	def isNumber()
		return @isNumber
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}: #{@item.item}")
	end
end

######################################################

class Expression < AST
	attr_accessor :item, :line

	def initialize(item)
		@item = item
		@line = item.line
	end

	def isBoolean()
		return item.isBoolean()
	end

	def isNumber()
		return item.isNumber()
	end

	def type()
		return @item.type()
	end
end

#######################################################
################### Generic Classes ###################
#######################################################

class Type < AST
	attr_accessor :type, :line

	def initialize(datatype)
		@type = datatype
		@line = datatype.line
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}: #{@type.item}")
	end
end

#######################################################

class UnaryOperator < Expression
    attr_accessor :operand

    def initialize(operand)
        super
    end

    def type()
		return @item.type()
	end
end

#######################################################

class BinaryOperator < Expression
    attr_accessor :left, :right

    def initialize(lh, rh)
        @left = lh
        @right = rh
        @line = lh.line
    end
end

class AritBinaryOp < BinaryOperator
	def isNumber()
		check()
		return true
	end

	def check()
		raise ContextError::new(@line,@left.type(),"number") unless @left.isNumber()
		raise ContextError::new(@line,@right.type(),"number") unless @right.isNumber()
	end

	def type()
		"number"
	end
end

class BoolBinaryOp < BinaryOperator
	def isBoolean()
		check()
		return true
	end

	def check()
		raise ContextError::new(@line,@left.type(),"boolean") unless @left.isBoolean()
		raise ContextError::new(@line,@right.type(),"boolean") unless @right.isBoolean()
	end

	def type()
		"boolean"
	end
end

class RelationalOp < BoolBinaryOp
	def check()
		raise ContextError::new(@line,@left.type(),"number") unless @left.isNumber()
		raise ContextError::new(@line,@right,type(),"number") unless @right.isNumber()
	end
end	

#######################################################

class List < AST
	attr_accessor :list 

	def initialize(list)
		@list = list
	end

	def print_ast(indent="")
		puts("#{indent}#{self.class}:")
		@list.each { |l| l.print_ast(indent + "·   ") }
	end

	def build_table(func_table, var_table)
		@list.each {|l| l.build_table(func_table,var_table)}
	end

	def check()
		@list.each {|l| l.check()}
	end
end

#########################################################
################## Reserved Structures ##################
#########################################################

class Code < AST
	attr_accessor :items

	def initialize(items)
		@items = items
		@func_table
		@var_table = []
	end

	def print_ast()
		@items.each do |i|
			i.print_ast();
		end
	end

	def build_table()
		@func_table = SymTable.new()
		@items.each do |i|
			new_table = SymTable.new()
			@var_table += [new_table]
			i.build_table(@func_table, new_table)
		end
	end

	def check()
		@items.each do |i|
			i.check();
		end
	end

	def print_scope()
		@var_table.each do |t|
			t.print_scope()
		end
	end
end

#######################################################

class MainBlock < AST
	attr_accessor :block 

	def initialize(block)
		@block = block
	end

	def build_table(func_table,var_table)
		super
		var_table.assignName("program")
	end
end

#######################################################

class Block < AST
	attr_accessor :declarations, :instructions

	def initialize(declarations,instructions)
		@declarations = declarations
		@instructions = instructions
	end

	def build_table(func_table, var_table)
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		super(func_table,local_table)
	end

end

#######################################################

class Declaration < AST
	attr_accessor :datatype, :tag, :data

	def initialize(datatype, tag, data)
		@datatype = datatype
		@tag = tag
		@data = data
	end

	def build_table(func_table, var_table)
		var_table.addEntry(@tag.item.item, @datatype.type.item)
		super
	end
end

#######################################################

class FunctionDeclare < AST
	attr_accessor :tag, :arguments, :returntype, :instructions

	def initialize(tag, arguments, returntype, instructions)
		@tag = tag
		@arguments = arguments
		@returntype = returntype
		@instructions = instructions
	end

	def build_table(func_table, var_table)
		if @returntype != nil
			type = @returntype.type.item
		else 
			type = nil
		end
		func_table.addEntry(@tag.item.item, type)
		super
		var_table.assignName(@tag.item.item)
	end
end

#######################################################

class FunctionCall < AST
	attr_accessor :tag, :parameters

	def initialize(tag, parameters)
		@tag = tag
		@parameters = parameters
		@func_table
	end

	def build_table(func_table,var_table)
		@func_table = func_table
		super
	end

	def check()
		func_name = @tag.item
		raise UndeclaredFunctionError::new(func_name.line, func_name.item) unless @func_table.contains?(func_name.item)
	end
end

#######################################################

class RepeatCall < AST
	attr_accessor :times, :instructions

	def initialize(times, instructions)
		@times = times
		@instructions = instructions
	end

	def check()
		raise ContextError::new(@times.line, @times.type, "number") unless @times.isNumber()
	end

	def build_table(func_table,var_table)
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		super(func_table,local_table)
	end
end

#######################################################

class ForCall < AST
	attr_accessor :iterator, :start, :finish, :factor, :instructions

	def initialize(iterator, start, finish, factor, instructions)
		@iterator = iterator
		@start = start
		@finish = finish
		@factor = factor
		@instructions = instructions		
		@func_table
	end

	def check()
		raise ContextError::new(@start.line, @start.type, "number") unless @start.isNumber()
		raise ContextError::new(@finish.line, @finish.type, "number") unless @finish.isNumber()
		if @factor != nil
			raise ContextError::new(@factor.line, @factor.type, "number") unless @factor.isNumber()
		end
	end

	def build_table(func_table,var_table)
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		local_table.addEntry(@iterator.item.item, "number")
		super(func_table,local_table)
	end
end

#######################################################

class WhileCall < AST
	attr_accessor :condition, :instructions

	def initialize(condition, instructions)
		@condition = condition
		@instructions = instructions
	end

	def check()
		raise ContextError::new(@condition.line, @condition.type, "boolean") unless @condition.isBoolean()
	end

	def build_table(func_table,var_table)
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		@condition.build_table(func_table,var_table) #if @instructions.respond_to? :build_table
		@instructions.build_table(func_table,local_table) if @instructions.respond_to? :build_table
	end
end

#######################################################

class IfThen < AST
	attr_accessor :condition, :instructions

	def initialize(condition, instructions)
		@condition = condition
		@instructions = instructions
	end

	def check()
		raise ContextError::new(@condition.line, @condition.type, "boolean") unless @condition.isBoolean()
	end

	def build_table(func_table,var_table)
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		@condition.build_table(func_table,var_table) #if @instructions.respond_to? :build_table
		@instructions.build_table(func_table,local_table) #if @instructions.respond_to? :build_table
	end
end

#######################################################

class IfElse < AST
	attr_accessor :condition, :ifInstructions, :elseInstructions

	def initialize(condition, instructions1, instructions2)
		@condition = condition
		@ifInstructions = instructions1
		@elseInstructions = instructions2
	end

	def check()
		raise ContextError::new(@condition.line, @condition.type, "boolean") unless @condition.isBoolean()
	end

	def build_table(func_table,var_table)
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		@condition.build_table(func_table,var_table) #if @instructions.respond_to? :build_table
		@ifInstructions.build_table(func_table,local_table) #if @instructions.respond_to? :build_table
		local_table = SymTable.new(var_table)
		var_table.addChild(local_table)
		@elseInstructions.build_table(func_table,local_table) #if @instructions.respond_to? :build_table
	end
end

#######################################################

class Return < AST
	attr_accessor :expression

	def initialize(e)
		@expression = e
	end
end

#######################################################

class Assign < AST
	attr_accessor :identifier, :value

	def initialize(identifier, value)
		@identifier = identifier
		@value = value
	end

	def check()
		raise ContextError::new(@value.line, @value.type(), @identifier.type()) unless @value.type() == @identifier.type()
	end
end

#######################################################

class Argument < AST
	attr_accessor :type, :identifier

	def initialize(type, identifier)
		@type = type
		@identifier = identifier
	end

	def build_table(func_table, var_table)
		var_table.addEntry(@identifier.item.item, @type.type.item)
		super
	end
end

#######################################################

class StdIn < AST
	attr_accessor :input

	def initialize(input)
		@input = input
	end
end

#######################################################

class StdOut < AST
	attr_accessor :output

	def initialize(out)
		@output = out
	end
end

class StdOutAndLine < StdOut; end

#######################################################
################ Movement Functions ###################
#######################################################

class NoParamFunction < AST; end

class SingleParamFunction < AST
	def initialize(param)
		@parameter = param
	end

	def check()
		raise ContextError::new(@parameter.line, @parameter.type, "number") unless @parameter.isNumber()
	end
end

class DualParamFunction < AST
	def initialize(param1,param2)
		@param1 = param1
		@param2 = param2
	end

	def check()
		raise ContextError::new(@param1.line, @param1.type, "number") unless @param1.isNumber()
		raise ContextError::new(@param2.line, @param2.type, "number") unless @param2.isNumber()
	end
end

############################################################
################## Mass Declarations #######################
############################################################

#Basic Tokes for Data
class Number < Item
	def initialize(item)
		super
		@type = "number"
		@isNumber = true
	end
	def type()
		return @type
	end
end
class Boolean < Item
	def initialize(item)
		super
		@type = "boolean"
		@isBoolean = true
	end
	def type()
		return @type
	end
end
class Identifier < Item
	attr_accessor :table

	def initialize(item, table=nil)
		super(item)
		@local_table = table
	end

	def build_table(func_table,var_table)
		@local_table = var_table
	end

	def isNumber()
		return ("number" == @local_table.getType(@item.item))
	end

	def isBoolean()
		return ("boolean" == @local_table.getType(@item.item))
	end

	def type()
		return @local_table.getType(@item.item)
	end
end

#Lists
class ArgumentList < List; end
class DeclarationList < List; end
class InstructionList < List; end
class Parameters < List; end

#Aritmethic Operators
class UnaryMinus < UnaryOperator
	def check()
		raise ContextError::new(@line,@item,"number") unless @item.isNumber()
	end
end
class Addition < AritBinaryOp; end
class Substraction < AritBinaryOp; end
class Multiplication < AritBinaryOp; end
class WholeDivision < AritBinaryOp; end
class Modulus < AritBinaryOp; end
class ExactDivision < AritBinaryOp; end 
class ExactModulus < AritBinaryOp; end

#Logic Operators
class NegationOp < UnaryOperator
	def check()
		raise ContextError::new(@line,@item,"boolean") unless @item.isBoolean()
	end
end
class Conjunction < BoolBinaryOp; end
class Disjunction < BoolBinaryOp; end

#Relational Operators
class Equivalence < BoolBinaryOp; end
class Difference < BoolBinaryOp; end
class EqualGreaterThan < RelationalOp; end
class EqualLessThan < RelationalOp; end
class LessThan < RelationalOp; end
class GreaterThan < RelationalOp; end

#Generalization
class Condition < Expression; 
	def check()
		raise ContextError::new(@line,@item,"boolean") unless @item.isBoolean()
	end
end

#Movement Functions
class HomeCall < NoParamFunction; end
class OpenEyeCall < NoParamFunction; end
class CloseEyeCall < NoParamFunction; end
class ForwardCall < SingleParamFunction; end
class BackwardCall < SingleParamFunction; end
class RotatelCall < SingleParamFunction; end
class RotaterCall < SingleParamFunction; end
class SetPositionCall < DualParamFunction; end
class ArcCall < DualParamFunction; end


