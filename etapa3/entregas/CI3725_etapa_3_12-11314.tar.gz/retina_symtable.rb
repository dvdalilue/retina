class SymTableError < RuntimeError; end

class RedefineError < SymTableError
	def initialize(tag)
		@tag = tag
	end

	def to_s
		"[ERROR] Intento de redefinir: #{tag}"
	end
end

class DataTypeError < SymTableError
	def initialize(proper_type, value)
		@proper_type = proper_type
		@value_given = value
	end

	def to_s
		"[ERROR] Error asignando valor: se esperaba #{@proper_type}, fue recibido:\n#{@value_given}}"
	end
end

class SymTable
	attr_accessor :parent

	def initialize(parent=nil)
		@parent = parent
		@child = []
		@table = {}
		@name = nil
	end

	def addEntry(tag, type=nil, value=nil)
		raise RedefineError::new(tag) if contains?(tag)
		@table[tag] = {type: type, value: value}
	end

	def addChild(child)
		@child += [child]
	end

	def assignName(tag)
		@name = tag
	end

	#def update(tag, value)  # proxima entrega
	#	raise DataTypeError::new() unless WATCHOUT!!!! ################################################################################
	#end

	def contains?(tag)
		if parent.nil? then 
			return @table.has_key?(tag)
		else 
			return (@table.has_key?(tag) or @parent.contains?(tag))
		end
	end

	def getType(tag)
		if @table.has_key?(tag) then
			return @table[tag][:type]
		elsif @parent.contains?(tag) then
			return @parent.getType(tag)
		end
		return "none"
	end

	def print_scope(indent="")
		puts("#{indent}Alcance _#{@name}:") unless @name.nil?
		puts("#{indent}Sub_Alcance:") if @name.nil?
		puts("#{indent}·   Variables:")
		puts("#{indent}·   ·   Ninguna") if @table.empty? 

		@table.each do |tag, values|
			puts("#{indent}·   ·   #{tag} : #{values[:type]}")
		end

		@child.each do |c|
			c.print_scope(indent + "·   ") if c.respond_to? :print_scope
		end
	end
end