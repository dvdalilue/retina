require_relative 'retina_ast'
require_relative 'retina_symTable'

$symTable = nil		# Tabla de simbolos.
$tableStack = []	# Pila de tablas.

################################################
# Manejo de la estructura general del programa #
################################################

# Manejador del programa principal.
def program_Handler(ast, printSymbolTable)
	return s_Handler(ast.s, printSymbolTable)
end

# Manejador de alcances.
def s_Handler(s, printSymbolTable = nil)
	# Asignación de una nueva tabla.
	symTableAux = SymbolTable.new($symTable)
	$symTable = symTableAux
	s.symTab = $symTable
	#Manejo de la estructura.
	funcError = 0
	if (s.funciones != nil)
		funcError = func_Handler(s.funciones)
	end

	bloqInstrError = bloqInstr_Handler(s.bloqIns)
	# Se empila la tabla del scope en la pila de tablas.
	$tableStack << $symTable
	$symTable = $symTable.father
	# Si ya se analizo todo el programa, se imprimen cada una
	# de las tablas (si no hubo errores).
	if ($symTable == nil)
		if (printSymbolTable)
			if (funcError > 0) or (bloqInstrError > 0)
				puts "Symbol table will not be shown."
				abort
			end
			puts "Symbol Table:"
			$tableStack.reverse!
			$tableStack.each do |st|
				st.print_Table
			end
		end
	end
	return funcError + bloqInstrError
end

# Manejador de funciones del usuario
def func_Handler(funciones)
	#Manejo de la estructura.
	ArgError = 0
	if (funciones.list_Arg != nil)
		ArgError = listArg_Handler(funciones.list_Arg)
	end
    #si la funcion tiene firma verificamos
    firmError = 0
    firma=false
	if (funciones.firma != nil)
		firma=true
		firmError = firm_Handler(funciones.firma)
	end

	instrError = linst_Handler(firma,funciones.list_inst,funciones.nombre)
	return ArgError + instrError + firmError
end

#Manejador para la firma de las funciones
def firm_Handler(firma)
    if (firma.type == Number) or (firma.type == Bool)
    	 firmError=0
    else
    	 firmError=1
	end

    return firmError
end

#Manejador para el bloque de instrucciones
def bloqInstr_Handler(bloque) 
	#Manejo de la estructura.
	declError = 0
	if (bloque.decla_list != nil)
		declError = lDecl_Handler(bloque.decla_list)
	end

	bloqError = bloqInstr2_Handler(bloque.inst_blq1)
	return declError + bloqError
end

# Auxiliar para el bloque de instrucciones
def bloqInstr2_Handler(bloque)
	#Manejo de la estructura.
	instError = 0
	if (bloque.instruction_list != nil)
		instError = linst_Handler(false,bloque.instruction_list,"bloque")
	end

    bloqError = 0
	if (bloque.inst_blq!= nil)
		bloqError = bloqInstr_Handler(bloque.inst_blq)
	end

	return instError + bloqError
end	

# Manejador de lista de instrucciones
def linst_Handler(firma,list_inst,nombre)
	
	if firma == true
  		# verificacion de que return pertenezca a la lista de instrucciones
  		#if (list_inst.inst == Return or
  		#	 list_inst.list_inst.to_a.member? Return)
  			returnError = 0  
  		else 
  			puts "Falta 'Return' en la declaracion de la funcion #{nombre}"	
  			returnError = 1
  		end  
	end

	linstError = 0
	if (list_inst.inst!= nil)
		linstError = linst_Handler(list_inst.inst)
	end
 	instError = inst_Handler(list_inst.inst)

	return returnError + instError + asigError + loopError + listInstError + condError
end

#Manejador para una instruccion
def inst_Handler(instr)
	case instr.type
	when :Asig
			return asig_Handler(instr.argumentos[0])
		end
	when :Read
		return read_Handler(instr)
	when :Write
		return write_Handler(instr)
	when :Writeln
		return writeln_Handler(instr)
	when :InstMovi
		return instMovi_Handler(instr)
	when :Conditional
		return conditional_Handler(instr.argumentos[0])
	when :Loop
		return iLoop_Handler(instr.argumentos[0])
	when :ListDecl
		return lDecl_Handler(instr.argumentos[0])
	end
end

# Manejador de la instruccion IND LOOP.
def iLoop_Handler(iLoop)
	
end

# Manejador de la instruccion DET LOOP.
def Loop_Handler(lLoop)
    case lLoop.type
	when :While
		result = 0
		expr = lLoop.expr
		if (expr_Handler(expr) != :BOOLEAN)
			puts " ERROR: expression must be boolean."
			result += 1
		end
		instr = lLoop.list_inst
		result += linstr_Handler(instr)
		return result
	when :For
			result = 0
		if (lLoop.var.type == :Var)
			iterVar = lLoop.var.term
			# Busca la variable, si la encuentra, la actualiza, si no, la inserta.
			if ($symTable.lookup(iterVar) == nil)
				$symTable.insert(iterVar, [:NumeralLit, nil])
			else
				$symTable.update(iterVar, [:NumeralLit, nil])
			end
			
			return result
		
		end

	when :Repeat
		
	end
    	
end


# Manejador de la instruccion CONDITIONAL STATEMENT.
def conditional_Handler(cond)
	expr = cond.exp
	instr1 = cond.list_inst
	result = linstr_Handler(instr1)

	result += cond1_Handler(cond.cond1)

	if (expr_Handler(expr) != :BOOLEAN)
		puts "CONDITIONAL STATEMENT ERROR: expression must be boolean."
		result += 1
	end
	return result
end

def cond1_Handler(cond1)
    condError=0
    if (cond1.list_inst != nil)
		condError= linstr_Handler(cond1.list_inst)
	end

  	return condError
end 


# Manejador de rReturn
def rReturn_Handler(rReturn)
	rReturnError = expr_Handler(rReturn.expr)
	return rReturnError
end

# Manejador de instMov1
def instMov_Handler(inst_movi1)
	instMov1Error = instMov2_Handler(inst_movi1.inst_movi2)
	return instMov1Error
end

# Manejador de instMovi2
def instMov2_Handler(inst_movi2)
	instMov2Error = expr_Handler(inst_movi2.expr)
	return instMov2Error
end

#Manejador de lista de declaraciones
def lDecl_Handler(ldecl)
	#Manejo de la estructura.
	listDeclError = 0
	if (ldecl.declaration_list != nil)
		listDeclError = lDecl_Handler(ldecl.declaration_list)
	end

    declError =  decl_Handler(ldecl.decl)

	return listDeclError + declError
end

#Manejador de declaraciones
def decl_Handler(decl)

	typeError = 0
	case decl.type
	when :Number
		typeError = decl1_Handler(:Number, decl.decl1)
	when :Bool
		typeError = decl1_Handler(:Bool, decl.decl1)
	else 
	    typeError = 1 
		puts "ERROR declaracion con un tipo desconocido #{decl.type}"
	end
	return typeError
end

# Manejador de decl_Handler1
def decl1_Handler(type, decl)
	
	error=0
    case type
	when :Number
		error = listId_Handler(:Number, decl.list_id)
	when :Bool
		error = listId_Handler(:Bool, decl.list_id)
	end
	asigError = 0
	if (decl.asig != nil)
		asigError = asig_Handler(decl.asig)
	end
	return error + asigError 
end

#Manejador para lista de Id
def listId_Handler(type, listI)

    if !($symTable.contains(listI.var))
		$symTable.insert(listI.var, [type, nil])
		if (listI.list_id != nil)                       # Cambie .listI por .list_id
			return listId_Handler(type, listI.list_id)  # Cambie .listI por .list_id
		end
		return 0
	else
		puts "ERROR: variable '#{listI.var}' was declared before" \
				" at the same scope."
		if (listI.list_id != nil)                           # Cambie .listI por .list_id
			return listId_Handler(type, listI.list_id) + 1  # Cambie .listI por .list_id
		end
		return 1
	end
end

# Manejador para asignaciones
def asig_Handler(asig)
	idVar = asig.id_expr[0].term
	#if (idVar == iterVar)
	#	puts "ASSIGN ERROR: iterator '#{idVar}' cannot be modified."
	#	return 1
	#end
	if ($symTable.lookup(idVar) == nil)
		puts "ASSIGN ERROR: variable '#{idVar}' has not been declared."
		return 1
	end
	typeVar = $symTable.lookup(idVar)[0]
	typeExpr = expr_Handler(asig.id_expr[1])
	if (typeVar != typeExpr)
		puts "ASSIGN ERROR: #{typeExpr} expression assigned to #{typeVar} "\
			"variable '#{idVar}'."
		return 1
	end
	return 0
end


def expr_Handler(expr)
	# Procesar como binaria
	if expr.instance_of?(BinExp)
		return binExp_Handler(expr)
	# Procesar como unaria
	elsif expr.instance_of?(UnaExp)
		return unaExp_Handler(expr)
	# Procesar como parentizada
	elsif expr.instance_of?(ParExp)
		return parExp_Handler(expr)
	# Procesar como un caso base, un termino.
	elsif expr.instance_of?(Terms)
		type = expr.nameTerm
		case type
		when :Identifier			
			idVar = expr.term
			typeVar = $symTable.lookup(idVar)[0]
			return typeVar
		when :True
			return :Bool
		when :False
			return :Bool
		when :Ints
			return :NumeralLit	
		when :Floats
			return :NumeralLit	
		end
	else
		puts "ERROR: hubo un errror expression_Handler."		
	end
end


# Manejador de expresiones binarias:
# Devuelve el tipo de las expresiones binarias
# => si hay un error de tipo, devuelve nil.
def binExp_Handler(expr)
	typeExpr1 = expr_Handler(expr.left)
	typeExpr2 = expr_Handler(expr.right)
	if (typeExpr1 != typeExpr2)
		return nil
	end
	case expr.op
	when /^(or|and)/
		if typeExpr1 == :BOOLEAN
			return :BOOLEAN
		else
			return nil
		end

	when /^(==|\/=)/
		return :BOOLEAN

	when /^[\+\-\*\/%]/
		if typeExpr1 == :NumeralLit
			return :NumeralLit
		else
			return nil
		end
	when /^(mod|div)/
		if (typeExpr1 == :NumeralLit) and (typeExpr2 == :NumeralLit)
			return :NumeralLit
		else
			return nil
		end

	when /^(<|>|<=|>=)/
		if (typeExpr1 == :NumeralLit) and (typeExpr2 == :NumeralLit)
			return :Bool
		else
			return nil
		end
	end
end

# Manejador de expresiones parentizadas.
def parExp_Handler(expr)
	return expr_Handler(expr.expr)
end

# Manejador de expresiones unarias.
def unaExp_Handler(expr)
	typeExpr = expr_Handler(expr.right)
	case expr.op
	when /not/
		if typeExpr == :BOOLEAN
			return :BOOLEAN
		else
			return nil
		end
	when /-/
		if typeExpr == :NUMBER
			return :NUMBER
		else
			return nil
		end
	end
end




# Manejador de la instruccion read.
def read_Handler(read)
	idVar = read.argumentos[0].term
	if ($symTable.lookup(idVar) == nil)
		puts "READ ERROR: variable '#{idVar}' has not been declared."
		return 1
	end
	typeVar = $symTable.lookup(idVar)[0]
	if (typeVar != :NUMBER) and (typeVar != :BOOLEAN)
		puts "READ ERROR: variable '#{idVar}' must be an int or a boolean."
		return 1
	end
	return 0
end

# Manejador de la instruccion write.
def write_Handler(write)
	expr = write.argumentos[0]
	typeExpr = expr_Handler(expr)
	if (typeExpr != :String)
		puts "WRITE ERROR: the expression given must be a string."
		return 1
	end
	return 0
end

def writeln_Handler(write)
	expr = write.argumentos[0]
	typeExpr = expr_Handler(expr)
	if (typeExpr != :String)
		puts "WRITE ERROR: the expression given must be a string."
		return 1
	end
	return 0
end


def listArg_Handler(list_Arg)
	typeError =  type_Handler(list_Arg.tipo)

	listArgError = 0
	if (list_Arg.list_Arg != nil)
		listArgError = listArg_Handler(list_Arg.list_Arg)
	end

	return typeError + listArgError
end


def type_Handler(type)
	error = 1
	if (type == :Number)
		error = 0
	elsif (type == :Bool)
		error = 0
	else
		puts "ERROR: unknown type: #{type}."
	end

	return error
end
